/*
 * database.h
 *
 * Author: Tim Van Wassenhove <timvw@users.sourceforge.net>
 * Update: 25-06-2004 14:11
 *
 * header file for a function that ass a gsmnumber to a database
 * and then returns a usercode.
 *
*/

#include <mysql.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <Code.h>

#define DBHOST "localhost"
#define DBUSER "user"
#define DBPASS "pass"
#define DBNAME "test"

int adduser(const char *, char *);

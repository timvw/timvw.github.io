/*
 * NSGClient.cc
 *
 * Author: Tim Van Wassenhove <timvw@users.sourceforge.net>
 * Update: 25-06-2004 14:11
 *
 * Communicate with the netsize gateway.
 *
*/

#include "NSGClient.h"

int get(CAGFrame * oResultFrame)
{
  // fill parameters for connection
  CAGFrame oParamFrame;
  oParamFrame[AG_BROKER_ADDRESS_PARAM] = _T(HOST);
  oParamFrame[AG_BROKER_PORT_PARAM] = _T(PORT);
  oParamFrame[AG_ENDPOINT_NAME_PARAM] = _T(MOEP);
  oParamFrame[AG_TIMEOUT_PARAM] = 5000L;
  oParamFrame[AG_PEER_NAME_PARAM] = AGSMSEXT_PEER_NAME;
  oParamFrame[AG_CHANNEL_TYPE_PARAM] = (long)ag_ctTCPIPSocket;
  oParamFrame[AG_COMMUNICATION_MODE_PARAM] = (long)ag_cmAsync;

  AGReturnCode agRet = agGenericError;

  // try to connect
  CAGCppEndpoint oEndpoint;
  if ((agRet = oEndpoint.Open(oParamFrame)) != agSuccess)
  {
    oEndpoint.Close();
    return -1;
  }

  // try to recieve a frame
  CAGFrame oGetParam;
  if ((agRet = oEndpoint.Get(*oResultFrame, oGetParam)) == agNoDataInQueue)
  {
    oEndpoint.Close();
    return -2;
  }
  
  // close connection
  oEndpoint.Close();
  
  // message recieved
  return 0;
}

int send(CAGString target, CAGString message)
{

  // fill login frame
  CAGFrame oLogin;
  oLogin[AG_EXTENSION_REQUEST] = AGSMS_REQ_LOGIN;
  oLogin[AGSMS_REQSLOT_LOGIN_NAME] = _T(USER);
  oLogin[AGSMS_REQSLOT_LOGIN_PWD] = _T(PASS);
  
  // fill send frame
  CAGFrame oSend;
  oSend[AG_EXTENSION_REQUEST] = AGSMS_REQ_SEND;
  oSend[AGSMS_REQSLOT_SEND_TARGET] = target;
  oSend[AGSMS_REQSLOT_SEND_MESSAGE] = message;
  
  CAGArray oRequests;
  oRequests.AddArraySlot(oLogin);
  oRequests.AddArraySlot(oSend);
  
  // put login frame and send frame in a single frame
  CAGFrame oSendFrame;
  oSendFrame[AG_EXTENSION_REQUEST] = oRequests;
  
  // fill parameters for connection
  CAGFrame oParamFrame;
  oParamFrame[AG_BROKER_ADDRESS_PARAM] = _T(HOST);
  oParamFrame[AG_BROKER_PORT_PARAM] = _T(PORT);
  oParamFrame[AG_ENDPOINT_NAME_PARAM] = _T(MTEP);
  oParamFrame[AG_TIMEOUT_PARAM] = 10000L;
  oParamFrame[AG_PEER_NAME_PARAM] = AGSMSEXT_PEER_NAME;
  oParamFrame[AG_CHANNEL_TYPE_PARAM] = (long)ag_ctTCPIPSocket;
  oParamFrame[AG_COMMUNICATION_MODE_PARAM] = (long)ag_cmSync;

  AGReturnCode agRet = agGenericError;

  // try to connect
  CAGCppEndpoint oEndpoint;
  if ((agRet = oEndpoint.Open(oParamFrame)) != agSuccess)
  {
    oEndpoint.Close();
    return -1;
  }

  // try to send the frame
  CAGFrame oParams;
  if ((agRet = oEndpoint.Send(oSendFrame, oParams)) != agSuccess)
  {
    oEndpoint.Close();
    return -2;
  }

  // wait for response frame
  CAGFrame oGetFrame;
  while ((agRet = oEndpoint.Get(oGetFrame, oParams)) == agTimeout)
  {
    // busy waiting
  }

  // try to get response frame
  if (agRet != agSuccess)
  {
    oEndpoint.Close();
    return -3;
  }
  
  // close connection
  oEndpoint.Close();
  
  // analyse response frame
  AGReturnCode nReturnCode;
  
  // test if authentication failed
  oGetFrame.IsLong(AG_EXTENSION_REQUEST _T(".0.") AG_EXTENSION_RESULT_CODE, &nReturnCode);
  if (nReturnCode != agSuccess)
  {
    return -4;
  }

  // test if message was sent
  oGetFrame.IsLong(AG_EXTENSION_REQUEST _T(".1.") AG_EXTENSION_RESULT_CODE, &nReturnCode);
  if (nReturnCode != agSuccess)
  {
    return -5;
  }

  // message sent
	return 0;
}

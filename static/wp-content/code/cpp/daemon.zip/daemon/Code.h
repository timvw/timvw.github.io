/*
 * Code.h
 *
 * Author: Tim Van Wassenhove <timvw@users.sourceforge.net>
 * Update: 25-06-2004 14:11
 *
 * header file for a function that generates a usercode.
 *
*/

#include <map>
#include <cmath>

void getcode(double number, char *);

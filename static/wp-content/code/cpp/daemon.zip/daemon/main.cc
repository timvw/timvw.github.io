/*
 * main.cc
 *
 * Author: Tim Van Wassenhove <timvw@users.sourceforge.net>
 * Update: 25-06-2004 14:11
 *
 * daemon that talks with netsize gateway.
 * If an incoming message is recieved, a reply will be sent.
 *
*/

#include "main.h"

int main(int argc, char ** argv)
{
  // what are broken pipes anyway?
  signal(SIGPIPE,NULL);

  // fork out and start new process group
  int forknum = fork();

  // failed to fork
  if (forknum == -1)
  {
    cout << "Error: Unable to fork new process" << endl;
    exit(1);
  }
  setsid();

  // parent process
  if (forknum > 0)
  {
    exit(0);
  }

  // endless loop
  int counter = 10; 
  while (true)
  {
    if (counter == 10)
    {
        logfile.open(LOGFILE, ofstream::out | ofstream::app);
        logfile << time(NULL) << " alive." << endl;
        logfile.close();
        counter = 0;
    }
    run();
    counter++;
  }
}

void run()
{
  // try to get incoming message
  CAGFrame * oResultFrame = new CAGFrame();
  int result = get(oResultFrame);
  while (result == 0)
  {
    // handle incoming message
    long nType;
    oResultFrame->IsLong(AGSMS_EVENT_TYPE, &nType);
    
    if (nType == nsg_etReceive)
    {
      CAGString sMessage;
      CAGString sFrom;
      oResultFrame->IsString(AGSMS_INCOMING_MESSAGE, &sMessage);
      oResultFrame->IsString(AGSMS_INCOMING_MESSAGE_ORIGIN, &sFrom);

      logfile.open(LOGFILE, ofstream::out | ofstream::app);
      logfile << time(NULL) << " " << (LPCTSTR)sFrom << ": " << (LPCTSTR)sMessage << endl;
      logfile.close();
      
      char * usercode = new char[255];

      int result = adduser((LPCTSTR)sFrom, usercode);

      if (result == 0)
      {
          char * message = new char[255];
          strcpy(message, "Hello, your code is: ");
          strcat(message, usercode);
          
          CAGString sReply(_T(message));
          
          send(sFrom, sReply);
          delete [] message;
      }

      delete [] usercode;
      
    }
    
    // try to get incoming message
    result = get(oResultFrame);
  }
  delete oResultFrame;
  
  // sleep for a while
  sleep(60);
}


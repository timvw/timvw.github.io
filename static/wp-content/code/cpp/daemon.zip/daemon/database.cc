/*
 * database.cc
 *
 * Author: Tim Van Wassenhove <timvw@users.sourceforge.net>
 * Update: 25-06-2004 14:11
 *
 * Find a unique usercode and return it.
 *
*/

#include "database.h"

int adduser(const char * gsmnumber, char * usercode)
{
  MYSQL database;
  MYSQL_RES *res;
  MYSQL_ROW row;
  
  // try to connect
  if (!mysql_connect(&database, DBHOST, DBUSER, DBPASS))
  {
    return -1;
  }
  
  // try to select database
  if (mysql_select_db(&database, DBNAME))
  {
    return -2;
  }

  double number = time(NULL);
  bool ready = false;
  while (!ready)
  {
      getcode(number, usercode);

      char * query = new char[255];
      
      // perform the query
      sprintf(query, "SELECT * FROM user_netsize WHERE usercode='%s'", usercode);
      if (mysql_real_query(&database, query, 255))
      {
          delete [] query;
          return -3;
      }
      delete [] query;

      res = mysql_store_result(&database);
      
      row = mysql_fetch_row(res);
      if (!row)
      {
          char * query2 = new char[255];
          sprintf(query2, "INSERT INTO user_netsize (usercode, gsmnumber) VALUES ('%s', '%s')", usercode, gsmnumber);
          if (mysql_real_query(&database, query2, 255))
          {
              delete [] query2;
              return -4;
          }
          delete [] query2;
          ready = true;
      }
      
      mysql_free_result(res);
      number++;
  }
  
  // disconnect
  mysql_close(&database);
  
  // we added the user
  return 0;
}

/*
 * NSGClient.h
 *
 * Author: Tim Van Wassenhove <timvw@users.sourceforge.net>
 * Update: 25-06-2004 14:11
 *
 * Header file for functions that send and recieve messages
 * from the netsize gateway.
 *
*/

#define AG_USES_AG_CORE_HEADER
#define AG_USES_AG_ENDPOINT_HEADER

#include <StdPort.h>
#include <AGSmsBaseDefines.h>
#include <AGSmsDefines.h>
#include <AGSmsRequestLoginDefines.h>
#include <AGSmsRequestMessagesDefines.h>
#include <AGSmsReturnCodeDefines.h>

#define USER "user"
#define PASS "pass"
#define MTEP "NSGClientMT^user"
#define MOEP "NSGClientMO^user"
#define SREP "NSGClientSR^user"

#define HOST "be.netsizeonline.com"
#define PORT "38000"

int get(CAGFrame *);
int send(CAGString, CAGString);


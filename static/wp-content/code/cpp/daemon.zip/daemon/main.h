/*
 * main.h
 *
 * Author: Tim Van Wassenhove <timvw@users.sourceforge.net>
 * Update: 25-06-2004 14:11
 *
*/

#ifndef MAIN_H
#define MAIN_H

#include <unistd.h>
#include <csignal>
#include <cstdlib>

#include <fstream>
using namespace std;

#include <iostream>
using std::cout;
using std::endl;

#include "NSGClient.h"
#include "database.h"

#define LOGFILE "ring.log"

ofstream logfile;

int main(int, char **);
void run();

#endif


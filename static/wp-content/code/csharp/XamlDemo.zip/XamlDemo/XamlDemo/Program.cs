using System;
using XamlDemo.Domain;
using XamlDemo.Infrastructure;

namespace XamlDemo
{
    class Program
    {
        private static void Main()
        {
            Person tim = DataLoader.Load<Person>("Domain.Person.Tim");
            Display(tim);

            Person jeff = DataLoader.Load<Person>("Domain.Person.Jeff");
            Display(jeff);

            Console.Write("{0}Press any key to continue...", Environment.NewLine);
            Console.ReadKey();
        }

        private static void Display(Person person)
        {
            Console.WriteLine("Information about: {0}", person.Name);
            Console.WriteLine("Birthday: {0}", person.Birthday.ToString("dd/MM/yyyy"));
            foreach (Address address in person.Addresses)
            {
                Display(address);
            }
            Console.WriteLine("--");
        }

        private static void Display(Address address)
        {
            Console.WriteLine();
            foreach (string line in address.Lines)
            {
                Console.WriteLine(line);
            }
        }
    }
}

﻿using System.Collections.Generic;

namespace XamlDemo.Domain
{
    public class Address
    {
        private IList<string> lines;

        public Address()
        {
            this.lines = new List<string>();
        }

        public IList<string> Lines
        {
            get { return this.lines; }
            set { this.lines = value; }
        }
    }
}
﻿using System;
using System.Collections.Generic;

namespace XamlDemo.Domain
{
    public class Person
    {
        private string name;
        private DateTime birthday;
        private IList<Address> addresses;

        public Person()
        {
            this.addresses = new List<Address>();
        }

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public DateTime Birthday
        {
            get { return this.birthday; }
            set { this.birthday = value; }
        }

        public IList<Address> Addresses
        {
            get { return this.addresses; }
            set { this.addresses = value; }
        }
    }
}
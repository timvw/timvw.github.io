﻿using System;
using System.Windows.Markup;
using System.Collections.Generic;

namespace XamlDemo.Infrastructure.Extensions
{
    public class ExternalList : MarkupExtension
    {
        private string type;
        private IList<string> resources;

        public string Type
        {
            get { return this.type; }
            set { this.type = value; }
        }

        public IList<string> Resources
        {
            get { return this.resources; }
            set { this.resources = value; }
        }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            Array value = Array.CreateInstance(System.Type.GetType(this.Type), this.Resources.Count);
            
            for(int i = 0; i < this.Resources.Count; ++i)
            {
                value.SetValue(DataLoader.Load(this.Resources[i]), i);
            }

            return value;
        }
    }
}

﻿using System;
using System.Windows.Markup;

namespace XamlDemo.Infrastructure.Extensions
{
    public class DateTime : MarkupExtension
    {
        private string value;
        private string format;

        public DateTime()
            : this("01/01/00")
        {
        }

        public DateTime(string value)
            : this(value, "dd/MM/yyyy")
        {
        }

        public DateTime(string value, string format)
        {
            this.value = value;
            this.format = format;
        }

        public string Value
        {
            get { return this.value; }
            set { this.value = value; }
        }

        public string Format
        {
            get { return this.format; }
            set { this.format = value; }
        }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return System.DateTime.ParseExact(this.value, this.format, null);
        }
    }
}

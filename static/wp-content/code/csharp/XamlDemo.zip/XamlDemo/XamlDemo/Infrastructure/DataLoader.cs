﻿using System.IO;
using System.Windows.Markup;

namespace XamlDemo.Infrastructure
{
    public static class DataLoader
    {
        public static object Load(string resourceName)
        {
            string fileName = Path.Combine("TestData", resourceName.Replace('.', '\\') + ".xaml");
            using(FileStream fileStream = new FileStream(fileName, FileMode.Open))
            {
                return XamlReader.Load(fileStream);
            }
        }

        public static T Load<T>(string resourceName)
        {
            return (T) Load(resourceName);
        }
    }
}
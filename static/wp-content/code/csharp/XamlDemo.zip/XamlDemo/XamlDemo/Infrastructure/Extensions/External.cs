﻿using System;
using System.Windows.Markup;

namespace XamlDemo.Infrastructure.Extensions
{
    public class External : MarkupExtension
    {
        private string type;
        private string resource;

        public string Type
        {
            get { return this.type; }
            set { this.type = value; }
        }

        public string Resource
        {
            get { return this.resource; }
            set { this.resource = value; }
        }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return DataLoader.Load(this.resource);
        }
    }
}

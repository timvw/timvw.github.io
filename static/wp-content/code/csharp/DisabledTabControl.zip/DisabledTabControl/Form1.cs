using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DisabledTabControl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            foreach (TabPage tabPage in this.tabControl1.TabPages)
            {
                tabPage.EnabledChanged += new EventHandler(this.tabPage_EnabledChanged);
            }

            this.tabControl1.TabPages[2].Enabled = false;
        }

        private void buttonToggle_Click(object sender, EventArgs e)
        {
            foreach (TabPage tabPage in this.tabControl1.TabPages)
            {
                tabPage.Enabled = !tabPage.Enabled;
            }
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (!e.TabPage.Enabled)
            {
                e.Cancel = true;
            }
        }

        private void tabControl1_ControlAdded(object sender, ControlEventArgs e)
        {
            TabPage tabPage = sender as TabPage;
            if (tabPage != null)
            {
                tabPage.EnabledChanged += new EventHandler(this.tabPage_EnabledChanged);
            }
        }

        private void tabControl1_ControlRemoved(object sender, ControlEventArgs e)
        {
            TabPage tabPage = sender as TabPage;
            if (tabPage != null)
            {
                tabPage.EnabledChanged -= new EventHandler(this.tabPage_EnabledChanged);
            }
        }
        void tabPage_EnabledChanged(object sender, EventArgs e)
        {
            TabPage tabPage = sender as TabPage;
            TabControl tabControl = tabPage.Parent as TabControl;
            tabControl.Invalidate(tabPage.ClientRectangle);
        }

        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            TabControl tabControl = sender as TabControl;
            TabPage tabPage = tabControl.TabPages[e.Index];
            Rectangle tabRectangle = tabControl.GetTabRect(e.Index);

            if (tabControl.Alignment == TabAlignment.Left || tabControl.Alignment == TabAlignment.Right)
            {
                float rotateAngle = 90;
                if (tabControl.Alignment == TabAlignment.Left)
                {
                    rotateAngle = 270;
                }

                PointF cp = new PointF(tabRectangle.Left + (tabRectangle.Width / 2), tabRectangle.Top + (tabRectangle.Height / 2));
                e.Graphics.TranslateTransform(cp.X, cp.Y);
                e.Graphics.RotateTransform(rotateAngle);
                tabRectangle = new Rectangle(-(tabRectangle.Height / 2), -(tabRectangle.Width / 2), tabRectangle.Height, tabRectangle.Width);
            }

            using (SolidBrush foreBrush = new SolidBrush(tabPage.ForeColor))
            {
                using (SolidBrush backBrush = new SolidBrush(tabPage.BackColor))
                {
                    if (!tabPage.Enabled)
                    {
                        foreBrush.Color = SystemColors.GrayText;
                    }

                    e.Graphics.FillRectangle(backBrush, tabRectangle);

                    using (StringFormat stringFormat = new StringFormat())
                    {
                        stringFormat.Alignment = StringAlignment.Center;
                        stringFormat.LineAlignment = StringAlignment.Center;
                        e.Graphics.DrawString(tabPage.Text, e.Font, foreBrush, tabRectangle, stringFormat);
                    }
                }
            }

            e.Graphics.ResetTransform();
        }
    }
}
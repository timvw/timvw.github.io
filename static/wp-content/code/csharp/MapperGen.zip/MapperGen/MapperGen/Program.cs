using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;

namespace MapperGen
{
    class Program
    {
        static void Main(string[] args)
        {
            //if (args.Length != 1)
            //{
            //    MessageBox.Show("This application cannot be launched directly.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //}

            args = new string[] { "DomainObjects.dll" };

            Assembly assembly = Assembly.ReflectionOnlyLoadFrom(args[0]);
            foreach (Type type in assembly.GetExportedTypes())
            {
                if (type.Namespace == "DomainObjects")
                {
                    GenerateMappers(type);
                }
            }

            Console.Write("{0}Press any key to continue...", Environment.NewLine);
            Console.ReadKey();
        }

        private static void GenerateMappers(Type type)
        {
            GenerateMapper(type, Direction.InternalToExternal);
            GenerateMapper(type, Direction.ExternalToInternal);
        }

        private static void GenerateMapper(Type type, Direction direction)
        {
            string template = File.ReadAllText(@"template.txt");

            string externalTypes = "Contracts.External";
            string internalTypes = "DomainObjects";

            string source;
            string destination;

            if (direction == Direction.ExternalToInternal)
            {
                source = "External";
                destination = "Internal";
            }
            else
            {
                source = "Internal";
                destination = "External";
            }

            string className = source + type.Name + "To" + destination + type.Name + "Builder";
            string sourceVariable = source.ToLower() + type.Name;
            string destinationVariable = destination.ToLower() + type.Name;

            StringBuilder stringBuilder = new StringBuilder();
            foreach (PropertyInfo propertyInfo in type.GetProperties())
            {
                GenerateMapper(stringBuilder, className, source, sourceVariable, destination, destinationVariable, propertyInfo);
            }
            string properties = stringBuilder.ToString();

            string mapper = string.Format(template, externalTypes, internalTypes, className, type.Name, source, destination, sourceVariable, destinationVariable, properties);
            File.WriteAllText(className + ".cs", mapper);
        }

        private static void GenerateMapper(StringBuilder stringBuilder, string className, string source, string sourceVariableName, string destination, string destinationVariableName, PropertyInfo propertyInfo)
        {
            string indent = new string(' ', 12);

            if (propertyInfo.PropertyType.Namespace == "System")
            {
                stringBuilder.Append(indent + destinationVariableName + "." + propertyInfo.Name + " = " + sourceVariableName + "." + propertyInfo.Name + ";" + Environment.NewLine);
            }
            else
            {
                if (propertyInfo.PropertyType.Name.EndsWith("[]"))
                {
                    stringBuilder.Append(indent + destinationVariableName + "." + propertyInfo.Name + " = "
                        + "Mapper<" + destination + "Types." + propertyInfo.PropertyType.Name.Replace("[]","") + ">.ConvertAll( "
                        + sourceVariableName + "." + propertyInfo.Name + " );" + Environment.NewLine
                        );
                }
                else
                {
                    stringBuilder.Append(indent + destinationVariableName + "." + propertyInfo.Name + " = "
                        + "Mapper<" + destination + "Types." + propertyInfo.PropertyType.Name + ">.Convert( "
                        + sourceVariableName + "." + propertyInfo.Name + " );" + Environment.NewLine
                        );
                }
            }
        }
    }

    enum Direction
    {
        InternalToExternal = 1,
        ExternalToInternal = 2
    }

}

using System;
using System.Collections.Generic;
using System.Text;

namespace DomainObjects
{
    public class Class1
    {
        private int id;
        private Class2[] children;

        public int Id
        {
            get { return this.id; }
            set { this.id = value; }
        }

        public Class2[] Children
        {
            get { return this.children; }
            set { this.children = value; }
        }
    }
}

using System;
using System.Windows.Forms;
using System.Drawing;
using VanWassenhove.WinForms;

namespace Printing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.dataGridView1.ColumnCount = 8;
            this.dataGridView1.RowCount = 50;

            for (int i = 0; i < this.dataGridView1.ColumnCount; ++i)
            {
                this.dataGridView1.Columns[i].HeaderText = String.Format("{0:00}", i);
            }

            this.dataGridView1.RowHeadersWidth = 100;
            for (int i = 0; i < this.dataGridView1.RowCount; ++i)
            {
                this.dataGridView1.Rows[i].HeaderCell.Value = String.Format("{0:00}", i);
            }

            for (int i = 0; i < this.dataGridView1.RowCount; ++i)
            {
                for (int j = 0; j < this.dataGridView1.ColumnCount; ++j)
                {
                    this.dataGridView1.Rows[i].Cells[j].Value = String.Format("{0:00},{1:00}", i, j);
                }
            }

            ResizedControlPrintPageEventHandler resizedControlPrintPageEventHandler = new ResizedControlPrintPageEventHandler(this.dataGridView1);
            this.printDocument1.PrintPage += resizedControlPrintPageEventHandler.PrintPage;
        }

        private void buttonPreview_Click(object sender, EventArgs e)
        {
            this.printPreviewDialog1.Show();
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            this.printDocument1.Print();
        }
    }
}
﻿using System;
using System.Windows.Forms;
using System.Web;

namespace HtmlClipboard
{
    public partial class TrayForm : Form
    {
        public TrayForm()
        {
            InitializeComponent();
        }

        private void toolStripMenuItemDecode_Click(object sender, EventArgs e)
        {
            string original = Clipboard.GetText();
            string htmlEncoded = HttpUtility.HtmlDecode(original);
            Clipboard.SetText(htmlEncoded);
        }

        private void toolStripMenuItemEncode_Click(object sender, EventArgs e)
        {
            string original = Clipboard.GetText();
            string htmlEncoded = HttpUtility.HtmlEncode(original);
            Clipboard.SetText(htmlEncoded);
        }

        private void toolStripMenuItemExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

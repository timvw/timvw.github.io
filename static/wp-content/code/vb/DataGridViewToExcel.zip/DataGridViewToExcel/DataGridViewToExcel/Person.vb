﻿Imports System

Namespace DataGridViewToExcel
    <Serializable> _
    Public Class Person
        ' Methods
        Public Sub New(ByVal id As Integer, ByVal name As String, ByVal birthday As DateTime)
            Me._id = id
            Me._name = name
            Me._birthday = birthday
        End Sub


        ' Properties
        Public Property Birthday As DateTime
            Get
                Return Me._birthday
            End Get
            Set(ByVal value As DateTime)
                Me._birthday = value
            End Set
        End Property

        Public Property Id As Integer
            Get
                Return Me._id
            End Get
            Set(ByVal value As Integer)
                Me._id = value
            End Set
        End Property

        Public Property Name As String
            Get
                Return Me._name
            End Get
            Set(ByVal value As String)
                Me._name = value
            End Set
        End Property


        ' Fields
        Private _birthday As DateTime
        Private _id As Integer
        Private _name As String
    End Class
End Namespace


Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim persons As New List(Of DataGridViewToExcel.Person)
        persons.Add(New DataGridViewToExcel.Person(1, "Tim", New DateTime(&H7BC, 4, 30)))
        persons.Add(New DataGridViewToExcel.Person(2, "Mike", New DateTime(&H7BE, 7, 30)))
        persons.Add(New DataGridViewToExcel.Person(3, "Joe", New DateTime(&H7C0, 4, &H15)))
        Me.DataGridView1.Columns.Add("Id", "Id")
        Me.DataGridView1.Columns.Item(0).ValueType = GetType(Integer)
        Me.DataGridView1.Columns.Add("Name", "Name")
        Me.DataGridView1.Columns.Add("Birthday", "Birthday")
        Me.DataGridView1.Columns.Item(2).ValueType = GetType(DateTime)
        Dim person As DataGridViewToExcel.Person
        For Each person In persons
            Me.DataGridView1.Rows.Add(New Object() {person.Id, person.Name, person.Birthday})
        Next
        Me.DataGridView1.Item(1, 0).Style.ForeColor = Color.Yellow
        Me.DataGridView1.Item(1, 0).Style.BackColor = Color.Black
        Using f As Font = New Font(FontFamily.GenericSansSerif, 12.3!)
            Me.DataGridView1.Item(1, 0).Style.Font = f
        End Using
    End Sub
End Class

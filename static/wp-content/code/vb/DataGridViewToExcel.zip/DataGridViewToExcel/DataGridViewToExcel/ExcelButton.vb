﻿Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Windows.Forms

Public Class ExcelButton
    Inherits Button
    ' Methods
    Public Sub New()
        AddHandler MyBase.Click, New EventHandler(AddressOf Me.ExcelButton_Click)
    End Sub

    Private Sub ExcelButton_Click(ByVal sender As Object, ByVal e As EventArgs)
        If (Me.DataGridView Is Nothing) Then
            Throw New ArgumentNullException("No DataGridView was provided for export")
        End If
        Using saveFileDialog As SaveFileDialog = Me.GetExcelSaveFileDialog
            If (saveFileDialog.ShowDialog(Me) = DialogResult.OK) Then
                Dim fileName As String = saveFileDialog.FileName
                ExcelGenerator.Generate(Me.DataGridView).Save(fileName)
                Process.Start(fileName)
            End If
        End Using
    End Sub

    Private Function GetExcelSaveFileDialog() As SaveFileDialog
        Dim saveFileDialog As New SaveFileDialog
        saveFileDialog.CheckPathExists = True
        saveFileDialog.AddExtension = True
        saveFileDialog.ValidateNames = True
        saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
        saveFileDialog.DefaultExt = ".xls"
        saveFileDialog.Filter = "Microsoft Excel Workbook (*.xls)|*.xls"
        Return saveFileDialog
    End Function


    ' Properties
    <Description("The DataGridView to export to Excel")> _
    Public Property DataGridView() As DataGridView
        Get
            Return Me._dataGridView
        End Get
        Set(ByVal value As DataGridView)
            Me._dataGridView = value
            MyBase.Enabled = (Not value Is Nothing)
        End Set
    End Property


    ' Fields
    Private _dataGridView As DataGridView
End Class


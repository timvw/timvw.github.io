﻿using System;
using System.Windows.Forms;
namespace Be.TimVW.ActiveHome.Windows
{
    public interface ITrayView
    {
        event EventHandler MenuClicked;
        event EventHandler ExitClicked;
        void Close();
    }
}

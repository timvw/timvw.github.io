﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Be.TimVW.ActiveHome.Library;

namespace Be.TimVW.ActiveHome.Windows
{
    public class TrayPresenter
    {
        private ITrayView trayView;

        public TrayPresenter(ITrayView view)
        {
            this.trayView = view;
            this.trayView.MenuClicked += this.trayView_MenuClicked;
            this.trayView.ExitClicked += this.trayView_ExitClicked;
        }

        void trayView_MenuClicked(object sender, EventArgs e)
        {
            using (MenuView menuView = new MenuView())
            {
                menuView.ShowDialog();
            }
        }

        private void trayView_ExitClicked(object sender, EventArgs e)
        {
            this.trayView.Close();
        }
    }
}

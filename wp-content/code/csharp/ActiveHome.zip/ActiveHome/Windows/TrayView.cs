﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Be.TimVW.ActiveHome.Windows
{
    public partial class TrayView : Form, ITrayView
    {
        public event EventHandler MenuClicked;
        public event EventHandler ExitClicked;

        public TrayView()
        {
            InitializeComponent();

            this.Hide();
        }

        private void Form1_VisibleChanged(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Hide();
        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            ToolStripItem clickedToolStripItem = e.ClickedItem;
            if (clickedToolStripItem == this.toolStripMenuItemAbout)
            {
                this.RaiseToolStripMenuItemClicked(this.MenuClicked, EventArgs.Empty);
            }
            else if (clickedToolStripItem == this.toolStripMenuItemExit)
            {
                this.RaiseToolStripMenuItemClicked(this.ExitClicked, EventArgs.Empty);
            }
        }

        private void RaiseToolStripMenuItemClicked(EventHandler handler, EventArgs e)
        {
            if (handler != null)
            {
                handler(this, e);
            }
        }
    }
}

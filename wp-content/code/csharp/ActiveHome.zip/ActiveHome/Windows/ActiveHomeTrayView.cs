﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Be.TimVW.ActiveHome.Library;

namespace Be.TimVW.ActiveHome.Windows
{
    public class ActiveHomeTrayView : ITrayView
    {
        public event EventHandler MenuClicked;
        public event EventHandler ExitClicked;

        private ITrayView trayView;

        public ActiveHomeTrayView(ITrayView trayView)
        {
            this.trayView = trayView;
            this.trayView.MenuClicked += this.trayView_MenuClicked;
            this.trayView.ExitClicked += this.trayView_ExitClicked;

            Notifier.Instance.NotificationReceived += this.Instance_NotificationReceived;
            Notifier.Instance.Enable();
        }

        public void Close()
        {
            Notifier.Instance.NotificationReceived -= this.Instance_NotificationReceived;
            Notifier.Instance.Disable();

            this.trayView.MenuClicked -= this.trayView_MenuClicked;
            this.trayView.ExitClicked -= this.trayView_ExitClicked;
            this.trayView.Close();
            this.trayView = null;
        }

        private void Instance_NotificationReceived(object sender, NotificationReceivedEventArgs e)
        {
            RadioFrequencyNotification rfNotification = e.Notification as RadioFrequencyNotification;
            if (rfNotification.IsKeyPressed)
            {
                if (rfNotification.Command == RadioFrequencyCommand.Menu)
                {
                    this.RaiseToolStripMenuItemClicked(this.MenuClicked, EventArgs.Empty);
                }
            }
        }

        private void trayView_MenuClicked(object sender, EventArgs e)
        {
            this.RaiseToolStripMenuItemClicked(this.MenuClicked, e);
        }

        private void trayView_ExitClicked(object sender, EventArgs e)
        {
            this.RaiseToolStripMenuItemClicked(this.ExitClicked, e);
        }

        private void RaiseToolStripMenuItemClicked(EventHandler handler, EventArgs e)
        {
            if (handler != null)
            {
                handler(this, e);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ActiveHomeScriptLib;

namespace Be.TimVW.ActiveHome.Library
{
    public class Notifier : INotifier
    {


        private static Notifier instance = new Notifier();

        public static Notifier Instance
        {
            get { return instance; }
        }

        private object lockObject;
        public event EventHandler<NotificationReceivedEventArgs> NotificationReceived;

        private ActiveHomeClass activeHomeClass;

        private Notifier()
        {
            this.lockObject = new object();

            this.activeHomeClass = new ActiveHomeClass();
            this.activeHomeClass.RecvAction += new _DIActiveHomeEvents_RecvActionEventHandler(activeHomeClass_RecvAction);
        }

        public void Enable()
        {
            lock (this.lockObject)
            {
                if (this.activeHomeClass == null)
                {
                    this.activeHomeClass = new ActiveHomeClass();
                    this.activeHomeClass.RecvAction += this.activeHomeClass_RecvAction;
                }
            }
        }

        public void Disable()
        {
            lock (this.lockObject)
            {
                if (this.activeHomeClass != null)
                {
                    this.activeHomeClass.RecvAction -= this.activeHomeClass_RecvAction;
                    this.activeHomeClass = null;
                }
            }
        }

        private void activeHomeClass_RecvAction(object recvAction, object x10Address, object code, object bszParm3, object bszParm4, object bszParm5, object bszReserved)
        {
            Notification notification = NotificationFactory.Instance.GetNotification(recvAction, x10Address, code, bszParm3, bszParm4, bszParm5, bszReserved);
            this.RaiseNotificationReceived(new NotificationReceivedEventArgs(notification));
        }

        private void RaiseNotificationReceived(NotificationReceivedEventArgs e)
        {
            EventHandler<NotificationReceivedEventArgs> handler = this.NotificationReceived;
            if (handler != null)
            {
                handler(this, e);
            }
        }
    }
}

﻿using System;
namespace Be.TimVW.ActiveHome.Library
{
    public interface INotifier
    {
        event EventHandler<NotificationReceivedEventArgs> NotificationReceived;
        void Enable();
        void Disable();
    }
}

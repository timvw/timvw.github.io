﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Be.TimVW.ActiveHome.Library
{
    public class NotificationReceivedEventArgs : EventArgs
    {
        private Notification notification;

        public NotificationReceivedEventArgs(Notification notification)
        {
            this.notification = notification;
        }

        public Notification Notification
        {
            get { return this.notification; }
        }
    }
}

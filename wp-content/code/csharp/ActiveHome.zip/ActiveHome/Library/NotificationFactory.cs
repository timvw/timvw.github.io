﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Be.TimVW.ActiveHome.Library
{
    public class NotificationFactory
    {
        private static NotificationFactory notificationFactory = new NotificationFactory();

        public static NotificationFactory Instance
        {
            get { return notificationFactory; }
        }

        public Notification GetNotification(object recvAction, object x10Address, object command, object bszParm3, object bszParm4, object bszParm5, object bszReserved)
        {
            switch (recvAction.ToString())
            {
                case PowerLineNotification.RecvAction:
                    return new PowerLineNotification(x10Address, command, bszParm3);
                case RadioFrequencyNotification.RecvAction:
                    return new RadioFrequencyNotification(x10Address, command, bszParm3, bszParm4);
                default:
                    throw new ArgumentException("The RecvAction " + recvAction + " is not supported.");
            }
        }
    }
}

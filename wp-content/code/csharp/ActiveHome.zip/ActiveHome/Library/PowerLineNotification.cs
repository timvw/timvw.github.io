﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Be.TimVW.ActiveHome.Library
{
    public class PowerLineNotification : Notification
    {
        public const string RecvAction = "recvplc";

        private PowerLineCommand command;
        private string additionalData;

        public PowerLineNotification(object x10Address, object command, object additionalData)
            : base(x10Address, command)
        {
            this.command = EnumParser.Parse<PowerLineCommand>((string)command);
            this.additionalData = (string)additionalData;
        }

        public PowerLineCommand Command
        {
            get { return this.command; }
        }

        public string AdditionalData
        {
            get { return this.additionalData; }
        }
    }
}

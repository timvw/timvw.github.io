﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Be.TimVW.ActiveHome.Library
{
    public class RadioFrequencyNotification : Notification
    {
        public const string RecvAction = "recvrf";

        private RadioFrequencyCommand command;
        private int sequenceNumber;
        private DateTime timestamp;

        public RadioFrequencyNotification(object x10Address, object command, object sequenceNumber, object timestamp)
            : base(x10Address, command)
        {
            this.command = EnumParser.Parse<RadioFrequencyCommand>((string)command);
            this.sequenceNumber = (int)sequenceNumber;
            this.timestamp = (DateTime)timestamp;
        }

        public RadioFrequencyCommand Command
        {
            get { return this.command; }
        }

        public int SequenceNumber
        {
            get { return this.sequenceNumber; }
        }

        public DateTime Timestamp
        {
            get { return this.timestamp; }
        }

        public bool IsKeyPressed
        {
            get { return this.sequenceNumber == 0; }
        }

        public bool IsKeyReleased
        {
            get { return this.sequenceNumber == -1; }
        }
    }
}

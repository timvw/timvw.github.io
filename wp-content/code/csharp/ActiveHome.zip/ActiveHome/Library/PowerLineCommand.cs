﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Be.TimVW.ActiveHome.Library
{
    public enum PowerLineCommand
    {
        AllOn,
        AllOff,
        AllLightsOff,
        On,
        Off,
        Bright,
        Dim
    }
}

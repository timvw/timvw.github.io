﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Be.TimVW.ActiveHome.Library
{
    public class Notification
    {
        private X10Address x10Address;
        private string rawCommand;

        public Notification(object x10Address, object command)
        {
            this.x10Address = EnumParser.Parse<X10Address>((string)x10Address);
            this.rawCommand = (string)command;
        }

        public X10Address X10Address
        {
            get { return this.x10Address; }
        }

        public string RawCommand
        {
            get { return this.rawCommand; }
        }
    }
}

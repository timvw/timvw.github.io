using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ExtenderProvider
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            SimpleObject simpleObject = new SimpleObject();
            simpleObject.Birthday = DateTime.Now;

            this.dateTimePicker1.DataBindings.Add("Value", simpleObject, "Birthday");
            this.textBox1.DataBindings.Add("Text", simpleObject, "Birthday", true, DataSourceUpdateMode.OnPropertyChanged);
        }
    }

    public class SimpleObject : INotifyPropertyChanged
    {
        private DateTime birthday;

        public event PropertyChangedEventHandler PropertyChanged;

        public DateTime Birthday
        {
            get { return this.birthday; }
            set
            {
                this.birthday = value;
                this.OnPropertyChanged("Birthday");
            }
        }

        private void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
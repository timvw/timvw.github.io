using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Windows.Forms;

namespace ExtenderProvider
{
    [ProvideProperty("WriteValuesAfterCloseUp", typeof(DateTimePicker))]
    [ProvideProperty("WriteValuesAfterSelectionChangeCommitted", typeof(ComboBox))]
    class WriteValueAfterEventExtender : Component, IExtenderProvider
    {
        private Dictionary<DateTimePicker, bool> writeValuesAfterCloseUp;
        private Dictionary<ComboBox, bool> writeValuesAfterSelectionChangeCommitted;

        public WriteValueAfterEventExtender()
        {
            this.writeValuesAfterCloseUp = new Dictionary<DateTimePicker, bool>();
            this.writeValuesAfterSelectionChangeCommitted = new Dictionary<ComboBox, bool>();
        }

        public bool CanExtend(object extendee)
        {
            return extendee is DateTimePicker || extendee is ComboBox;
        }

        #region WriteValuesAfterCloseUp

        [Description("Gets a boolean indicating if the values are written to the datasource after a CloseUp event.")]
        public bool GetWriteValuesAfterCloseUp(DateTimePicker dateTimePicker)
        {
            bool value;
            if (!this.writeValuesAfterCloseUp.TryGetValue(dateTimePicker, out value))
            {
                value = false;
            }
            return value;
        }

        public void SetWriteValuesAfterCloseUp(DateTimePicker dateTimePicker, bool value)
        {
            if (this.writeValuesAfterCloseUp.ContainsKey(dateTimePicker))
            {
                this.writeValuesAfterCloseUp[dateTimePicker] = value;
            }
            else
            {
                this.writeValuesAfterCloseUp.Add(dateTimePicker, value);
            }

            if (value)
            {
                dateTimePicker.CloseUp += this.dateTimePicker_CloseUp;
            }
            else
            {
                dateTimePicker.CloseUp -= this.dateTimePicker_CloseUp;
            }
        }

        private void dateTimePicker_CloseUp(object sender, EventArgs e)
        {
            DateTimePicker dateTimePicker = sender as DateTimePicker;
            if (dateTimePicker != null)
            {
                foreach (Binding binding in dateTimePicker.DataBindings)
                {
                    binding.WriteValue();
                }
            }
        }

        #endregion

        #region WriteValuesAfterSelectionChangeCommitted

        [Description("Gets a boolean indicating if the values are written to the datasource after a SelectionChangeCommitted event.")]
        public bool GetWriteValuesAfterSelectionChangeCommitted(ComboBox comboBox)
        {
            bool value;
            if (!this.writeValuesAfterSelectionChangeCommitted.TryGetValue(comboBox, out value))
            {
                value = false;
            }
            return value;
        }

        public void SetWriteValuesAfterSelectionChangeCommitted(ComboBox comboBox, bool value)
        {
            if (this.writeValuesAfterSelectionChangeCommitted.ContainsKey(comboBox))
            {
                this.writeValuesAfterSelectionChangeCommitted[comboBox] = value;
            }
            else
            {
                this.writeValuesAfterSelectionChangeCommitted.Add(comboBox, value);
            }

            if (value)
            {
                comboBox.SelectionChangeCommitted += this.comboBox_SelectionChangeCommitted;
            }
            else
            {
                comboBox.SelectionChangeCommitted -= this.comboBox_SelectionChangeCommitted;
            }
        }

        void comboBox_SelectionChangeCommitted(object sender, EventArgs e)
        {
            ComboBox comboBox = sender as ComboBox;
            if (comboBox != null)
            {
                foreach (Binding binding in comboBox.DataBindings)
                {
                    binding.WriteValue();
                }
            }
        }

        #endregion
    }
}

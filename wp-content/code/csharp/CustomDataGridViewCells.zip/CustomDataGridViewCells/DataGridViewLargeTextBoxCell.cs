using System.Drawing;
using System.Windows.Forms;

namespace VanWassenhove.CustomDataGridViewCell
{
    /// <summary>
    /// This class represents a TextBoxCell that spans multiple columns.
    /// </summary>
    public class DataGridViewLargeTextBoxCell : DataGridViewTextBoxCell
    {
        #region Fields

        private int columnSpan;

        #endregion

        #region Properties

        /// <summary>
        /// Gets and sets the number of columns this DataGridViewCell spans.
        /// </summary>
        public int ColumnSpan
        {
            get { return this.columnSpan; }
            set { this.columnSpan = value; }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        public DataGridViewLargeTextBoxCell()
            : base()
        {
            this.columnSpan = 1;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="columnSpan">The number of columns this DataGridViewCell spans.</param>
        public DataGridViewLargeTextBoxCell(int columnSpan)
            : base()
        {
            this.columnSpan = columnSpan;
        }

        #endregion

        #region overrides

        protected override void OnDataGridViewChanged()
        {
            base.OnDataGridViewChanged();
            if (this.DataGridView != null)
            {
                this.DataGridView.CellPainting += this.DataGridView_CellPainting;
            }
        }

        public override void PositionEditingControl(bool setLocation, bool setSize, Rectangle cellBounds, Rectangle cellClip, DataGridViewCellStyle cellStyle, bool singleVerticalBorderAdded, bool singleHorizontalBorderAdded, bool isFirstDisplayedColumn, bool isFirstDisplayedRow)
        {
            cellBounds.Width = cellBounds.Width * this.columnSpan;
            cellClip.Width = cellClip.Width * this.columnSpan;
            base.PositionEditingControl(setLocation, setSize, cellBounds, cellClip, cellStyle, singleVerticalBorderAdded, singleHorizontalBorderAdded, isFirstDisplayedColumn, isFirstDisplayedRow);
        }

        public override void DetachEditingControl()
        {
            base.DetachEditingControl();
            this.DataGridView.InvalidateCell(this);
        }

        #endregion

        #region EventHandlers

        protected virtual void DataGridView_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex == this.RowIndex)
            {
                if (e.ColumnIndex >= this.ColumnIndex && e.ColumnIndex < this.ColumnIndex + this.columnSpan)
                {
                    Rectangle displayRectangle = this.DataGridView.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
                    displayRectangle.X -= (this.OwningColumn.Width - displayRectangle.Width);
                    displayRectangle.X -= (e.ColumnIndex - this.ColumnIndex) * this.OwningColumn.Width;
                    displayRectangle.Width = this.OwningColumn.Width * this.columnSpan;

                    int stringX = displayRectangle.X + 1;
                    int stringY = displayRectangle.Y + ((this.OwningRow.Height - this.InheritedStyle.Font.Height) / 2);

                    if (this.DataGridView.RowHeadersVisible)
                    {
                        if (displayRectangle.X < this.DataGridView.RowHeadersWidth)
                        {
                            displayRectangle.Width -= (this.DataGridView.RowHeadersWidth - displayRectangle.X);
                            displayRectangle.X = this.DataGridView.RowHeadersWidth + 1;
                        }
                    }
                    else
                    {
                        if (displayRectangle.X < 0)
                        {
                            displayRectangle.Width -= (0 - displayRectangle.X);
                            displayRectangle.X = 1;
                        }
                    }
                    RectangleF oldClip = e.Graphics.ClipBounds;
                    e.Graphics.SetClip(displayRectangle);

                    Brush foreBrush = null;
                    Brush backBrush = null;

                    try
                    {
                        if (this.Selected)
                        {
                            foreBrush = new SolidBrush(this.InheritedStyle.SelectionForeColor);
                            backBrush = new SolidBrush(this.InheritedStyle.SelectionBackColor);
                        }
                        else
                        {
                            foreBrush = new SolidBrush(this.InheritedStyle.ForeColor);
                            backBrush = new SolidBrush(this.InheritedStyle.BackColor);
                        }

                        e.Graphics.FillRectangle(backBrush, displayRectangle);
                        e.Graphics.DrawString(this.FormattedValue.ToString(), this.InheritedStyle.Font, foreBrush, stringX, stringY);
                        e.Graphics.DrawLine(Pens.Black, displayRectangle.X, displayRectangle.Bottom - 1, displayRectangle.Right, displayRectangle.Bottom - 1);
                        e.Graphics.DrawLine(Pens.Black, displayRectangle.Right - 1, displayRectangle.Y - 1, displayRectangle.Right - 1, displayRectangle.Bottom + 1);
                    }
                    finally
                    {
                        if (foreBrush != null)
                        {
                            foreBrush.Dispose();
                        }
                        if (backBrush != null)
                        {
                            backBrush.Dispose();
                        }
                    }

                    e.Graphics.SetClip(oldClip);

                    e.Handled = true;
                }
            }
        }

        #endregion
    }
}

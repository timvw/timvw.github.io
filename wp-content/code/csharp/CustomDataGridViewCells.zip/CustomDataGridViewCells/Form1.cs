using System.Windows.Forms;

namespace VanWassenhove.CustomDataGridViewCell
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.dataGridView1.ColumnCount = 30;
            this.dataGridView1.RowCount = 20;

            this.dataGridView1[1, 1] = new DataGridViewLargeTextBoxCell(2);
            this.dataGridView1[1, 1].Value = "abcdefghijklmnopqrstuvwxyz";
        }
    }
}
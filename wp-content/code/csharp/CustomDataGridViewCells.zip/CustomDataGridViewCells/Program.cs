using System;
using System.Windows.Forms;

namespace VanWassenhove.CustomDataGridViewCell
{
    class Program
    {
        [STAThreadAttribute()]
        public static void Main()
        {
            Application.Run(new Form1());
        }
    }
}
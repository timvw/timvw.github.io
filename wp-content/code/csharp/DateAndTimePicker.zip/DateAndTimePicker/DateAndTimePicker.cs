using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace VanWassenhove.Controls
{
    public partial class DateAndTimePicker : UserControl
    {
        public DateAndTimePicker()
        {
            InitializeComponent();
        }

        public DateTime Value
        {
            get
            {
                DateTime date = this.dateTimePicker1.Value;
                DateTime time = this.dateTimePicker2.Value;
                return new DateTime(date.Year, date.Month, date.Day, time.Hour, time.Minute, time.Second);
            }
            set
            {
                this.dateTimePicker1.Value = value;
                this.dateTimePicker2.Value = value;
            }
        }
    }
}
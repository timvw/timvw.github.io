using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace VanWassenhove.Controls
{
    public partial class NullableDateTimePicker : UserControl, INotifyPropertyChanged
    {
        #region Private Fields
        private event PropertyChangedEventHandler propertyChanged;
        #endregion

        #region Constructor
        public NullableDateTimePicker()
        {
            InitializeComponent();
        }
        #endregion

        #region Private Methods
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = this.propertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        #region Private EventHandlers
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
            {
                this.dateAndTimePicker1.Visible = false;
            }
            else
            {
                this.dateAndTimePicker1.Value = DateTime.Now;
                this.dateAndTimePicker1.Visible = true;
            }

            this.OnPropertyChanged("Value");
        }
        #endregion

        #region Public Properties
        public event PropertyChangedEventHandler PropertyChanged
        {
            add { this.propertyChanged += value; }
            remove { this.propertyChanged -= value; }
        }

        public Nullable<DateTime> Value
        {
            get
            {
                if (this.checkBox1.Checked)
                {
                    return null;
                }
                else
                {
                    return this.dateAndTimePicker1.Value;
                }
            }
            set
            {
                if (value.HasValue)
                {
                    this.dateAndTimePicker1.Value = value.Value;
                }
                else
                {
                    this.checkBox1.Checked = true;
                }

                this.OnPropertyChanged("Value");
            }
        }
        #endregion
    }
}

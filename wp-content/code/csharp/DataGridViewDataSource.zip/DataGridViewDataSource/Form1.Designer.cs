namespace DataGridViewDataSource
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ColumnRegion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnButton = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ColumnQ1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnQ2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnQ3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnQ4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnRegion,
            this.ColumnButton,
            this.ColumnQ1,
            this.ColumnQ2,
            this.ColumnQ3,
            this.ColumnQ4,
            this.ColumnYear});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(421, 138);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            // 
            // ColumnRegion
            // 
            this.ColumnRegion.HeaderText = "REGION";
            this.ColumnRegion.Name = "ColumnRegion";
            // 
            // ColumnButton
            // 
            this.ColumnButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ColumnButton.HeaderText = "+";
            this.ColumnButton.Name = "ColumnButton";
            this.ColumnButton.ReadOnly = true;
            this.ColumnButton.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnButton.Width = 20;
            // 
            // ColumnQ1
            // 
            this.ColumnQ1.HeaderText = "Q1";
            this.ColumnQ1.Name = "ColumnQ1";
            this.ColumnQ1.Visible = false;
            this.ColumnQ1.Width = 50;
            // 
            // ColumnQ2
            // 
            this.ColumnQ2.HeaderText = "Q2";
            this.ColumnQ2.Name = "ColumnQ2";
            this.ColumnQ2.Visible = false;
            this.ColumnQ2.Width = 50;
            // 
            // ColumnQ3
            // 
            this.ColumnQ3.HeaderText = "Q3";
            this.ColumnQ3.Name = "ColumnQ3";
            this.ColumnQ3.Visible = false;
            this.ColumnQ3.Width = 50;
            // 
            // ColumnQ4
            // 
            this.ColumnQ4.HeaderText = "Q4";
            this.ColumnQ4.Name = "ColumnQ4";
            this.ColumnQ4.Visible = false;
            this.ColumnQ4.Width = 50;
            // 
            // ColumnYear
            // 
            this.ColumnYear.HeaderText = "YEAR";
            this.ColumnYear.Name = "ColumnYear";
            this.ColumnYear.Width = 50;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 138);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnRegion;
        private System.Windows.Forms.DataGridViewButtonColumn ColumnButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnQ1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnQ2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnQ3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnQ4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnYear;
    }
}


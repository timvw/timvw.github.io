using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DataGridViewDataSource
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.dataGridView1.AutoGenerateColumns = false;
            this.ColumnRegion.DataPropertyName = "Label";
            this.ColumnQ1.DataPropertyName = "Q1";
            this.ColumnQ2.DataPropertyName = "Q2";
            this.ColumnQ3.DataPropertyName = "Q3";
            this.ColumnQ4.DataPropertyName = "Q4";
            this.ColumnYear.DataPropertyName = "Year";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BindingList<SalesRow> bindingList = new BindingList<SalesRow>();
            bindingList.Add(new SalesRow("EMEA", new int[] { 100, 100, 100, 100 }));
            bindingList.Add(new SalesRow("LATAM", new int[] { 150, 150, 150, 150 }));
            bindingList.Add(new SalesRow("APAC", new int[] { 100, 100, 100, 100 }));
            bindingList.Add(new SalesRow("NORAM", new int[] { 150, 150, 150, 150 }));

            SalesRows salesRows = new SalesRows(bindingList);
            this.dataGridView1.DataBindingComplete += this.dataGridView1_DataBindingComplete;
            this.dataGridView1.DataMember = "Rows";
            this.dataGridView1.DataSource = salesRows;
     }

        void dataGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            this.dataGridView1.DataBindingComplete -= this.dataGridView1_DataBindingComplete;

            SalesRows salesRows = this.dataGridView1.DataSource as SalesRows;
            if (salesRows != null)
            {
                int? buttonRowIndex;
                List<int> salesRowIndices;

                if (this.TryGetRows(out buttonRowIndex, out salesRowIndices))
                {
                    this.dataGridView1.Rows[buttonRowIndex.Value].HeaderCell.Value = "+";
                    foreach (int salesRowIndex in salesRowIndices)
                    {
                        this.dataGridView1.Rows[salesRowIndex].Visible = false;
                    }
                }
            }
        }

        private bool TryGetRows(out int? buttonRowIndex, out List<int> salesRowIndices)
        {
            buttonRowIndex = null;
            salesRowIndices = null;

            SalesRows salesRows = this.dataGridView1.DataSource as SalesRows;
            if (salesRows != null)
            {
                buttonRowIndex = -1;
                salesRowIndices = new List<int>();

                for (int rowIndex = 0; rowIndex < this.dataGridView1.RowCount; ++rowIndex)
                {
                    if (salesRows.Rows[rowIndex] is GlobalSalesRow)
                    {
                        break;
                    }
                    else if (salesRows.Rows[rowIndex] is ButtonRow)
                    {
                        for (int columnIndex = 0; columnIndex < this.dataGridView1.ColumnCount; ++columnIndex)
                        {
                            this.dataGridView1[columnIndex, rowIndex] = new DataGridViewButtonCell();
                        }
                        buttonRowIndex = rowIndex;
                    }
                    else
                    {
                        salesRowIndices.Add(rowIndex);
                    }
                }
            }

            return buttonRowIndex != null;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == this.ColumnButton.Index)
            {
                bool visible = !this.ColumnQ1.Visible;
                this.ColumnQ1.Visible = visible;
                this.ColumnQ2.Visible = visible;
                this.ColumnQ3.Visible = visible;
                this.ColumnQ4.Visible = visible;
                this.ColumnButton.HeaderText = visible ? "-" : "+";
            }

            SalesRows salesRows = this.dataGridView1.DataSource as SalesRows;
            if (salesRows != null)
            {
                int? buttonRowIndex;
                List<int> salesRowIndices;

                if (this.TryGetRows(out buttonRowIndex, out salesRowIndices))
                {
                    if (e.RowIndex == buttonRowIndex.Value)
                    {
                        bool visible = this.dataGridView1.Rows[buttonRowIndex.Value].HeaderCell.Value.ToString() == "+";
                        foreach (int salesRowIndex in salesRowIndices)
                        {
                            this.dataGridView1.Rows[salesRowIndex].Visible = visible;
                        }
                        this.dataGridView1.Rows[buttonRowIndex.Value].HeaderCell.Value = visible ? "-" : "+";
                    }
                }
            }
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            SalesRows salesRows = this.dataGridView1.DataSource as SalesRows;
            if (salesRows != null)
            {
                ButtonRow buttonRow = salesRows.Rows[e.RowIndex] as ButtonRow;
                if (buttonRow != null)
                {
                    if (e.ColumnIndex > 1)
                    {
                        e.Value = string.Empty;
                        e.FormattingApplied = true;
                    }
                }
            }
        }
    }
}
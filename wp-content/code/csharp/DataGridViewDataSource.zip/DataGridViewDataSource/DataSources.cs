using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace DataGridViewDataSource
{
    #region Class SalesRow

    public class SalesRow : INotifyPropertyChanged
    {
        #region Private Fields
        private event PropertyChangedEventHandler propertyChanged;
        private string label;
        private int[] values;
        #endregion

        #region Constructors
        public SalesRow()
        {
            this.label = "";
            this.values = new int[4];
        }

        public SalesRow(string label, int[] values)
        {
            if (values == null)
            {
                throw new ArgumentNullException();
            }

            if (values.Length != 4)
            {
                throw new ArgumentException();
            }

            this.label = label;
            this.values = values;
        }
        #endregion

        #region Public Events
        public virtual event PropertyChangedEventHandler PropertyChanged
        {
            add { this.propertyChanged += value; }
            remove { this.propertyChanged -= value; }
        }
        #endregion

        #region Private Methods
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = this.propertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        #region Public Properties
        public virtual string Label
        {
            get { return this.label; }
            set
            {
                if (this.label != value)
                {
                    this.label = value;
                    this.OnPropertyChanged("Label");
                }
            }
        }

        public virtual int Q1
        {
            get { return this.values[0]; }
            set
            {
                if (this.values[0] != value)
                {
                    this.values[0] = value;
                    this.OnPropertyChanged("Q1");
                    this.OnPropertyChanged("Year");
                }
            }
        }

        public virtual int Q2
        {
            get { return this.values[1]; }
            set
            {
                if (this.values[1] != value)
                {
                    this.values[1] = value;
                    this.OnPropertyChanged("Q2");
                    this.OnPropertyChanged("Year");
                }
            }
        }

        public virtual int Q3
        {
            get { return this.values[2]; }
            set
            {
                if (this.values[2] != value)
                {
                    this.values[2] = value;
                    this.OnPropertyChanged("Q3");
                    this.OnPropertyChanged("Year");
                }
            }
        }

        public virtual int Q4
        {
            get { return this.values[3]; }
            set
            {
                if (this.values[3] != value)
                {
                    this.values[3] = value;
                    this.OnPropertyChanged("Q4");
                    this.OnPropertyChanged("Year");
                }
            }
        }

        public virtual int Year
        {
            get
            {
                int sum = 0;
                foreach (int value in values)
                {
                    sum += value;
                }
                return sum;
            }
        }
        #endregion
    }

    #endregion

    #region Class GlobalSalesRow

    public class GlobalSalesRow : SalesRow
    {
        #region Private Fields

        private BindingList<SalesRow> salesRows;

        #endregion

        #region Constructors

        public GlobalSalesRow(string label, BindingList<SalesRow> salesRows)
        {
            if (label == null || salesRows == null)
            {
                throw new ArgumentNullException();
            }

            this.Label = label;
            this.salesRows = salesRows;
            this.salesRows.RaiseListChangedEvents = true;
            this.salesRows.ListChanged += new ListChangedEventHandler(salesRows_ListChanged);
        }

        #endregion

        #region Private Methods
        private void salesRows_ListChanged(object sender, ListChangedEventArgs e)
        {
            this.OnPropertyChanged(e.PropertyDescriptor.Name);
        }
        #endregion

        #region Public Properties
        public override int Q1
        {
            get
            {
                int sum = 0;
                foreach (SalesRow salesRow in this.salesRows)
                {
                    sum += salesRow.Q1;
                }
                return sum;
            }
        }

        public override int Q2
        {
            get
            {
                int sum = 0;
                foreach (SalesRow salesRow in this.salesRows)
                {
                    sum += salesRow.Q2;
                }
                return sum;
            }
        }

        public override int Q3
        {
            get
            {
                int sum = 0;
                foreach (SalesRow salesRow in this.salesRows)
                {
                    sum += salesRow.Q3;
                }
                return sum;
            }
        }

        public override int Q4
        {
            get
            {
                int sum = 0;
                foreach (SalesRow salesRow in this.salesRows)
                {
                    sum += salesRow.Q4;
                }
                return sum;
            }
        }

        public override int Year
        {
            get
            {
                int sum = 0;
                foreach (SalesRow salesRow in this.salesRows)
                {
                    sum += salesRow.Year;
                }
                return sum;
            }
        }
        #endregion
    }

    #endregion

    #region Class ButtonRow

    public class ButtonRow : SalesRow
    {
        #region Constructors

        public ButtonRow()
            : base()
        {
            this.Label = "DETAILS";
        }

        #endregion
    }

    #endregion

    #region Class SalesRows

    public class SalesRows
    {
        #region Private Fields

        private BindingList<SalesRow> salesRows;

        #endregion

        #region Constructors

        public SalesRows(BindingList<SalesRow> salesRows)
        {
            if (salesRows == null)
            {
                throw new ArgumentNullException();
            }

            this.salesRows = salesRows;
        }

        #endregion

        #region Public Properties

        public BindingList<SalesRow> Rows
        {
            get
            {
                BindingList<SalesRow> rows = new BindingList<SalesRow>();

                ButtonRow buttonRow = new ButtonRow();
                rows.Add(buttonRow);

                foreach (SalesRow salesRow in this.salesRows)
                {
                    rows.Add(salesRow);
                }

                GlobalSalesRow globalSalesRow = new GlobalSalesRow("GLOBAL", this.salesRows);
                rows.Add(globalSalesRow);

                return rows;
            }
        }

        #endregion
    }

    #endregion
}

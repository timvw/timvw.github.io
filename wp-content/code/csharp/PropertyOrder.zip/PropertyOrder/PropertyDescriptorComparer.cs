using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.ComponentModel;

namespace PropertyOrder
{
    /// <summary>
    /// This class tries to use PropertyOrderAttributes in order to compare PropertyDescriptors.
    /// </summary>
    class PropertyDescriptorComparer : IComparer
    {
        #region IComparer Members

        /// <summary>
        /// Implementation of <see cref="IComparer.Compare"/>
        /// </summary>
        public int Compare(object x, object y)
        {
            if (x == y) return 0;
            if (x == null) return 1;
            if (y == null) return -1;

            PropertyDescriptor propertyDescriptorX = x as PropertyDescriptor;
            PropertyDescriptor propertyDescriptorY = y as PropertyDescriptor;

            PropertyOrderAttribute propertyOrderAttributeX = propertyDescriptorX.Attributes[typeof(PropertyOrderAttribute)] as PropertyOrderAttribute;
            PropertyOrderAttribute propertyOrderAttributeY = propertyDescriptorY.Attributes[typeof(PropertyOrderAttribute)] as PropertyOrderAttribute;

            if (propertyOrderAttributeX == propertyOrderAttributeY) return 0;
            if (propertyOrderAttributeX == null) return 1;
            if (propertyOrderAttributeY == null) return -1;

            return propertyOrderAttributeX.Order.CompareTo(propertyOrderAttributeY.Order);
        }

        #endregion
    }
}

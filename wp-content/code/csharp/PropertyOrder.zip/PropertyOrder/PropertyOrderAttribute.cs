using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyOrder
{
    /// <summary>
    /// This class represents an Attribute that allows the user to specify a specific order to a property.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    class PropertyOrderAttribute : Attribute
    {

        #region Private Fields

        private int order;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="order"></param>
        public PropertyOrderAttribute(int order)
        {
            this.order = order;
        }

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets the order of the related property.
        /// </summary>
        public int Order
        {
            get { return this.order; }
        }

        #endregion
    }
}

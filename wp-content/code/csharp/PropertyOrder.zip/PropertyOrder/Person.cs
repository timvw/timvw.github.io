using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyOrder
{
    /// <summary>
    /// This class represents a Person
    /// </summary>
    class Person
    {
        #region Private Fields

        private int id;
        private string name;
        private DateTime birthDay;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <param name="birthDay"></param>
        public Person(int id, string name, DateTime birthDay)
        {
            this.id = id;
            this.name = name;
            this.birthDay = birthDay;
        }

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets and sets the Identification.
        /// </summary>
        [PropertyOrder(0)]
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Gets and sets the Name.
        /// </summary>
        [PropertyOrder(2)]
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets and sets the day of birth.
        /// </summary>
        [PropertyOrder(1)]
        public DateTime BirthDay
        {
            get { return birthDay; }
            set { birthDay = value; }
        }

        #endregion
    }
}

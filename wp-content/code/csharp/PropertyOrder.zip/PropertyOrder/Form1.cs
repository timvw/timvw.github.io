using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace PropertyOrder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = null;

            Dictionary<string, int> propertyOrders = new Dictionary<string, int>();
            propertyOrders.Add("Id", (int)this.numericUpDownId.Value);
            propertyOrders.Add("BirthDay", (int)this.numericUpDownBirthDay.Value);
            propertyOrders.Add("Name", (int)this.numericUpDownName.Value);

            DictionaryPropertyDescriptorComparer comparer = new DictionaryPropertyDescriptorComparer(propertyOrders);

            PropertyOrderBindingList<Person> persons = new PropertyOrderBindingList<Person>(comparer);

            persons.Add(new Person(1, "Timvw", new DateTime(1980, 4, 30)));
            persons.Add(new Person(2, "Mike", new DateTime(1984, 1, 1)));

            this.dataGridView1.DataSource = persons;
        }
    }
}
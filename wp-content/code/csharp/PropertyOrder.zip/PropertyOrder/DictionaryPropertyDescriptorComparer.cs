using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.ComponentModel;

namespace PropertyOrder
{
    /// <summary>
    /// This class uses a dictionary with pairs of propertyname, sortorder in order to compare.
    /// </summary>
    class DictionaryPropertyDescriptorComparer : IComparer
    {
        #region Private Fields

        private Dictionary<string, int> propertyOrders;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="propertyOrders">The dictionary with property-order pairs to use.</param>
        public DictionaryPropertyDescriptorComparer(Dictionary<string, int> propertyOrders)
        {
            this.propertyOrders = propertyOrders;
        }

        #endregion

        #region IComparer Members

        /// <summary>
        /// Implementation of <see cref="IComparer.Compare"/>
        /// </summary>
        public int Compare(object x, object y)
        {
            if (x == y) return 0;
            if (x == null) return 1;
            if (y == null) return -1;

            PropertyDescriptor propertyDescriptorX = x as PropertyDescriptor;
            PropertyDescriptor propertyDescriptorY = y as PropertyDescriptor;

            int orderX;
            if (!this.propertyOrders.TryGetValue(propertyDescriptorX.Name, out orderX))
            {
                orderX = int.MaxValue;
            }

            int orderY;
            if (!this.propertyOrders.TryGetValue(propertyDescriptorY.Name, out orderY))
            {
                orderY = int.MaxValue;
            }

            return orderX.CompareTo(orderY);
        }

        #endregion
    }
}

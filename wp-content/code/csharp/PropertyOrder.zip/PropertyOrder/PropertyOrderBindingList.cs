using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Collections;

namespace PropertyOrder
{
    /// <summary>
    /// This class represents a BindingList that exposes the properties of it's elements in an order specified by the provided PropertyOrderAttributes.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    class PropertyOrderBindingList<T> : BindingList<T>, ITypedList
    {
        #region Private Fields

        private IComparer comparer;

        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        public PropertyOrderBindingList()
            : this(new PropertyDescriptorComparer())
        {
            //
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="comparer">The comparer to use.</param>
        public PropertyOrderBindingList(IComparer comparer)
            : base()
        {
            this.comparer = comparer;
        }

        #endregion

        #region ITypedList Members

        /// <summary>
        /// Implementation of <see cref="ITypedList.GetItemProperties"/>
        /// </summary>
        public PropertyDescriptorCollection GetItemProperties(PropertyDescriptor[] listAccessors)
        {
            PropertyDescriptorCollection typePropertiesCollection = TypeDescriptor.GetProperties(typeof(T));
            return typePropertiesCollection.Sort(this.comparer);
        }

        /// <summary>
        /// Implementation of <see cref="ITypedList.GetListName"/>
        /// </summary>
        public string GetListName(PropertyDescriptor[] listAccessors)
        {
            return string.Format("A list with Properties for {0}", typeof(T).Name);
        }

        #endregion
    }
}

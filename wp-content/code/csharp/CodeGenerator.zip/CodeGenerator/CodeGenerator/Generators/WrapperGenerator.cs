using System;
using System.IO;
using System.Reflection;
using System.Text;
using Be.Timvw.Framework;

namespace CodeGenerator.Generators
{
    public class WrapperGenerator
    {
        public const string TemplatesPath = "Generators\\WrapperTemplates";
        private static readonly string s_EventTemplate;
        private static readonly string s_PropertyTemplate;
        private static readonly string s_MethodTemplate;
        private static readonly string s_VoidMethodTemplate;
        private static readonly string s_ClassTemplate;

        private static readonly string[] s_SpecialMethodPrefixes;

        public event EventHandler<ItemEventArgs<EventInfo[]>> EventsFound;
        public event EventHandler<ItemEventArgs<PropertyInfo[]>> PropertiesFound;
        public event EventHandler<ItemEventArgs<MethodInfo[]>> MethodsFound;

        static WrapperGenerator()
        {
            s_EventTemplate = File.ReadAllText(Path.Combine(TemplatesPath, "Event.txt"));
            s_PropertyTemplate = File.ReadAllText(Path.Combine(TemplatesPath, "Property.txt"));
            s_MethodTemplate = File.ReadAllText(Path.Combine(TemplatesPath, "Method.txt"));
            s_VoidMethodTemplate = File.ReadAllText(Path.Combine(TemplatesPath, "VoidMethod.txt"));
            s_ClassTemplate = File.ReadAllText(Path.Combine(TemplatesPath, "Class.txt"));

            s_SpecialMethodPrefixes = new string[] { "get_", "set_", "add_", "remove_" };
        }

        public string Generate(Type type)
        {
            if (type == null)
            {
                throw new ArgumentNullException("type");
            }

            string namespaceName = "MyNamespace";
            string className = type.Name + "Wrapper";
            string typeName = TypeHelper.GetCsharpTypeName(type);
            string events = GenerateEvents(type);
            string properties = GenerateProperties(type);
            string methods = GenerateMethods(type);

            return string.Format(s_ClassTemplate, namespaceName, className, typeName, events, properties, methods);
        }

        public virtual string GenerateEvents(Type type)
        {
            StringBuilder eventBuilder = new StringBuilder();

            EventInfo[] typeEvents = type.GetEvents(BindingFlags.Instance | BindingFlags.Public);
            ItemEventArgs<EventInfo[]> args = new ItemEventArgs<EventInfo[]>(typeEvents);
            EventHandlerHelper.Raise(this.EventsFound, this, args);
            EventInfo[] filteredEvents = args.Item;

            foreach (EventInfo eventInfo in filteredEvents)
            {
                string eventType = TypeHelper.GetCsharpTypeName(eventInfo.EventHandlerType);
                string eventName = eventInfo.Name;
                eventBuilder.AppendFormat(s_EventTemplate, eventType, eventName);
                eventBuilder.AppendLine();
            }

            return eventBuilder.ToString();
        }

        public virtual string GenerateProperties(Type type)
        {
            PropertyInfo[] typeProperties = type.GetProperties(BindingFlags.Instance | BindingFlags.Public);
            ItemEventArgs<PropertyInfo[]> args = new ItemEventArgs<PropertyInfo[]>(typeProperties);
            EventHandlerHelper.Raise(this.PropertiesFound, this, args);
            PropertyInfo[] filteredProperties = args.Item;

            StringBuilder propertyBuilder = new StringBuilder();
            foreach (PropertyInfo propertyInfo in filteredProperties)
            {
                string propertyType = TypeHelper.GetCsharpTypeName(propertyInfo.GetGetMethod().ReturnType);
                string propertyName = propertyInfo.Name;
                propertyBuilder.AppendFormat(s_PropertyTemplate, propertyType, propertyName);
                propertyBuilder.AppendLine();
            }

            return propertyBuilder.ToString();
        }

        public virtual string GenerateMethods(Type type)
        {
            MethodInfo[] typeMethods = type.GetMethods(BindingFlags.Instance | BindingFlags.Public);
            ItemEventArgs<MethodInfo[]> args = new ItemEventArgs<MethodInfo[]>(typeMethods);
            EventHandlerHelper.Raise(this.MethodsFound, this, args);
            MethodInfo[] filteredMethods = args.Item;

            StringBuilder methodBuilder = new StringBuilder();
            foreach (MethodInfo methodInfo in filteredMethods)
            {
                string methodName = methodInfo.Name;
                if (!Array.Exists(s_SpecialMethodPrefixes, delegate(string specialMethodPrefix)
                {
                    return methodName.StartsWith(specialMethodPrefix);
                }))
                {
                    string methodType = TypeHelper.GetCsharpTypeName(methodInfo.ReturnType);
                    string methodParameters = GenerateParameters(methodInfo);

                    if (methodInfo.ReturnType == typeof(void))
                    {
                        methodBuilder.AppendFormat(s_VoidMethodTemplate, methodName, methodParameters);
                    }
                    else
                    {
                        methodBuilder.AppendFormat(s_MethodTemplate, methodType, methodName, methodParameters);
                    }

                    methodBuilder.AppendLine();
                }
            }

            return methodBuilder.ToString();
        }

        public virtual string GenerateParameters(MethodInfo methodInfo)
        {
            StringBuilder parameterBuilder = new StringBuilder();

            ParameterInfo[] parameterInfos = methodInfo.GetParameters();
            for (int i = 0; i < parameterInfos.Length; ++i)
            {
                string parameterOut = parameterInfos[i].IsOut ? "out " : string.Empty;
                string parameterName = parameterInfos[i].Name;
                parameterBuilder.AppendFormat("{0}{1}", parameterOut, parameterName);

                if (i < parameterInfos.Length - 1)
                {
                    parameterBuilder.Append(", ");
                }
            }

            return parameterBuilder.ToString();
        }
    }
}

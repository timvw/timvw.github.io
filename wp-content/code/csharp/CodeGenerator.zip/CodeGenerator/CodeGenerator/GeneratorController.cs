using System;
using System.Reflection;
using System.Windows.Forms;
using CodeGenerator.Generators;
using Be.Timvw.Framework;

namespace CodeGenerator
{
    public class GeneratorController
    {
        public GeneratorController(GeneratorView view)
        {
            view.GenerateInterfaceRequested += this.view_GenerateInterfaceRequested;
            view.GenerateWrapperRequested += this.view_GenerateWrapperRequested;
        }

        public virtual void view_GenerateInterfaceRequested(object sender, ItemEventArgs<Type> e)
        {
            Type selectedType = e.Item;
            InterfaceGenerator generator = new InterfaceGenerator();
            string generatedInterface = generator.Generate(selectedType);

            Clipboard.SetText(generatedInterface);

            GeneratorView view = (GeneratorView)sender;
            view.DisplayMessage("Interface has been generated and copied to Clipboard.");
        }

        public virtual void view_GenerateWrapperRequested(object sender, ItemEventArgs<Type> e)
        {
            Type selectedType = e.Item;
            WrapperGenerator generator = new WrapperGenerator();
            string generatedWrapper = generator.Generate(selectedType);

            Clipboard.SetText(generatedWrapper);

            GeneratorView view = (GeneratorView)sender;
            view.DisplayMessage("Wrapper has been generated and copied to Clipboard.");
        }
    }
}

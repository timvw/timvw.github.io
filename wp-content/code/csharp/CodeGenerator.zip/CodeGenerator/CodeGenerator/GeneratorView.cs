using System;
using System.Reflection;
using System.Windows.Forms;
using Be.Timvw.Framework;

namespace CodeGenerator
{
    public partial class GeneratorView : Form
    {
        public event EventHandler<ItemEventArgs<Type>> GenerateInterfaceRequested;
        public event EventHandler<ItemEventArgs<Type>> GenerateWrapperRequested;

        public GeneratorView()
        {
            InitializeComponent();
        }

        public virtual Assembly SelectedAssembly
        {
            get { return this.assemblyTypePicker1.SelectedAssembly; }
            set { this.assemblyTypePicker1.SelectedAssembly = value; }
        }

        public virtual Type SelectedType
        {
            get { return this.assemblyTypePicker1.SelectedType; }
            set { this.assemblyTypePicker1.SelectedType = value; }
        }

        public virtual void DisplayMessage(string text)
        {
            MessageBox.Show(text);
        }

        private void assemblyTypePicker1_TypesFound(object sender, ItemEventArgs<Type[]> e)
        {
            e.Item = Array.FindAll(e.Item, delegate(Type aType)
            {
                return aType.IsAbstract && !aType.IsInterface;
            });
        }

        private void buttonGenerateInterface_Click(object sender, EventArgs e)
        {
            Type selectedType = this.SelectedType;
            if (selectedType != null)
            {
                ItemEventArgs<Type> args = new ItemEventArgs<Type>(selectedType);
                EventHandlerHelper.Raise(this.GenerateInterfaceRequested, this, args);
            }
            else
            {
                this.DisplayMessage("Could not generate Interface because no Type is selected.");
            }
        }

        private void buttonGenerateWrapper_Click(object sender, EventArgs e)
        {
            Type selectedType = this.SelectedType;
            if (selectedType != null)
            {
                ItemEventArgs<Type> args = new ItemEventArgs<Type>(selectedType);
                EventHandlerHelper.Raise(this.GenerateWrapperRequested, this, args);
            }
            else
            {
                this.DisplayMessage("Could not generate Wrapper because no Type is selected.");
            }
        }
    }
}
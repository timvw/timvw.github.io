namespace CodeGenerator
{
    partial class GeneratorView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonGenerateWrapper = new System.Windows.Forms.Button();
            this.assemblyTypePicker1 = new Be.Timvw.Framework.Windows.Forms.AssemblyTypePicker();
            this.buttonGenerateInterface = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonGenerateWrapper
            // 
            this.buttonGenerateWrapper.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGenerateWrapper.Location = new System.Drawing.Point(410, 72);
            this.buttonGenerateWrapper.Name = "buttonGenerateWrapper";
            this.buttonGenerateWrapper.Size = new System.Drawing.Size(104, 23);
            this.buttonGenerateWrapper.TabIndex = 1;
            this.buttonGenerateWrapper.Text = "Generate Wrapper";
            this.buttonGenerateWrapper.UseVisualStyleBackColor = true;
            this.buttonGenerateWrapper.Click += new System.EventHandler(this.buttonGenerateWrapper_Click);
            // 
            // assemblyTypePicker1
            // 
            this.assemblyTypePicker1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.assemblyTypePicker1.Location = new System.Drawing.Point(12, 12);
            this.assemblyTypePicker1.MinimumSize = new System.Drawing.Size(111, 64);
            this.assemblyTypePicker1.Name = "assemblyTypePicker1";
            this.assemblyTypePicker1.SelectedAssembly = null;
            this.assemblyTypePicker1.SelectedType = null;
            this.assemblyTypePicker1.Size = new System.Drawing.Size(502, 64);
            this.assemblyTypePicker1.TabIndex = 0;
            this.assemblyTypePicker1.TypesFound += new System.EventHandler<Be.Timvw.Framework.ItemEventArgs<System.Type[]>>(this.assemblyTypePicker1_TypesFound);
            // 
            // buttonGenerateInterface
            // 
            this.buttonGenerateInterface.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGenerateInterface.Location = new System.Drawing.Point(297, 72);
            this.buttonGenerateInterface.Name = "buttonGenerateInterface";
            this.buttonGenerateInterface.Size = new System.Drawing.Size(107, 23);
            this.buttonGenerateInterface.TabIndex = 2;
            this.buttonGenerateInterface.Text = "Generate Interface";
            this.buttonGenerateInterface.UseVisualStyleBackColor = true;
            this.buttonGenerateInterface.Click += new System.EventHandler(this.buttonGenerateInterface_Click);
            // 
            // GeneratorView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(526, 107);
            this.Controls.Add(this.buttonGenerateInterface);
            this.Controls.Add(this.buttonGenerateWrapper);
            this.Controls.Add(this.assemblyTypePicker1);
            this.Name = "GeneratorView";
            this.Text = "Code Generator";
            this.ResumeLayout(false);

        }

        #endregion

        private Be.Timvw.Framework.Windows.Forms.AssemblyTypePicker assemblyTypePicker1;
        private System.Windows.Forms.Button buttonGenerateWrapper;
        private System.Windows.Forms.Button buttonGenerateInterface;
    }
}


﻿using System.Runtime.Remoting.Proxies;
using System.Runtime.Remoting.Messaging;
using System.Reflection;
using System;

namespace Be.TimVW.Tools.DeferredExecution
{
    public class Proxy<T, TResult> : RealProxy
    {
        private Func<T, TResult> func;
        private T funcParameter;
        private TResult funcResult;
        private Type funcResultType;
        private bool deferred;

        public Proxy(Func<T, TResult> func, T funcParameter)
            : base(typeof(TResult))
        {
            this.func = func;
            this.funcParameter = funcParameter;
            this.deferred = true;
        }

        public override IMessage Invoke(IMessage msg)
        {
            if (this.deferred)
            {
                this.funcResult = this.func(this.funcParameter);
                this.funcResultType = this.funcResult.GetType();
                this.deferred = false;
            }

            IMethodCallMessage callMsg = (IMethodCallMessage)msg;
            object result = this.funcResultType.InvokeMember(callMsg.MethodName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.InvokeMethod, null, this.funcResult, callMsg.Args);
            return new ReturnMessage(result, null, 0, callMsg.LogicalCallContext, callMsg);
        }

        public TResult ResultProxy
        {
            get { return (TResult)GetTransparentProxy(); }
        }
    }
}

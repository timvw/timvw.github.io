﻿using System.Collections.Generic;
using System;

namespace Be.TimVW.Tools.DeferredExecution
{
    public static class DeferredExecutionHelper
    {
        public static IList<TResult> GetListHelper<T, TResult>(Func<T, IList<TResult>> costlyFunction, T t)
        {
            return new Proxy<T, IList<TResult>>(costlyFunction, t).ResultProxy;
        }

        public static TResult GetHelper<T, TResult>(Func<T, TResult> costlyFunction, T t) where TResult : MarshalByRefObject
        {
            return new Proxy<T, TResult>(costlyFunction, t).ResultProxy;
        }
    }
}

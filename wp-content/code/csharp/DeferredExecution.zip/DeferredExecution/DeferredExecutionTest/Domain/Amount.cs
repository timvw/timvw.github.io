﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Be.TimVW.Tools.DeferredExecution.Test.Domain
{
    public class Amount : MarshalByRefObject
    {
        private double amount;

        public Amount(double amount)
        {
            this.amount = amount;
        }

        public double Value
        {
            get { return this.amount; }
            set { this.amount = value; }
        }
    }
}

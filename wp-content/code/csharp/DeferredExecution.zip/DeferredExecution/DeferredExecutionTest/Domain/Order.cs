﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Be.TimVW.Tools.DeferredExecution.Test.Domain
{
    public class Order : MarshalByRefObject
    {
        private int id;
        private IList<Amount> amounts;

        public Order(int id, IList<Amount> amounts)
        {
            this.id = id;
            this.amounts = amounts;
        }

        public int Id
        {
            get { return id; }
        }

        public IList<Amount> Amounts
        {
            get { return this.amounts; }
        }
    }
}

﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Be.TimVW.Tools.DeferredExecution.Test.Domain;
using System.Collections;

namespace Be.TimVW.Tools.DeferredExecution.Test
{
    [TestClass]
    public class DeferredExecutionHelperTest
    {
        [TestMethod]
        public void GetListHelperTestDeferredExecution()
        {
            double expectedParameter = 1;
            IList<int> expectedResult = new List<int>(new int[] { 1, 2, 3 });

            IList<int> actualResult = DeferredExecutionHelper.GetListHelper<double, int>(delegate(double actualParameter)
            {
                Assert.AreEqual(expectedParameter, actualParameter);
                Assert.Fail("Should not perform this method.");
                return expectedResult;
            }, expectedParameter);
        }

        [TestMethod]
        public void GetListHelperTestDeferredExecutionResult()
        {
            double expectedParameter = 1;
            IList<int> expectedResult = new List<int>(new int[] { 1, 2, 3 });

            IList<int> actualResult = DeferredExecutionHelper.GetListHelper<double, int>(delegate(double actualParameter)
            {
                Assert.AreEqual(expectedParameter, actualParameter);
                return expectedResult;
            }, expectedParameter);

            Assert.AreEqual(expectedResult.Count, actualResult.Count);
            for (int i = 0; i < expectedResult.Count; ++i)
            {
                Assert.AreEqual(expectedResult[i], actualResult[i]);
            }
        }

        [TestMethod]
        public void GetHelperTestDeferredExecution()
        {
            string expectedParameter = "x";
            Order expectedResult = new Order(1, new List<Amount>(new Amount[] { new Amount(1) }));

            Order actualResult = DeferredExecutionHelper.GetHelper<string, Order>(delegate(string actualParameter)
            {
                Assert.AreEqual(expectedParameter, actualParameter);
                Assert.Fail("Should not perform this method.");
                return expectedResult;
            }, expectedParameter);
        }

        [TestMethod]
        public void GetHelperTestDeferredExecutionResult()
        {
            string expectedParameter = "x";
            Order expectedResult = new Order(1, new List<Amount>(new Amount[] { new Amount(1) }));

            Order actualResult = DeferredExecutionHelper.GetHelper<string, Order>(delegate(string actualParameter)
            {
                Assert.AreEqual(expectedParameter, actualParameter);
                return expectedResult;
            }, expectedParameter);

            Assert.AreEqual(expectedResult.Id, actualResult.Id);
            Assert.AreEqual(expectedResult.Amounts, actualResult.Amounts);
        }
    }
}

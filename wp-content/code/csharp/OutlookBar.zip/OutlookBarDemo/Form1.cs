using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using OutlookBar;

namespace OutlookBarDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.LoadOutlookBarItems();
        }

        private void LoadOutlookBarItems()
        {
            Color itemsColor = Color.Gray;

            Control addressControl = new Panel();
            IOutlookBarItem addressItem = new OutlookBarItem("Address", Resource1.address, itemsColor, addressControl);
            this.outlookBar1.Add(addressItem);

            Control calculatorControl = new Panel();
            IOutlookBarItem calculatorItem = new OutlookBarItem("Calculator", Resource1.calculator, itemsColor, calculatorControl);
            this.outlookBar1.Add(calculatorItem);

            Control relationshipsControl = new RelationShipsControl();
            IOutlookBarItem relationshipsItem = new OutlookBarItem("Relationships", Resource1.relationships, itemsColor, relationshipsControl);
            this.outlookBar1.Add(relationshipsItem);
        }

        private void outlookBar1_ItemClick(object sender, EventArgs e)
        {
            IOutlookBarItem item = sender as IOutlookBarItem;
            this.label1.Text = "Active TaskPanel: " + item.Caption;
        }
    }
}
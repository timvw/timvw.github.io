using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace OutlookBar
{
    public class OutlookBarItem : IOutlookBarItem
    {
        #region Private Fields
        private string caption;
        private Image image;
        private Color imageTransparentColor;
        private Control control;
        #endregion

        #region Constructors
        public OutlookBarItem(string caption, Image image, Color imageTransparentColor, Control control)
        {
            this.caption = caption;
            this.image = image;
            this.imageTransparentColor = imageTransparentColor;
            this.control = control;
        }
        #endregion

        #region Public Properties
        public string Caption
        {
            get { return this.caption; }
            set { this.caption = value; }
        }

        public Image Image
        {
            get { return this.image; }
            set { this.image = value; }
        }

        public Color ImageTransparentColor
        {
            get { return this.imageTransparentColor; }
            set { this.imageTransparentColor = value; }
        }

        public Control Control
        {
            get { return this.control; }
            set { this.control = value; }
        }
        #endregion
    }
}

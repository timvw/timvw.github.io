using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace OutlookBar
{
    public partial class OutlookBar : UserControl
    {
        private event EventHandler itemClick;

        public OutlookBar()
        {
            InitializeComponent();
        }

        public event EventHandler ItemClick
        {
            add { this.itemClick += value; }
            remove { this.itemClick -= value; }
        }

        public void Add(IOutlookBarItem item)
        {
            ToolStripButton toolStripButton = new ToolStripButton();
            toolStripButton.Image = item.Image;
            toolStripButton.ImageTransparentColor = item.ImageTransparentColor;
            toolStripButton.Text = item.Caption;
            toolStripButton.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText;

            toolStripButton.Click += new EventHandler(delegate(object sender, EventArgs e)
            {
                this.splitContainer1.Panel1.Controls.Clear();
                this.labelCaption.Text = item.Caption;
                this.panelCaption.BackColor = item.ImageTransparentColor;
                item.Control.Dock = DockStyle.Fill;
                this.splitContainer1.Panel1.Controls.Add(item.Control);
                this.OnItemClick(item);
            });

            this.splitContainer1.SplitterDistance -= toolStripButton.Height;
            this.toolStrip1.Items.Add(toolStripButton);
        }

        private void OnItemClick(IOutlookBarItem item)
        {
            if (this.itemClick != null)
            {
                this.itemClick(item, EventArgs.Empty);
            }
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace OutlookBar
{
    public interface IOutlookBarItem
    {
        string Caption { get; }
        Image Image { get; }
        Color ImageTransparentColor { get; }
        Control Control { get; }
    }
}

using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsApplication1
{
    class Constants
    {
        public const string Operation1 = "Operation1";
        public const string Operation2 = "Operation2";
        public const string Operation3 = "Operation3";
        public const string Operation4 = "Operation4";
        public const string Operation5 = "Operation5";
        public const string Operation6 = "Operation6";
    }
}

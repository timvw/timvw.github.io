using System;
using System.Collections.Generic;
using System.Text;

namespace DataGridViewToExcel
{
    [Serializable]
    public class Person
    {
        private int id;
        private string name;
        private DateTime birthday;

        public Person(int id, string name, DateTime birthday)
        {
            this.id = id;
            this.name = name;
            this.birthday = birthday;
        }

        public int Id
        {
            get { return this.id; }
            set { this.id = value; }
        }

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public DateTime Birthday
        {
            get { return this.birthday; }
            set { this.birthday = value; }
        }
    }
}

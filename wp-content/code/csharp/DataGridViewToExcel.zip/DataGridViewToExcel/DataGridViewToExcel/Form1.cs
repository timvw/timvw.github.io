using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CarlosAg.ExcelXmlWriter;
using System.Threading;
using System.Diagnostics;

namespace DataGridViewToExcel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            List<Person> persons = new List<Person>();
            persons.Add(new Person(1, "Tim", new DateTime(1980, 4, 30)));
            persons.Add(new Person(2, "Mike", new DateTime(1982, 7, 30)));
            persons.Add(new Person(3, "Joe", new DateTime(1984, 4, 21)));

            this.dataGridView1.Columns.Add("Id", "Id");
            this.dataGridView1.Columns[0].ValueType = typeof(int);
            this.dataGridView1.Columns.Add("Name", "Name");
            this.dataGridView1.Columns.Add("Birthday", "Birthday");
            this.dataGridView1.Columns[2].ValueType = typeof(DateTime);

            this.dataGridView2.Columns.Add("Id", "Id");
            this.dataGridView2.Columns[0].ValueType = typeof(int);
            this.dataGridView2.Columns.Add("Name", "Name");
            this.dataGridView2.Columns.Add("Birthday", "Birthday");
            this.dataGridView2.Columns[2].ValueType = typeof(DateTime);

            foreach (Person person in persons)
            {
                this.dataGridView1.Rows.Add(new object[] { person.Id, person.Name, person.Birthday });
                this.dataGridView2.Rows.Add(new object[] { person.Id, person.Name, person.Birthday });
            }

            this.dataGridView1[1, 0].Style.ForeColor = Color.Yellow;
            this.dataGridView1[1, 0].Style.BackColor = Color.Black;
            this.dataGridView2[1, 0].Style.ForeColor = Color.Yellow;
            this.dataGridView2[1, 0].Style.BackColor = Color.Black;

            using (Font f = new Font(FontFamily.GenericSansSerif, 12.3f))
            {
                this.dataGridView1[1, 0].Style.Font = f;
                this.dataGridView2[2, 0].Style.Font = f;
            }
        }

        private void buttonGenerateExcel_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = GetExcelSaveFileDialog())
            {
                if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
                {
                    string fileName = saveFileDialog.FileName;

                    Workbook workbook = ExcelGenerator.Generate(this.dataGridView1);
                    workbook.Save(fileName);

                    Process.Start(fileName);
                }
            }
        }

        private SaveFileDialog GetExcelSaveFileDialog()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.CheckPathExists = true;
            saveFileDialog.AddExtension = true;
            saveFileDialog.ValidateNames = true;
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            saveFileDialog.DefaultExt = ".xls";
            saveFileDialog.Filter = "Microsoft Excel Workbook (*.xls)|*.xls";
            return saveFileDialog;
        }
    }
}
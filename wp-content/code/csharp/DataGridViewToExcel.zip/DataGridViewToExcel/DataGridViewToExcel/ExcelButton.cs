using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;
using CarlosAg.ExcelXmlWriter;
using System.Diagnostics;

namespace DataGridViewToExcel
{
    public class ExcelButton : Button
    {
        #region Fields

        private DataGridView dataGridView;

        #endregion

        #region Constructors

        public ExcelButton()
            : base()
        {
            this.Click += new EventHandler(ExcelButton_Click);
        }

        #endregion

        #region Properties

        [Description("The DataGridView to export to Excel")]
        public DataGridView DataGridView
        {
            get { return this.dataGridView; }
            set { this.dataGridView = value; this.Enabled = value != null; }
        }

        #endregion

        #region EventHandlers

        void ExcelButton_Click(object sender, EventArgs e)
        {
            if (this.dataGridView == null)
            {
                throw new ArgumentNullException("No DataGridView was provided for export");
            }

            using (SaveFileDialog saveFileDialog = GetExcelSaveFileDialog())
            {
                if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
                {
                    string fileName = saveFileDialog.FileName;
                    Workbook workbook = ExcelGenerator.Generate(this.dataGridView);
                    workbook.Save(fileName);

                    Process.Start(fileName);
                }
            }
        }

        #endregion

        #region Methods

        private SaveFileDialog GetExcelSaveFileDialog()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.CheckPathExists = true;
            saveFileDialog.AddExtension = true;
            saveFileDialog.ValidateNames = true;
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            saveFileDialog.DefaultExt = ".xls";
            saveFileDialog.Filter = "Microsoft Excel Workbook (*.xls)|*.xls";
            return saveFileDialog;
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Infrastructure.StateMachineLanguage;

namespace Infrastructure.StateMachineComponents
{
    public class ActionsForCommand<TState, TCommand> : IChooseAction<TState, TCommand>
    {
        private readonly CommandsForState<TState, TCommand> commandsForState;
        private readonly List<Action> actions = new List<Action>();

        public ActionsForCommand(CommandsForState<TState, TCommand> owner)
        {
            commandsForState = owner;
        }

        public IChooseCommandAndAction<TState, TCommand> Do(Action action)
        {
            actions.Add(action);
            return new CommandAndActionForState<TState, TCommand>(commandsForState, this);
        }

        public void Execute()
        {
            foreach (Action action in actions) action();
        }
    }
}

﻿using Infrastructure.StateMachineLanguage;
namespace Infrastructure.StateMachineComponents
{
    public class CommandAndActionForState<TState, TCommand> : IChooseCommandAndAction<TState, TCommand>
    {
        private readonly CommandsForState<TState, TCommand> commandsForState;
        private readonly ActionsForCommand<TState, TCommand> actionsForCommand;

        public CommandAndActionForState(CommandsForState<TState, TCommand> commands, ActionsForCommand<TState, TCommand> actions)
        {
            commandsForState = commands;
            actionsForCommand = actions;
        }

        public IChooseAction<TState, TCommand> On(TCommand command)
        {
            return commandsForState.On(command);
        }

        public IChooseCommandAndAction<TState, TCommand> Do(Action action)
        {
            return actionsForCommand.Do(action);
        }
    }
}

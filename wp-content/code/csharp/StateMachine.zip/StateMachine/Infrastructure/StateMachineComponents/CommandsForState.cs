﻿using System;
using System.Collections.Generic;
using Infrastructure.StateMachineLanguage;

namespace Infrastructure.StateMachineComponents
{
    public class CommandsForState<TState, TCommand> : IChooseCommand<TState, TCommand>
    {
        private readonly StateMachine<TState, TCommand> stateMachine;
        private readonly Dictionary<TCommand, ActionsForCommand<TState, TCommand>> actionsForCommandPerCommand = new Dictionary<TCommand, ActionsForCommand<TState, TCommand>>();

        public CommandsForState(StateMachine<TState, TCommand> owner)
        {
            stateMachine = owner;
        }

        public IChooseAction<TState, TCommand> On(TCommand command)
        {
            var actionsForCommand = new ActionsForCommand<TState, TCommand>(this);
            actionsForCommandPerCommand[command] = actionsForCommand;
            return actionsForCommand;
        }

        public void Handle(TCommand command)
        {
            ActionsForCommand<TState, TCommand> actionsForCommand;
            if (!actionsForCommandPerCommand.TryGetValue(command, out actionsForCommand)) return;
            actionsForCommand.Execute();
        }
    }
}

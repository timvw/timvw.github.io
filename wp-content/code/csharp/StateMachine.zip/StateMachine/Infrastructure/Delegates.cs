namespace Infrastructure
{
    public delegate void Action();
}
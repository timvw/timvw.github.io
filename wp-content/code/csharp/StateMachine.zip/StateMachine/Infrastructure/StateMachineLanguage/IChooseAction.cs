﻿namespace Infrastructure.StateMachineLanguage
{
    public interface IChooseAction<TState, TCommand>
    {
        IChooseCommandAndAction<TState, TCommand> Do(Action action);
    }
}

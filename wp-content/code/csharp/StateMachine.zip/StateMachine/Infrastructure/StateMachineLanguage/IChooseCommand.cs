﻿namespace Infrastructure.StateMachineLanguage
{
    public interface IChooseCommand<TState, TCommand>
    {
        IChooseAction<TState, TCommand> On(TCommand command);
    }
}

﻿namespace Infrastructure.StateMachineLanguage
{
    public interface IChooseCommandAndAction<TState, TCommand> : IChooseCommand<TState, TCommand>, IChooseAction<TState, TCommand> 
    { 
    }
}

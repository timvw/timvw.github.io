﻿namespace Infrastructure.StateMachineLanguage
{
    public interface IChooseState<TState, TCommand> 
    { 
        IChooseCommand<TState, TCommand> WhenIn(TState state); 
    }
}

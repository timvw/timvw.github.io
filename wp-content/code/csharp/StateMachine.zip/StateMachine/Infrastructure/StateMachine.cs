﻿using System;
using System.Collections.Generic;
using Infrastructure.StateMachineLanguage;
using Infrastructure.StateMachineComponents;

namespace Infrastructure
{
    public class StateMachine<TState, TCommand> : IChooseState<TState, TCommand>
    {
        private TState currentState;
        private readonly Dictionary<TState, CommandsForState<TState, TCommand>> commandsForStatePerState = new Dictionary<TState, CommandsForState<TState, TCommand>>();

        public IChooseCommand<TState, TCommand> WhenIn(TState state)
        {
            var commandsForState = new CommandsForState<TState, TCommand>(this);
            commandsForStatePerState[state] = commandsForState;
            return commandsForState;
        }

        public void Handle(TCommand command)
        {
            CommandsForState<TState, TCommand> commandsForCurrentState;
            if (!commandsForStatePerState.TryGetValue(currentState, out commandsForCurrentState)) return;
            commandsForCurrentState.Handle(command);
        }

        public void ChangeStateTo(TState state)
        {
            currentState = state;
        }
    }
}

﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Infrastructure.Tests
{
    [TestClass]
    public class WhenHandlingCommand : GivenWhenThen
    {
        protected enum States { Loading, Ready };
        protected enum Commands { Previous, Next };

        protected StateMachine<States, Commands> sut;

        protected override void Arrange()
        {
            sut = new StateMachine<States, Commands>();
            sut.ChangeStateTo(States.Loading);
        }

        protected override void Act()
        {
            sut.Handle(Commands.Next);
        }

        [TestClass]
        public class GivenThereIsAnActionForTheCommandInTheCurrentState : WhenHandlingCommand
        {
            protected bool executed;

            protected override void Arrange()
            {
                base.Arrange();

                executed = false;
                sut.WhenIn(States.Loading)
                    .On(Commands.Next).Do(() => executed = true);
            }

            [TestMethod]
            public void ShouldExecuteThatAction()
            {
                Assert.IsTrue(executed);
            }
        }

        [TestClass]
        public class GivenThereIsNoActionForTheCommandInTheCurrentState : WhenHandlingCommand
        {
            [TestMethod]
            public void ShouldNotThrowAnException()
            {
            }
        }

        [TestClass]
        public class GivenThereIsAnActionForTheCommandInADifferentState : WhenHandlingCommand
        {
            protected bool executed;

            protected override void Arrange()
            {
                base.Arrange();

                executed = false;
                sut.WhenIn(States.Ready)
                    .On(Commands.Next).Do(() => executed = true);
            }

            [TestMethod]
            public void ShouldNotExecuteThatAction()
            {
                Assert.IsFalse(executed);
            }
        }

        [TestClass]
        public class GivenThereIsAnActionForADifferentCommandInTheCurrentState : WhenHandlingCommand
        {
            protected bool executed;

            protected override void Arrange()
            {
                base.Arrange();

                executed = false;
                sut.WhenIn(States.Loading)
                    .On(Commands.Previous).Do(() => executed = true);
            }

            [TestMethod]
            public void ShouldNotExecuteThatAction()
            {
                Assert.IsFalse(executed);
            }
        }

        [TestClass]
        public class GivenThereIsAlsoAnActionForADifferentCommandInTheCurrentState : WhenHandlingCommand
        {
            protected bool executed;

            protected override void Arrange()
            {
                base.Arrange();

                executed = false;
                sut.WhenIn(States.Loading)
                    .On(Commands.Next).Do(() => { })
                    .On(Commands.Previous).Do(() => executed = true);
            }

            [TestMethod]
            public void ShouldNotExecuteThatAction()
            {
                Assert.IsFalse(executed);
            }
        }

        [TestClass]
        public class GivenThereAreTwoActionsForTheCommandInTheCurrentState : WhenHandlingCommand
        {
            protected bool executedFirstAction;
            protected bool executedSecondAction;

            protected override void Arrange()
            {
                base.Arrange();

                sut.WhenIn(States.Loading)
                    .On(Commands.Next)
                        .Do(() => executedFirstAction = true)
                        .Do(() => executedSecondAction = true);
            }

            [TestMethod]
            public void ShouldExecuteFirstAction()
            {
                Assert.IsTrue(executedFirstAction);
            }

            [TestMethod]
            public void ShouldExecuteSecondAction()
            {
                Assert.IsTrue(executedSecondAction);
            }
        }
    }
}

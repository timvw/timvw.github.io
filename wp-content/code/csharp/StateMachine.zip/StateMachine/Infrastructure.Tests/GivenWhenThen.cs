﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Infrastructure.Tests
{
    [TestClass]
    public abstract class GivenWhenThen
    {
        [TestInitialize]
        public void BeforeEachTest()
        {
            Arrange();
            Act();
        }

        protected abstract void Arrange();
        protected abstract void Act();

    }
}

// JWorld.java

import java.awt.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

/**
 * @see java.lang.Object
 * @author Tim Van Wassenhove <timvw@users.sourceforge.net> 
 */
public class JWorld extends JPanel implements Runnable {

	private static final int BACKGROUND_IMAGES_COUNT = 4;
	private Image[] background;
	private int count;
	private Vector pieces;

	public JWorld() {
		pieces = new Vector();
		background = new Image[BACKGROUND_IMAGES_COUNT];
		for (int i=1;i<=background.length;i++) {
			URL iconURL = ClassLoader.getSystemResource("images/background"+i+".gif");
			if (iconURL != null) {
				background[i-1] = new ImageIcon(iconURL).getImage();	
			}
		}	
		count = 0;
		setSize(500,500);
		setVisible(true);
		new Thread(this).start();
	}
	
	public void run() {
		while (true) {
			try {
				Thread.sleep(750);
			} catch (InterruptedException ie) {
				//
			} finally {
				count++;
				if (count >= background.length) {
					count = 0;
				}
				repaint();
			}
		}
	}
	
	public void addPiece(Piece p) {
		pieces.add(p);		
	}
	
	public void removePiece(Piece p) {
		pieces.remove(p);		
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(background[count],0,0,this);
		Enumeration e = pieces.elements();
		while(e.hasMoreElements()) {
			Piece p = (Piece)e.nextElement();
			p.paint(g,this);
		}
	}
	
	public void movePiece(Piece p,int x,int y) {
		p.move(x,y);
	}
	
	synchronized public void update(Piece p) {
		if (p.getX() < 0 || p.getX() > 460 || p.getY() < 0 || p.getY() > 440) {
			p.undoMove();
		}
		Enumeration e = pieces.elements();
		while(e.hasMoreElements()) {
			Piece piece = (Piece)e.nextElement();
			if (p != piece &&  piece.testCollision(p)) {
				p.hit(piece);
			}
		}
	 	repaint();
	}

}

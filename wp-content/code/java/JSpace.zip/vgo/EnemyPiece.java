// EnemyPiece.java
/**
 * @see java.lang.Object
 * @author Tim Van Wassenhove <timvw@users.sourceforge.net> 
 */
public class EnemyPiece extends Piece {
	
	private static int hitcount = 0;
	
	public EnemyPiece(JWorld world,int posX,int posY) {
		super("bad guy",world,posX,posY,30,30,"enemy"+( (int)(Math.random() * 3)+1)+".gif");
		new Thread(this).start();
	}
	
	public void hit(Piece piece) {
		if (!isDead()) {
			if (piece instanceof BulletPiece) {
				piece.hit(this);
			} else if (piece.getName() == "hero") {
				hitcount++;
				System.out.println("bad guys have hitted hero: "+hitcount);
				if (hitcount >= 30) {
					System.out.println("Game over.");
					System.exit(-1);
				}
			}
		}
	}
	
	
}

// BulletPiece.java
/**
 * @see java.lang.Object
 * @author Tim Van Wassenhove <timvw@users.sourceforge.net> 
 */
public class BulletPiece extends Piece implements Runnable {
	
	private static int deadcount = 0;
	
	public BulletPiece(JWorld world,int posX,int posY) {
		super("bullet",world,posX,posY,5,5,"bullet.gif");
		new Thread(this).start();
	}
	
	public void hit(Piece p) {
		if (p.getName().equals("bad guy")) {
			deadcount++;
			System.out.println(getName()+" has killed "+p.getName()+" kills: "+deadcount);
			getWorld().removePiece(p);
			getWorld().removePiece(this);
			setDead(true);
			p.setDead(true);
			int x = (int)(Math.random()* 400); 
			int y = (int)(Math.random() * 100); 
			for (int i=(int)(Math.random()* 2);i<2; i++) {
				getWorld().addPiece(new EnemyPiece(getWorld(),x,y));
			}
		} 
	}
	
	public void undoMove() {
		setDead(true);
		getWorld().removePiece(this);
	}
	
	public void run() {
		while (!isDead()) {
			try {
				Thread.sleep(30);
 	 	 	} catch (InterruptedException ie) {
				//
			} finally {
				getWorld().movePiece(this,0,-5);
			}
		}
	}
}

// JSpace.java

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * @see java.lang.Object
 * @author Tim Van Wassenhove <timvw@users.sourceforge.net> 
 */
public class 
JSpace extends JFrame implements ActionListener, KeyListener {
	
	private JWorld world;
	private Piece piece;
	
	public static void main(String[] args) {
		JSpace space = new JSpace();
	}
	
	public JSpace() {
		super("JSpace v1.0");
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		
		world = new JWorld();
		piece = new Piece("hero",world,230,400);
		world.addPiece(piece); 
		for (int i=0;i<2;i++) {
			int x = (int)(Math.random() * 400);  
			int y = (int)(Math.random() * 100);
			world.addPiece(new EnemyPiece(world,x,y));
		}
		c.add(world,BorderLayout.CENTER);
		
		addKeyListener(this);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500,500);
		setVisible(true);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see java.awt.event.KeyListener#keyTyped(java.awt.event.KeyEvent)
	 */
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
	 */
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			world.movePiece(piece,0,-20);
		} else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			world.movePiece(piece,0,20);
		} else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			world.movePiece(piece,-20,0);
		} else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			world.movePiece(piece,20,0);
		} else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			world.addPiece(new BulletPiece(world,(piece.getX()+(int)(piece.getWidth()/2.0)) , piece.getY()-20));
		}
	}

	/* (non-Javadoc)
	 * @see java.awt.event.KeyListener#keyReleased(java.awt.event.KeyEvent)
	 */
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}

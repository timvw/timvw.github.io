// Piece.java

import java.awt.*;
import java.awt.image.*;
import java.net.*;
import javax.swing.*;

/**
 * @see java.lang.Object
 * @author Tim Van Wassenhove <timvw@users.sourceforge.net> 
 */
public class Piece implements Runnable {
	
	private JWorld world;
	private Image image;
	private int oldX,oldY;
	private int posX,posY;
	int width,height;
	private Shape position;
	int hitcount;
	private String name;
	private boolean isDead;
	
	public Piece(String name,JWorld world,int posX,int posY) {
		this(name,world,posX,posY,30,30,"hero.gif");
	}
	
	public Piece(String name,JWorld world,int posX,int posY,int width, int height,String imageLocation) {
		this.name = name;
		this.world = world;
		this.width = width;
		this.height = height;
		URL iconURL = ClassLoader.getSystemResource("images/"+imageLocation);
		if (iconURL != null) {
			image = new ImageIcon(iconURL).getImage();	
		}
		this.posX = oldX = posX;
		this.posY = oldY = posY;
		setPosition(posX,posY);
		hitcount = 0;
		isDead = false;
	}
	
	public String getName() {
		return name;
	}
	
	public void setPosition(int posX,int posY) {
		position = new Rectangle(posX,posY,width,height);
	}
	
	public void paint(Graphics g,ImageObserver observer) {
		g.drawImage(image,posX,posY,observer);
	}
	
	public int getX() {
		return posX;
	}
	
	public int getY() {
		return posY;
	}
	
	public void undoMove() {
		posX = oldX;
		posY = oldY;
		setPosition(posX,posY);
		world.update(this);
	}
	
	public void move(int x,int y) {
		oldX = posX;
		oldY = posY;
		setPosition(posX,posY);
		posX += x;
		posY += y;
		world.update(this);
	}
	
	public Rectangle getPosition() {
		return position.getBounds();
	}
	
	public boolean testCollision(Piece piece) {
		if (piece != this && !isDead && position.intersects(piece.getPosition())) {
			return true;
		}
	  	return false;		
	}
	
	public void hit(Piece piece) {
		if (piece instanceof BulletPiece) {
			piece.hit(this);
		} else {
			hitcount++;
			System.out.println(getName()+" has hit "+piece.getName()+" hitcount: "+hitcount);
		}
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	protected JWorld getWorld() {
		return world;
	}
	
	public void run() {
		while (!isDead()) {
			try {
				Thread.sleep((int)(Math.random() * 300)); 
			} catch(InterruptedException ie) {
				//
			} finally {
				int x = (int)(Math.random() * 200)-100;
				int y = (int)(Math.random() * 200)-100;
				world.movePiece(this,x,y);
			}
		}
	}
	
	public void setDead(boolean dead) {
		isDead = dead;
	}
	
	public boolean isDead() {
		return isDead;
	}
	
}

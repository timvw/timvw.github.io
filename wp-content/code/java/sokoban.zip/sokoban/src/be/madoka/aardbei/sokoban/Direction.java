/*
 * Created on Jun 12, 2003 9:04:08 PM
 */
package be.madoka.aardbei.sokoban;

/**
 * Represents a direction of a PositionChange.
 * @author Tim Van Wassenhove
 */
public interface Direction {

	public static final int UNDO_LEVEL = -2;
	public static final int UNDO_MOVE = -1;

	public static final int REMOVE = 0;
	public static final int INSERT = 1;

	public static final int UP = 2;
	public static final int DOWN = 3;
	public static final int LEFT = 4;
	public static final int RIGHT = 5;

}

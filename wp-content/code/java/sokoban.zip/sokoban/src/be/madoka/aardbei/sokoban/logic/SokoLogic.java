/*
 * Created on Jun 12, 2003 10:02:25 PM
 */
package be.madoka.aardbei.sokoban.logic;

import java.util.*;
import be.madoka.aardbei.sokoban.*;
import be.madoka.aardbei.sokoban.logic.loader.*;

/**
 * Represents the Logic of a Sokoban game.
 * @author Tim Van Wassenhove
 */
public class SokoLogic extends Logic implements Direction {

	private static final String NAME = "Sokoban v1.0";
	private static final String INFO = "Sokoban is a classic puzzle game invented in Japan.\nThe original game was written by Hiroyuki Imabayashi in.\nIn 1980 it won a computer game contest.\nMr Hiroyuki Imabayashi is president of the company Thinking Rabbit Inc. in Japan.\nThe game is Copyright  1982 Thinking Rabbit.\nOver the years many versions for all platforms have been made and new levels are created all the time.";
	
	private SokoLoader loader;		
	private int level;	
	private World world;	
	private Piece hero;
	private Vector treasures;
	private Vector goals;
	private int lastDirection;		
	private String playerName;
	private String fileName;
			
	/**
	 * Default constructor.
	 */	
	public SokoLogic() {
		initialize();
	}

	/**
	 * Initialises the global variables.
	 */
	protected void initialize() {
		loader = null;
		level = 0;
		updateLevel(new LevelChangeEvent(this,level));
		world = null;
		updateDimension(new DimensionChangeEvent(this,null));
		hero = null;
		updateScore(new ScoreChangeEvent(this,0));
		treasures = new Vector();
		goals = new Vector();
		lastDirection = Direction.UNDO_MOVE;
	}

	/**
	 * Handles PositionChangeEvents recieved from a World.
	 * @param e the PositionChangeEvent
	 */
	public void worldEvent(PositionChangeEvent e) {
		updatePosition(e);
		Piece piece = (Piece)e.getSource();
		if (piece == hero) {
			updateScore(new ScoreChangeEvent(this,hero.getMoves()));
			if (testLevelCompleted()) {
				levelCompleted(true);
				if (testGameCompleted()) {
					gameCompleted(true);
				} else {
					level++;
					startLevel(level);
				}
			}
		}
	}

	/**
	 * Tests if the level has been completed.
	 * @return a <code>boolean</code> specifying if the level has been completed or not
	 */
	protected boolean testLevelCompleted() {
		boolean completed = true;
		Enumeration e = treasures.elements();
		while (e.hasMoreElements() && completed) {
			Piece treasure = (Piece)e.nextElement();
			boolean onGoal = false;
			Enumeration e2 = goals.elements();
			while (!onGoal && e2.hasMoreElements()) {
				Piece goal = (Piece)e2.nextElement();
				if (treasure.getPosition().equals(goal.getPosition())) {
					onGoal = true;
				}
			}
			completed = onGoal;
		}
		return completed;
	}

	/**
	 * Tests if the Game has been completed.
	 * @return a <code>boolean</code> specifying if the game has been completed or not
	 */
	protected boolean testGameCompleted() {
		if (loader.hasMoreWorlds()) {
			return false;
		}
		return true;
	}
	
	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Logic#getName()
	 */
	public String getName() {
		return NAME;
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Logic#getInfo()
	 */
	public String getInfo() {
		return INFO;
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Logic#move(int)
	 */
	public boolean move(int direction) {	
		if (world != null && hero != null) {
			if (direction == UNDO_LEVEL) {
				levelCompleted(false);
				startLevel(level);
			} else if (direction == UNDO_MOVE) {
				if (lastDirection != UNDO_MOVE) {
					lastDirection = direction;
					return world.move(direction);
				}
			} else {
				lastDirection = direction;
				return world.move(hero,direction);
			}
		}
		lastDirection = direction;
		return false;
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Logic#start(java.lang.String,java.lang.String)
	 */
	public boolean start(String playerName,String fileName) {
		if (loader == null) {
			this.playerName = playerName;
			this.fileName = fileName;
			loader = new XMLSokoLoader(this,fileName);
			return startLevel(1);
		} 
		return false;
	}

	/**
	 * Starts a level.
	 * @param level the level
	 * @return a <code>boolean</code> specifying if the level could be started or not
	 */
	protected boolean startLevel(int level) {
		if (loader != null && loader.hasWorld(level)) {
			world = loader.getWorld(level);
			updateDimension(new DimensionChangeEvent(this,world.getDimension()));
			if (world != null) {
				this.level = level;
				updateLevel(new LevelChangeEvent(this,level));
				findPieces();
				updateScore(new ScoreChangeEvent(this,0));
				return true;
			}
		}
		return false;
	}

	/**
	 * Finds all the important Pieces in a World.
	 */
	protected void findPieces() {
		hero = world.findPiece("HERO");
		treasures = world.findPieces("TREASURE");
		goals = world.findPieces("GOAL");
		insertPieces("EMPTY");
		insertPieces("WALL");
		insertPieces("GOAL");
		insertPieces("TREASURE");
		insertPieces("HERO");
	}
	
	/**
	 * Inserts the pieces.
	 */
	protected void insertPieces(String name) {
		Vector pieces = world.findPieces(name);
		Enumeration e = pieces.elements();
		while (e.hasMoreElements()) {
			Piece piece = (Piece)e.nextElement();
			updatePosition(new PositionChangeEvent(piece,null,piece.getPosition(),Direction.INSERT));
		}
	}	
	

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Logic#end()
	 */
	public boolean end() {
		initialize();
		levelCompleted(false);
		gameCompleted(false);
		return true;
	}

}

/*
 * Created on Jun 16, 2003 7:13:23 PM
 */
package be.madoka.aardbei.sokoban;

/**
 * Represents a dimension.
 * @author Tim Van Wassenhove
 */
public class Dimension {
	
	private int width;
	private int height;
	
	/**
	 * Default constructor.
	 * @param width the width
	 * @param height the height
	 */
	public Dimension(int width,int height) {
		this.width = width;
		this.height = height;
	}

	/**
	 * Returns the width.
	 * @return an <code>int</code> specifying the width
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Returns the height.
	 * @return an <code>int</code> specifying the height
	 */
	public int getHeight() {
		return height;
	}

}

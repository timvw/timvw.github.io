/*
 * Created on Jun 12, 2003 9:01:15 PM
 */
package be.madoka.aardbei.sokoban;

/**
 * Represents a visual representation for some Logic.
 * @author Tim Van Wassenhove
 */
public interface Visualisation {

	/**
	 * Updates the Dimension.
	 * @param e the DimensionChangeEvent
	 */
	public void updateDimension(DimensionChangeEvent e);
	
	/**
	 * Updates a Position.
	 * @param e the PositionChangeEvent
	 */
	public void updatePosition(PositionChangeEvent e);
	
	/**
	 * Updates the level.
	 * @param e the LevelChangeEvent
	 */
	public void updateLevel(LevelChangeEvent e);
	
	/**
	 * Updates the score.
	 * @param e the ScoreChangeEvent
	 */
	public void updateScore(ScoreChangeEvent e);
	
	/**
	 * The Level has been completed whether or not succesfull.
	 * @param succes the succes
	 */
	public void levelCompleted(boolean succes);
	
	/**
	 * The Game has been completed wheter or not succesfull.
	 * @param succes the succes
	 */
	public void gameCompleted(boolean succes);

}

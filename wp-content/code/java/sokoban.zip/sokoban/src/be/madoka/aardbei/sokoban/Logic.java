/*
 * Created on Jun 12, 2003 8:53:05 PM
 */
package be.madoka.aardbei.sokoban;

import java.util.*;

/**
 * Represents the logic of a game. 
 * @author Tim Van Wassenhove
 */
public abstract class Logic {

	private Vector visualisations;
	
	/**
	 * Default constructor.
	 */
	public Logic() {
		visualisations = new Vector();
	}

	/**
	 * Adds the given Visualisation to the visualisations.
	 * @param vis the Visualisation
	 */
	public void addVisualisation(Visualisation vis) {
		visualisations.add(vis);
	}

	/**
	 * Removes the given Visualisation from the visualisations.
	 * @param vis the Visualisation
	 */
	public void removeVisualisation(Visualisation vis) {
		visualisations.remove(vis);
	}
	
	/**
	 * Notifies the Visualisations of a PositionChangeEvent.
	 * @param pce the PositionChangeEvent
	 */
	protected void updatePosition(PositionChangeEvent pce) {
		Enumeration e = visualisations.elements();
		while (e.hasMoreElements()) {
			Visualisation vis = (Visualisation)e.nextElement();
			vis.updatePosition(pce);
		}			
	}
	
	/**
	 * Notifies the Visualisations of a DimensionChangeEvent.
	 * @param dce the DimensionChangeEvent
	 */
	protected void updateDimension(DimensionChangeEvent dce) {
		Enumeration e = visualisations.elements();
		while (e.hasMoreElements()) {
			Visualisation vis = (Visualisation)e.nextElement();
			vis.updateDimension(dce);
		}	
	}
	
	/**
	 * Notifies the Visualisations of a LevelChangeEvent.
	 * @param lce the LevelChangeEvent
	 */
	protected void updateLevel(LevelChangeEvent lce) {
		Enumeration e = visualisations.elements();
		while (e.hasMoreElements()) {
			Visualisation vis = (Visualisation)e.nextElement();
			vis.updateLevel(lce);
		}		
	}
	
	/**
	 * Notifies the Visualisations of a ScoreChangeEvent.
	 * @param lse the ScoreChangeEvent
	 */
	protected void updateScore(ScoreChangeEvent sce) {
		Enumeration e = visualisations.elements();
		while (e.hasMoreElements()) {
			Visualisation vis = (Visualisation)e.nextElement();
			vis.updateScore(sce);
		}		
	}
	
	/**
	 * Notifies the Visualisations that the Level has been completed.
	 */
	protected void levelCompleted(boolean succes) {
		Enumeration e = visualisations.elements();
		while (e.hasMoreElements()) {
			Visualisation vis = (Visualisation)e.nextElement();
			vis.levelCompleted(succes);
		}			
	}
	
	/**
	 * Notifies the Visualisations that the game has been completed.
	 */
	protected void gameCompleted(boolean succes) {
		Enumeration e = visualisations.elements();
		while (e.hasMoreElements()) {
			Visualisation vis = (Visualisation)e.nextElement();
			vis.gameCompleted(succes);
		}			
	}

	/**
	 * Gives the name of this game.
	 * @return a <code>String</code> specifying the name
	 */	
	abstract public String getName();
	
	/**
	 * Gives some info about this game.
	 * @return a <code>String</code> giving info about this game
	 */
	abstract public String getInfo();
	
	/**
	 * Moves the game in the given direction.
	 * @param direction the direction
	 * @return a <code>boolean</code> specifying if the move was performed or not
	 */
	abstract public boolean move(int direction);
	
	/**
	 * Starts a new game from the given fileName for the given playerName.
	 * @param playerName the playerName
	 * @param fileName the filename
	 * @return a <code>boolean</code> specifying whether the game was started or not
	 */
	abstract public boolean start(String playerName,String fileName);
	
	/**
	 * Ends the game.
	 * @return a <code>boolean</code> specifying whether the game wa stopped or not
	 */
	abstract public boolean end();
	
}

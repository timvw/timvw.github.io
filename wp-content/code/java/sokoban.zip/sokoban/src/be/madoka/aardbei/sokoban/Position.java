/*
 * Created on Jun 12, 2003 9:18:17 PM
 */
package be.madoka.aardbei.sokoban;

/**
 * Represents a Position.
 * @author Tim Van Wassenhove
 */
public class Position {

	private int posX;
	private int posY;
	
	/**
	 * Default constructor.
	 * @param posX the X-position
	 * @param posY the Y-position
	 */
	public Position(int posX,int posY) {
		this.posX = posX;
		this.posY = posY;
	}
	
	/**
	 * Gives the X-position.
	 * @return an <code>int</code> giving the position on the X-axis
	 */
	public int getX() {
		return posX;
	}

	/**
	 * Gives the Y-position.
	 * @return an <code>int</code> giving the position on the Y-axis
	 */
	public int getY() {
		return posY;
	}

	/**
	 * Compares with a given Position.
	 * @param position the Position to compare with
	 * @return a <code>boolean</code> specifying whether the Positions are equal or not
	 */
	public boolean equals(Position position) {
		if (getX() == position.getX() && getY() == position.getY()) {
			return true;
		} else {
			return false;
		}
	}

}

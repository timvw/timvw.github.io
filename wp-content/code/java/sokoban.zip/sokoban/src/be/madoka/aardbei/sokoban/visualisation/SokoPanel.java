/*
 * Created on Jun 12, 2003 9:35:44 PM
 */
package be.madoka.aardbei.sokoban.visualisation;

import java.awt.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import be.madoka.aardbei.sokoban.*;
import be.madoka.aardbei.sokoban.logic.*;

/**
 * Able to paint a World and its Pieces.
 * @author Tim Van Wassenhove
 */
public class SokoPanel extends JPanel {

	private String[] imageURL = {
		"images/unknown.gif",
		"images/empty.gif",
		"images/wall.gif",
		"images/goal.gif",
		"images/treasure.gif",
		"images/hero.gif"
	};

	private Vector pieces;
	private Image[] images;
	
	private int width;
	private int height;
	private be.madoka.aardbei.sokoban.Dimension dimension;
	private int pieceWidth;
	private int pieceHeight;
	
	/**
	 * Default constructor.
	 */
	public SokoPanel() {
		pieces = new Vector();
		images = new Image[imageURL.length];
		for (int i=0;i<images.length;i++) {
			URL url = ClassLoader.getSystemResource(imageURL[i]);
			if (url != null) {
				images[i] = new ImageIcon(url).getImage();
			}
		}
		setVisible(true);
	}	
	
	/**
	 * Updates the position of an object.
	 * @param e the PositionChangeEvent
	 */
	public void update(PositionChangeEvent e) {
		if (e.getSource() instanceof Piece) {
			Piece piece = (Piece)e.getSource();
			if (e.getDirection() == Direction.INSERT) {
				pieces.add(piece);
			} else if (e.getDirection() == Direction.REMOVE) {
				pieces.remove(piece);
			}
			repaint();
		}
	}
	
	/**
	 * Updates the dimension.
	 * @param e the DimensionChangeEvent
	 */
	public void update(DimensionChangeEvent e) {
		dimension = e.getDimension();
		rescaleImages();
		repaint();
	}
	
	/**
	 * Paints this World.
	 * @param g the Graphics
	 */
	public void paint(Graphics g) {
		int curWidth = getWidth();
		int curHeight = getHeight();
		if (curWidth != width || curHeight != height) {
			rescaleImages();
		}
		g.setColor(Color.GRAY);
		g.fillRect(0,0,curWidth,curHeight);
		paintPieces(g); 
	}
	
	/**
	 * Rescales the Images so the whole World can be painted.
	 */
	protected void rescaleImages() {
		width = getWidth();
		height = getHeight();
		if (dimension != null && dimension.getWidth() != 0 && dimension.getHeight() != 0) {
			pieceWidth = (int) (width/dimension.getWidth());
			pieceHeight = (int) (height/dimension.getHeight());
			for (int i=0;i<images.length;i++) {
				images[i] = images[i].getScaledInstance(pieceWidth,pieceHeight,Image.SCALE_SMOOTH);
			}
		}
	}
		
	/**
	 * Finds pieces with a given name.
	 * @param name the name
	 */	
	protected Enumeration pieces(String name) {
		Vector foundPieces = new Vector();
		Enumeration e = pieces.elements();
		while (e.hasMoreElements()) {
			Piece piece = (Piece)e.nextElement();
			if (piece.getName().equals(name)) {
				foundPieces.add(piece);
			}
		}
		return foundPieces.elements();	
	}
		
	/**
	 * Paints the Pieces.
	 * @param g the Graphics
	 */
	protected void paintPieces(Graphics g) {
		paintPieces(g,"EMPTY");
		paintPieces(g,"WALL");
		paintPieces(g,"GOAL");
		paintPieces(g,"TREASURE");
		paintPieces(g,"HERO");
	}
	
	/**
	 * Paints a given Piece on the Graphics object.
	 * @param g the Graphics
	 * @param piece the Piece
	 */
	protected void paintPieces(Graphics g,String name) {	
		int pieceCnt = 0;
		if (name.equals("EMPTY")) {
			pieceCnt = 1;
		} else if (name.equals("WALL")) {
			pieceCnt = 2;
		} else if (name.equals("GOAL")) {
			pieceCnt = 3;
		} else if (name.equals("TREASURE")) {
			pieceCnt = 4;
		} else if (name.equals("HERO")) {
			pieceCnt = 5;
		}
		Enumeration e = pieces(name);
		while (e.hasMoreElements()) {
			Piece piece = (Piece)e.nextElement();
			Position position = piece.getPosition();
			int posX = position.getX();
			int posY = position.getY();
			g.drawImage(images[pieceCnt], posX*pieceWidth, posY*pieceHeight,this);
		}
	}
	
	/**
	 * the Level has been completed.
	 * @author Tim Van Wassenhove
	 */
	public void levelCompleted() {
		pieces = new Vector();
		dimension = null;
		repaint();
	}
	
}

/*
 * Created on Jun 16, 2003 7:16:07 PM
 */
package be.madoka.aardbei.sokoban;

import java.beans.PropertyChangeEvent;

/**
 * Represents a change of Dimension.
 * @author Tim Van Wassenhove
 */
public class DimensionChangeEvent extends PropertyChangeEvent {

	/**
	 * Default constructor.
	 * @param logic the logic
	 * @param newDimension the new Dimension
	 */
	public DimensionChangeEvent(Logic logic,Dimension newDimension) {
		super(logic,"dimension",null,newDimension);
	}
	
	/**
	 * Returns the new Dimension.
	 * @return a <code>Dimension</code> specifying the new Dimension
	 */
	public Dimension getDimension() {
		if (getNewValue() != null) {
			return (Dimension)getNewValue();
		} 
		return new Dimension(0,0);
	}

}

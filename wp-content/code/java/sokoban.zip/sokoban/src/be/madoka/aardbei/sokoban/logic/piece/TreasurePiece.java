/*
 * Created on Jun 11, 2003 5:10:01 PM
 */
package be.madoka.aardbei.sokoban.logic.piece;

import be.madoka.aardbei.sokoban.*;
import be.madoka.aardbei.sokoban.logic.*;

/**
 * Represents a Treasure Piece.
 * @author Tim Van Wassenhove
 */
public class TreasurePiece extends Piece {

	private static final String NAME = "TREASURE";

	/**
	 * Default constructor.
	 * @param position the Position
	 */
	public TreasurePiece(Position position) {
		super(position);
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.Piece#getName()
	 */
	public String getName() {
		return NAME;
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.Piece#getNewPosition(int)
	 */
	protected Position getNewPosition(int direction) {
		int posX = getPosition().getX();
		int posY = getPosition().getY();
		if (direction == Direction.LEFT) {
			posX--;
		} else if (direction == Direction.RIGHT) {
			posX++;
		} else if (direction == Direction.UP) {
			posY++;
		} else if (direction == Direction.DOWN) {
			posY--;
		}
		return new Position(posX,posY);
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.Piece#testCollision(be.madoka.aardbei.sokoban.PositionChangeEvent)
	 */
	protected boolean testCollision(PositionChangeEvent e) {
		if (e.getDirection() != Direction.UNDO_MOVE || e.getDirection() != Direction.REMOVE) {
			Position pos = (Position)e.getNewValue();
			if (getPosition().equals(pos)) {
				if ((e.getSource() instanceof HeroPiece) && (move(e.getDirection()))) {
					return false;
				} else {
					return true;
				}
			}
		}
		return false;
	}


}

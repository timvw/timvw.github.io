/*
 * Created on Jun 11, 2003 5:10:23 PM
 */
package be.madoka.aardbei.sokoban.logic.piece;

import be.madoka.aardbei.sokoban.*;

/**
 * Represents a Goal Piece.
 * @author Tim Van Wassenhove
 */
public class GoalPiece extends EmptyPiece {

	private static final String NAME = "GOAL";

	/**
	 * Default constructor.
	 * @param position the Position
	 */
	public GoalPiece(Position position) {
		super(position);
	}
	
	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.Piece#getName()
	 */
	public String getName() {
		return NAME;
	}
	
}

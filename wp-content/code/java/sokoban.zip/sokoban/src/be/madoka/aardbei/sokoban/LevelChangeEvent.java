/*
 * Created on Jun 16, 2003 6:16:58 PM
 */
package be.madoka.aardbei.sokoban;

/**
 * Represents a levelchange.
 * @author Tim Van Wassenhove
 */
public class LevelChangeEvent extends ScoreChangeEvent {

	/**
	 * Default constructor
	 * @param logic the logic
	 * @param newLevel the new level
	 */
	public LevelChangeEvent(Logic logic, int newLevel) {
		super(logic,"level",newLevel);
	}

}

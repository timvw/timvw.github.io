/*
 * Created on Jun 12, 2003 9:37:09 PM
 */
package be.madoka.aardbei.sokoban.visualisation;

import java.awt.*;
import javax.swing.*;

/**
 * Contains information about the score and level.
 * @author Tim Van Wassenhove
 */
public class SokoBar extends JToolBar {

	private JLabel levelLabel;
	private JLabel scoreLabel;

	/**
	 * Default constructor.
	 */
	public SokoBar() {
		setLayout(new FlowLayout());
		levelLabel = new JLabel("Level: 0");
		add(levelLabel);
		scoreLabel = new JLabel("Score: 0");
		add(scoreLabel);
		setVisible(true);
	}
	
	/**
	 * Updates the level.
	 * @param level the level
	 */
	public void updateLevel(int level) {
		levelLabel.setText("Level: "+level);
	}
	
	/**
	 * Updates the score.
	 * @param score the score
	 */
	public void updateScore(int score) {
		scoreLabel.setText("Score: "+score);
	}
	
}

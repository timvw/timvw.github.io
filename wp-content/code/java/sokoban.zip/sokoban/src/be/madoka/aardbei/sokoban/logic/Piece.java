/*
 * Created on Jun 17, 2003 1:55:35 AM
 */
package be.madoka.aardbei.sokoban.logic;

import java.beans.*;

import be.madoka.aardbei.sokoban.*;

/**
 * Represents an item that can exist in a World.
 * @author Tim Van Wassenhove
 */
abstract public class Piece  implements PropertyChangeListener, VetoableChangeListener {
	
	private Position position;
	private Position oldPosition;
	private int moves;
	private PropertyChangeSupport pcs;
	private VetoableChangeSupport vcs;
	
	/**
	 * Default constructor.
	 * @param name the name
	 * @param position the Position
	 */
	public Piece(Position position) {
		this.position = position;
		oldPosition = position;
		moves = 0;
		pcs = new PropertyChangeSupport(this);
		vcs = new VetoableChangeSupport(this);
		addPropertyListener(this);
	}

	/**
	 * Adds the given VetoAbleChangeListener.
	 * @param vcl the VetoAbleChangeListener 
	 */
	public void addVetoableChangeListener(VetoableChangeListener vcl) {
		vcs.addVetoableChangeListener(vcl);
	}
	
	/**
	 * Removes the given VetoAbleChangeListener.
	 * @param vcl the VetoAbleChangeListener
	 */
	public void removeVetoableChangeListener(VetoableChangeListener vcl) {
		vcs.removeVetoableChangeListener(vcl);
	}
	
	/**
	 * Adds the given PropertyListener.
	 * @param pcl the PropertyListener
	 */
	public void addPropertyListener(PropertyChangeListener pcl) {
		pcs.addPropertyChangeListener(pcl);
	}
	
	/**
	 * Removes the given PropertyListener.
	 * @param pcl the PropertyListener
	 */
	public void removePropertyListener(PropertyChangeListener pcl) {
		pcs.removePropertyChangeListener(pcl);
	}
	
	/**
	 * Returns the name of this Piece.
	 * @return a <code>String</code> specifying the name of this Piece
	 */
	abstract public String getName();
	
	/**
	 * Returns the Position of this Piece.
	 * @return a <code>Position</code> specifying the Position of this Piece
	 */
	public Position getPosition() {
		return position;
	}
	
	/**
	 * Gives the Position after we would have moved into the given direction.
	 * @param direction the direction
	 * @return a <code>Position</code> specifying the Position
	 */
	private Position getPosition(int direction) {
		if (direction == Direction.UNDO_MOVE) {
			return oldPosition;
		} else if (direction == Direction.INSERT) {
			return position;
		} else if (direction == Direction.REMOVE) {
			return null;
		} else {
			return getNewPosition(direction);
		}
	}
	
	/**
	 * Returns the new Position after moving into the giving Direction. 
	 * @param direction the Direction
	 * @return a <code>Position</code> specifying the new Position
	 */	
	abstract protected Position getNewPosition(int direction);
	
	/**
	 * Returns the previous Position of this Piece.
	 * @return a <code>Position</code> specifying the previous Position of this Piece
	 */
	public Position getOldPosition() {
		return oldPosition;
	}
	
	/**
	 * Saves the current Position.
	 */
	protected void savePosition() {
		oldPosition = position;
	}
	
	/**
	 * Moves into the given direction.
	 * @param direction the direction
	 * @return a <code>boolean/<code> specifying if the move was succesfull or not
	 */
	public boolean move(int direction) {
		Position newPosition = getPosition(direction);
		try {
			vcs.fireVetoableChange(new PositionChangeEvent(this,position,newPosition,direction));
			Position prevPosition = position;
			position = newPosition;
			if (direction == Direction.UNDO_MOVE) {
				if (moves > 0) {
					moves--;
				}
			} else if (direction == Direction.INSERT || direction == Direction.REMOVE) {
				moves = 0;
			} else {
				oldPosition = prevPosition;
				moves++;
			}
			pcs.firePropertyChange(new PositionChangeEvent(this,prevPosition,position,direction));
			return true;
		} catch (PropertyVetoException e) {
			return false;
		}
	}
	
	/**
	 * Gives the number moves this Piece has made.
	 * @return an <code>int</code> specifying the number of moves
	 */
	public int getMoves() {
		return moves;
	}
	
	/* (non-Javadoc)
	 * @see java.beans.PropertyChangeListener#propertyChange(java.beans.PropertyChangeEvent)
	 */
	public void propertyChange(PropertyChangeEvent e) {
	}

	/* (non-Javadoc)
	 * @see java.beans.VetoableChangeListener#vetoableChange(java.beans.PropertyChangeEvent)
	 */
	public void vetoableChange(PropertyChangeEvent e) throws PropertyVetoException {
		if (e instanceof PositionChangeEvent) {
			PositionChangeEvent pce = (PositionChangeEvent)e;
			if (pce.getDirection() != Direction.UNDO_MOVE || pce.getDirection() == Direction.REMOVE) {
				if (testCollision(pce)) {
					throw new PropertyVetoException("COLLISION",pce);
				}
			}
		}
	}
	
	/**
	 * Tests if there is collision with the source of the PositionChangeEvent.
	 * @param e the PositionChangeEvent
	 * @return a <code>boolean</code> specifying if there is collision or not
	 */
	abstract protected boolean testCollision(PositionChangeEvent e);

}

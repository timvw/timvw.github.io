/*
 * Created on Jun 17, 2003 1:59:48 AM
 */
package be.madoka.aardbei.sokoban.logic;

import java.util.*;
import java.beans.*;

import be.madoka.aardbei.sokoban.*;

/**
 * Represents a World where Pieces can live in.
 * @author Tim Van Wassenhove
 */
public class World implements PropertyChangeListener, VetoableChangeListener {
	
	private SokoLogic logic;
	private Dimension dimension;
	private Vector pieces;
	
	/**
	 * Default constructor.
	 * @param logic the Logic
	 * @param dimension the Dimension
	 */
	public World(SokoLogic logic,Dimension dimension) {
		this.logic = logic;
		this.dimension = dimension;
		pieces = new Vector();
	}
	
	/**
	 * Moves all the Pieces into a given direction.
	 * @param direction
	 * @return a <code>boolean</code> specifying if the move was succesfull or not
	 */
	public boolean move(int direction) {
		boolean succes = true;
		Enumeration e = pieces.elements();
		while (e.hasMoreElements()) {
			Piece piece = (Piece)e.nextElement();
			if (!piece.move(direction)) {
				succes = false;
			}
		}
		return succes;
	}
	
	/**
	 * Moves a Piece into a given direction.
	 * @param piece the Piece
	 * @param direction the direction
	 * @return a <code>boolean</code> specifying if the move was succesfull or not
	 */
	public boolean move(Piece piece,int direction) {
		return piece.move(direction);
	}

	/**
	 * Adds a Piece to this World.
	 * @param piece the Piece
	 * @return a <code>boolean</code> specifying if the Piece was added or not
	 */
	public boolean add(Piece piece) {
		piece.addVetoableChangeListener(this);
		piece.addPropertyListener(this);
		Enumeration e = pieces.elements();
		while (e.hasMoreElements()) {
			Piece p = (Piece)e.nextElement();
			piece.addVetoableChangeListener(p);
			piece.addPropertyListener(p);
		}
		if (piece.move(Direction.INSERT)) {
			e = pieces.elements();
			while (e.hasMoreElements()) {
				Piece p = (Piece)e.nextElement();
				p.addVetoableChangeListener(piece);
				p.addPropertyListener(piece);
			}		
			pieces.add(piece);
			return true;
		}
		return false;		
	}
	
	/**
	 * Removes a given Piece from this World.
	 * @param piece the Piece
	 * @return a <code>boolean</code> specifying if the piece was removed or not
	 */
	public boolean removePiece(Piece piece) {
		if (piece.move(Direction.REMOVE)) {
			pieces.remove(piece);
			Enumeration e = pieces.elements();
			while (e.hasMoreElements()) {
				Piece p = (Piece)e.nextElement();
				piece.removeVetoableChangeListener(p);
				piece.removePropertyListener(p);
				p.removeVetoableChangeListener(piece);
				p.removePropertyListener(piece);
			}
			piece.removePropertyListener(this);
			piece.removeVetoableChangeListener(this);		
			return true;
		} 
		return false;
	}
	
	/**
	 * Gives the Dimension of this World.
	 * @return a <code>Dimension</code> specifying the Dimension of this World
	 */
	public Dimension getDimension() {
		return dimension;
	}
	
	/**
	 * Returns all the pieces.
	 * @return a <code>Vector</code> containing all the pieces
	 */
	public Vector pieces() {
		return pieces;
	}

	/**
	 * Returns a Piece with the given name.
	 * @param name the name
	 * @return a <code>Piece</code> as requested
	 */
	public Piece findPiece(String name) {
		Enumeration e = pieces.elements();
		while (e.hasMoreElements()) {
			Piece piece = (Piece)e.nextElement();
			if (piece.getName().equals(name)) {
				return piece;
			}
		}
		return null;
	}

	/**
	 * Returns all the Pieces with the givin name
	 * @param name the name
	 * @return a <code>Vector</code> containing all the Pieces
	 */
	public Vector findPieces(String name) {
		Enumeration e = pieces.elements();
		Vector piecesFound = new Vector();
		while (e.hasMoreElements()) {
			Piece piece = (Piece)e.nextElement();
			if (piece.getName().equals(name)) {
				piecesFound.add(piece);
			}
		}
		return piecesFound;
	}

	/* (non-Javadoc)
	 * @see java.beans.PropertyChangeListener#propertyChange(java.beans.PropertyChangeEvent)
	 */
	public void propertyChange(PropertyChangeEvent e) {
		if (e instanceof PositionChangeEvent) {
			logic.worldEvent((PositionChangeEvent)e);
		}
	}

	/* (non-Javadoc)
	 * @see java.beans.VetoableChangeListener#vetoableChange(java.beans.PropertyChangeEvent)
	 */
	public void vetoableChange(PropertyChangeEvent e) throws PropertyVetoException {
		if (e instanceof PositionChangeEvent) {
			PositionChangeEvent pce = (PositionChangeEvent)e;
			if (pce.getDirection() != Direction.INSERT || pce.getDirection() != Direction.REMOVE) {
				Position position = (Position) e.getNewValue();
				int x = position.getX();
				int y = position.getY();
				if (x < 0 || x >= dimension.getWidth() || y < 0 || y >= dimension.getHeight()) {
					throw new PropertyVetoException("INVALID POSITON",e);
				}
			}
		}		
	}

}

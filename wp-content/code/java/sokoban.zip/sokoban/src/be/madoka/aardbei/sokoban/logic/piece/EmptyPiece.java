/*
 * Created on Jun 11, 2003 5:11:00 PM
 */
package be.madoka.aardbei.sokoban.logic.piece;

import be.madoka.aardbei.sokoban.*;
import be.madoka.aardbei.sokoban.logic.*;

/**
 * Represents an Empty Piece.
 * @author Tim Van Wassenhove
 */
public class EmptyPiece extends Piece {

	private static final String NAME = "EMPTY";

	/**
	 * Default constructor.
	 * @param position the Position
	 */
	public EmptyPiece(Position position) {
		super(position);
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.Piece#getName()
	 */
	public String getName() {
		return NAME;
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.Piece#getNewPosition(int)
	 */
	protected Position getNewPosition(int direction) {
		return getPosition();
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.Piece#testCollision(be.madoka.aardbei.sokoban.PositionChangeEvent)
	 */
	protected boolean testCollision(PositionChangeEvent e) {
		return false;
	}
	
}

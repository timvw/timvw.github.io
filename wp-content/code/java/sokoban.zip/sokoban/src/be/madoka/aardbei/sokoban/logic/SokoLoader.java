/*
 * Created on Jun 12, 2003 10:03:54 PM
 */
package be.madoka.aardbei.sokoban.logic;

/**
 * Generates Worlds
 * @author Tim Van Wassenhove
 */
public interface SokoLoader {

	/**
	 * Tests if another World is available.
	 * @return a <code>boolean</code> specifying if at least one more world can be loaded
	 */
	public boolean hasMoreWorlds();
	
	/**
	 * Tests if the requested World is available.
	 * @return a <code>boolean</code> specifying if the requested level is available
	 */
	public boolean hasWorld(int level);
	
	/**
	 * Loads the next World.
	 * @return a <code>World</code>
	 */
	public World nextWorld();
	
	/**
	 * Loads the World belonging to the given level.
	 * @param level the level
	 * @return a <code>World</code>
	 */
	public World getWorld(int level);

}

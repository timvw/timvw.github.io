/*
 * Created on Jun 17, 2003 11:16:09 AM
 */
package be.madoka.aardbei.sokoban.logic.loader;

import java.io.*;
import java.util.*;
import be.madoka.aardbei.sokoban.*;
import be.madoka.aardbei.sokoban.logic.*;
import be.madoka.aardbei.sokoban.logic.piece.*;
import org.jdom.*;
import org.jdom.input.*;

/**
 * @author Tim Van Wassenhove
 */
public class XMLSokoLoader implements SokoLoader {

	private SokoLogic logic;
	private int counter;
	private String fileName;
	
	/**
	 * Default constructor.
	 * @param fileName the fileName
	 */
	public XMLSokoLoader(SokoLogic logic,String fileName) {
		this.logic = logic;
		this.fileName = fileName;
		counter = 0;
	}

	/**
	 * Returns the number of levels in the file.
	 * @return an <code>int</code> specifying the available levels
	 */
	protected int countLevels() {
		int count = 0;
		try {
			SAXBuilder builder = new SAXBuilder(false);
			Document doc = builder.build(fileName);
			Element game = doc.getRootElement();		
			List levels= game.getChildren();
			count = levels.size();
		} catch(JDOMException jde) {
			jde.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}	finally {
			return count;	
		}		
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.SokoLoader#hasMoreWorlds()
	 */
	public boolean hasMoreWorlds() {
		if (counter < countLevels()) {
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.SokoLoader#nextWorld()
	 */
	public World nextWorld() {
		if (hasMoreWorlds()) {
			counter++;
			return getWorld(counter);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.SokoLoader#getWorld(int)
	 */
	public World getWorld(int level) {
		if (level <= countLevels()) {
			try {
				SAXBuilder builder = new SAXBuilder(false);
				Document doc = builder.build(fileName);
				Element game = doc.getRootElement();		
				List levels= game.getChildren();
				int count = 1;
				ListIterator levelsIterator = levels.listIterator();
				while (count < level) {
					count++;
					Element e = (Element)levelsIterator.next();
				}
				Element track = (Element)levelsIterator.next();
				World world = new World(logic,new Dimension(track.getAttribute("width").getIntValue(),track.getAttribute("height").getIntValue()));
				List lines = track.getChildren();
				ListIterator linesIterator = lines.listIterator();
				int posY = 0;
				while (linesIterator.hasNext()) {
					Element line = (Element)linesIterator.next();
					List columns = line.getChildren();
					ListIterator columnsIterator = columns.listIterator();
					int posX = 0;
					while (columnsIterator.hasNext()) {
						Element piece = (Element)columnsIterator.next();
						String name = piece.getName();
						if (name.equals("e")) {
							Piece p = new EmptyPiece(new Position(posX,posY));
							world.add(p);
						} else if (name.equals("w")) {
							Piece p = new WallPiece(new Position(posX,posY));
							world.add(p);
						} else if (name.equals("t")) {
							Piece p = new GoalPiece(new Position(posX,posY));
							world.add(p);
							if (piece.getAttribute("inc") != null) {
								String name2 = piece.getAttribute("inc").getName();
								if (name2.equals("h")) {
									Piece p2 = new HeroPiece(new Position(posX,posY));
									world.add(p2);	
								} else if (name2.equals("b")) {
									Piece p2 = new TreasurePiece(new Position(posX,posY));
									world.add(p2);									
								}
							}
						} else if (name.equals("h")) {
							Piece p = new EmptyPiece(new Position(posX,posY));
							world.add(p);
							Piece p2 = new HeroPiece(new Position(posX,posY));
							world.add(p2);	
						} else if (name.equals("b")) {
							Piece p = new EmptyPiece(new Position(posX,posY));
							world.add(p);
							Piece p2 = new TreasurePiece(new Position(posX,posY));
							world.add(p2);
						}
						posX++;
					}
					posY++;					
				}
				return world;
			} catch(JDOMException jde) {
				jde.printStackTrace();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		} 
		return null;
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.SokoLoader#hasWorld(int)
	 */
	public boolean hasWorld(int level) {
		return (level <= countLevels());
	}

}

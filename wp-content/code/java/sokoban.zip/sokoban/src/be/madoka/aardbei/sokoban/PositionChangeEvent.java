/*
 * Created on Jun 12, 2003 9:21:35 PM
 */
package be.madoka.aardbei.sokoban;

import java.beans.PropertyChangeEvent;

/**
 * Represents a change of Position.
 * @author Tim Van Wassenhove
 */
public class PositionChangeEvent extends PropertyChangeEvent {

	private int direction;

	/**
	 * Default constructor.
	 * @param object the object
	 * @param oldPosition the old Position
	 * @param newPosition the new Position
	 * @param direction the direction
	 */
	public PositionChangeEvent(Object object,Position oldPosition,Position newPosition,int direction) {
		super(object,"position",oldPosition,newPosition);
		this.direction = direction;
	}

	/**
	 * Gives the direction of the PositionChangeEvent.
	 * @return a <code>int</code> specifying the direction
	 */
	public int getDirection() {
		return direction;
	}

}

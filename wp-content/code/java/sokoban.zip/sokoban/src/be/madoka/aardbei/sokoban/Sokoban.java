/*
 * Created on Jun 12, 2003 8:50:30 PM
 */
package be.madoka.aardbei.sokoban;

import be.madoka.aardbei.sokoban.logic.*;
import be.madoka.aardbei.sokoban.visualisation.*;

/**
 * Initialise a Logic, add a Visualisation and play the game.
 * @author Tim Van Wassenhove
 */
public class Sokoban {

	/**
	 * This is the main entry-point for the Sokoban game.
	 * @param args
	 */
	public static void main(String[] args) {
		Logic logic = new SokoLogic();
		Visualisation gui = new SokoGui(logic);
		logic.addVisualisation(gui);
	}

}

/*
 * Created on Jun 12, 2003 9:34:21 PM
 */
package be.madoka.aardbei.sokoban.visualisation;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import be.madoka.aardbei.sokoban.*;

/**
 * Not only provides a Visualisation of a Logic,
 * but also generates input-events for a Logic.
 * @author Tim Van Wassenhove
 */
public class SokoGui extends JFrame implements Visualisation, KeyListener, ActionListener {

	private Logic logic;
	private String playerName;
	
	private SokoPanel panel;
	private SokoBar bar;
	
	private JMenu fileMenu;
	private JMenuItem startItem,stopItem,exitItem;

	private JMenu lookMenu;
	private JMenuItem[] lookItem;

	private JMenu helpMenu;
	private JMenuItem helpItem,aboutItem;
	
	/**
	 * Default constructor.
	 * @param logic the Logic
	 */
	public SokoGui(Logic logic) {
		super(logic.getName());
		this.logic = logic;
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		
		panel = new SokoPanel();
		c.add(panel,BorderLayout.CENTER);
		
		bar = new SokoBar();
		c.add(bar,BorderLayout.SOUTH);
		
		addKeyListener(this);
		setJMenuBar(createMenuBar());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500,400);
		setVisible(true);
		
		while (playerName == null || playerName.length() <= 0) {
			playerName = JOptionPane.showInputDialog(this,"Enter your name: ");
		}
	}
	
	/**
	 * Initialises a JMenuBar.
	 * @return a <code>JMenuBar</code>
	 */
	protected JMenuBar createMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		startItem = new JMenuItem("Start");
		startItem.setMnemonic(KeyEvent.VK_S);
		startItem.addActionListener(this);
		fileMenu.add(startItem);
		stopItem = new JMenuItem("Stop");
		stopItem.setMnemonic(KeyEvent.VK_T);
		stopItem.addActionListener(this);
		fileMenu.add(stopItem);
		fileMenu.addSeparator();
		exitItem = new JMenuItem("Exit");
		exitItem.setMnemonic(KeyEvent.VK_X);
		exitItem.addActionListener(this);
		fileMenu.add(exitItem);
		menuBar.add(fileMenu);

		lookMenu = new JMenu("Look");
		lookMenu.setMnemonic(KeyEvent.VK_L);
		UIManager.LookAndFeelInfo[] info = UIManager.getInstalledLookAndFeels();
		lookItem = new JMenuItem[info.length];
		for (int i=0;i<info.length;i++) {
			lookItem[i] = new JMenuItem(info[i].getClassName());
			lookItem[i].addActionListener(this);
			lookMenu.add(lookItem[i]);
		}
		menuBar.add(lookMenu);

		helpMenu = new JMenu("Help");
		helpMenu.setMnemonic(KeyEvent.VK_H);
		helpItem = new JMenuItem("Help Contents");
		helpItem.setMnemonic(KeyEvent.VK_H);
		helpItem.addActionListener(this);
		helpMenu.add(helpItem);
		helpMenu.addSeparator();
		aboutItem = new JMenuItem("About "+logic.getName());
		aboutItem.setMnemonic(KeyEvent.VK_A);
		aboutItem.addActionListener(this);
		helpMenu.add(aboutItem);
		menuBar.add(helpMenu);
		
		return menuBar;
	}

	/**
	 * Sets the Look and Feel to the given Look&Feel-Name.
	 * @param lnfName the Look And Feel Name
	 */	
	protected void setLook(String lnfName) {
		try {
			UIManager.setLookAndFeel(lnfName);
			SwingUtilities.updateComponentTreeUI(this);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	

	/**
	 * Asks the user for a XML file containing SokoWorlds.
	 * @return a <code>String</code> specifying the path of this file
	 */
	protected String getLevelFile() {
		JFileChooser chooser = new JFileChooser();
		int returnVal = chooser.showOpenDialog(this);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
				return chooser.getSelectedFile().getPath();
		}
		return null;
	}
	
	/**
	 * Shows a HelpDialog
	 */
	protected void showHelp() {
		JOptionPane.showMessageDialog(this,"Sokoban means warehouse keeper in Japanese.\nThe object of the game is to push boxes (or balls) into their correct position\nin a crowded warehouse with a minimal number of pushes and moves.\nThe boxes can only be pushed, never pulled,\nand only one can be pushed at a time.\nIt sounds easy, but the levels range from very easy to extremely difficult,\nsome takes hours and even days to figure out.\nThe simplicity and elegance of the rules have made Sokoban one of the most popular logic games.","Help",JOptionPane.INFORMATION_MESSAGE);
	}

	/**
	 * Shows an AboutDialog
	 */
	protected void showAbout() {
		JOptionPane.showMessageDialog(this,logic.getInfo(),"About "+logic.getName(),JOptionPane.INFORMATION_MESSAGE);
	}

	/**
	 * A key has been typed.
	 * @param e the KeyEvent
	 */
	public void keyTyped(KeyEvent e) {
	}

	/**
	 * A key has been released.
	 * @param e the KeyEvent
	 */
	public void keyReleased(KeyEvent e) {
	}

	/**
	 * A key has been pressed.
	 * @param e the KeyEvent
	 */
	public void keyPressed(KeyEvent e) {
		boolean validMove = true;
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			validMove = logic.move(Direction.DOWN);
		} else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			validMove = logic.move(Direction.UP);
		} else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			validMove = logic.move(Direction.LEFT);
		} else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			validMove = logic.move(Direction.RIGHT);
		} else if (e.getKeyCode() == KeyEvent.VK_U) {
			validMove = logic.move(Direction.UNDO_MOVE);
		} else if (e.getKeyCode() == KeyEvent.VK_L) {
			validMove = logic.move(Direction.UNDO_LEVEL);
		}
		if (!validMove) {
			// play some annoying sound to announce collision :)
		}
	}
	
	/**
	 * An action has been performed.
	 * @param event the event
	 */
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == startItem) {
			String fileName = getLevelFile();
			if (fileName != null && fileName.length() != 0) {
				logic.start(playerName,fileName);
			}
		} else if (event.getSource() == stopItem) {
			logic.end();
		} else if (event.getSource() == exitItem) {
			logic.end();
			System.exit(0);
		} else if  (event.getSource() == helpItem) {
			showHelp();
		} else if (event.getSource() == aboutItem) {	
			showAbout();
		} else {
			for (int i=0;i<lookItem.length;i++) {
				if (event.getSource() == lookItem[i]) {
					setLook(event.getActionCommand());
				}
			}
		}
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Visualisation#updatePosition(be.madoka.aardbei.sokoban.PositionChangeEvent)
	 */
	public void updatePosition(PositionChangeEvent e) {
		panel.update(e);
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Visualisation#updateLevel(be.madoka.aardbei.sokoban.LevelChangeEvent)
	 */
	public void updateLevel(LevelChangeEvent e) {
		bar.updateLevel(e.getValue());	
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Visualisation#updateScore(be.madoka.aardbei.sokoban.ScoreChangeEvent)
	 */
	public void updateScore(ScoreChangeEvent e) {
		bar.updateScore(e.getValue());
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Visualisation#updateDimension(be.madoka.aardbei.sokoban.DimensionChangeEvent)
	 */
	public void updateDimension(DimensionChangeEvent e) {
		panel.update(e);
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Visualisation#levelCompleted(boolean)
	 */
	public void levelCompleted(boolean succes) {
		panel.levelCompleted();
		if (succes) {
			JOptionPane.showMessageDialog(this,"Congratulations U completed this level!!!","Level End",JOptionPane.INFORMATION_MESSAGE);		
		} else {
			JOptionPane.showMessageDialog(this,"The level has been ended.","Level Completed",JOptionPane.INFORMATION_MESSAGE);		
		}
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.Visualisation#gameCompleted(boolean)
	 */
	public void gameCompleted(boolean succes) {
		if (succes) {
			JOptionPane.showMessageDialog(this,"Congratulations U completed this game!!!","Game End",JOptionPane.INFORMATION_MESSAGE);
		} else {
			JOptionPane.showMessageDialog(this,"The game has been ended.","Game End",JOptionPane.INFORMATION_MESSAGE);			
		}
	}	

}

/*
 * Created on Jun 11, 2003 5:09:45 PM
 */
package be.madoka.aardbei.sokoban.logic.piece;

import be.madoka.aardbei.sokoban.*;

/**
 * Represents a Wall.
 * @author Tim Van Wassenhove
 */
public class WallPiece extends EmptyPiece {

	private static final String NAME = "WALL";

	/**
	 * Default constructor.
	 * @param position the Position
	 */
	public WallPiece(Position position) {
		super(position);
	}

	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.Piece#getName()
	 */
	public String getName() {
		return NAME;
	}
	
	/* (non-Javadoc)
	 * @see be.madoka.aardbei.sokoban.logic.Piece#testCollision(be.madoka.aardbei.sokoban.PositionChangeEvent)
	 */
	public boolean testCollision(PositionChangeEvent e) {
		Position pos = (Position)e.getNewValue();
		if (getPosition().equals(pos)) {
			return true;
		} 
		return false;
	}

}

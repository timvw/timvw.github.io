/*
 * Created on Jun 16, 2003 5:56:08 PM
 */
package be.madoka.aardbei.sokoban;

import java.beans.PropertyChangeEvent;

/**
 * Represents a scorechange.
 * @author Tim Van Wassenhove
 */
public class ScoreChangeEvent extends PropertyChangeEvent {

	/**
	 * Constructor mostly used for classes extending this class.
	 * @param logic the logic
	 * @param name the name
	 * @param newScore the new score
	 */	
	protected ScoreChangeEvent(Logic logic,String name,int newScore) {
		super(logic,name,null,new Integer(newScore));
	}

	/**
	 * Default constructor.
	 * @param logic the logic
	 * @param newScore the new score
	 */
	public ScoreChangeEvent(Logic logic,int newScore) {
		this(logic,"score",newScore);
	}

	/**
	 * Returns the new value.
	 * @return an <code>int</code> giving the new value
	 */
	public int getValue() {
		if (getNewValue() != null) {
			return ((Integer)getNewValue()).intValue();
		}
		return 0;
	}

}

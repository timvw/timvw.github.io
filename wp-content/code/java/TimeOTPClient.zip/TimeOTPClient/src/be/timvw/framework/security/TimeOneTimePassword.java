package be.timvw.framework.security;

import java.util.*;
import org.bouncycastle.math.*;
import org.bouncycastle.crypto.*;
import org.bouncycastle.crypto.digests.*;
import org.bouncycastle.crypto.macs.*;
import org.bouncycastle.crypto.params.*;

public class TimeOneTimePassword extends HmacOneTimePassword
{
	private Date epoch;
	private int timeStep;

	public TimeOneTimePassword(String secret)
	{
		this(secret, new SHA1Digest(), 6, new Date(0), 30);
	}

	public TimeOneTimePassword(String secret, Digest digest, int numberOfDigits, Date epoch, int timeStep)
	{
		super(secret, digest, numberOfDigits);
		this.epoch = epoch;
		this.timeStep = timeStep;
	}

	public String getPassword()
	{
		long iterationTime = System.currentTimeMillis() / 1000;
		return this.getPassword(getIterationNumber(iterationTime));
	}

	public String getPassword(Date iterationTime)
	{
	    return getPassword(getIterationNumber(iterationTime.getTime()));
	}

	public long getIterationNumber(long iterationTime)
	{
	    return (long)((iterationTime - this.epoch.getTime()) / this.timeStep);
	}
}

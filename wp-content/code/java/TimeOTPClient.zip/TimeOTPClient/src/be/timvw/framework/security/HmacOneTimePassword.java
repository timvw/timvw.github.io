package be.timvw.framework.security;

import org.bouncycastle.math.*;
import org.bouncycastle.crypto.*;
import org.bouncycastle.crypto.digests.*;
import org.bouncycastle.crypto.macs.*;
import org.bouncycastle.crypto.params.*;

public class HmacOneTimePassword
{
	private static final int[] DIGITS_POWER = { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000 };

	private Mac hmac;
	private int numberOfDigits;

	public HmacOneTimePassword(String secret)
	{
		this(secret, new SHA1Digest(), 6);
	}

	public HmacOneTimePassword(String secret, Digest digest, int numberOfDigits)
	{
		try
		{
			this.hmac = new HMac(digest);
			this.hmac.init(new KeyParameter(secret.getBytes("ASCII")));
			this.numberOfDigits = numberOfDigits;
		}
		catch (java.io.UnsupportedEncodingException e)
		{
			// ascii is pretty standard, we should never get here.
		}
	}

	public byte[] computeHash(byte[] text)
	{
		this.hmac.update(text, 0, text.length);

		byte[] hash = new byte[this.hmac.getMacSize()];
		this.hmac.doFinal(hash, 0);

		return hash;
	}

	public byte[] getHash(long iterationNumber)
	{
		byte[] text = new byte[8];
		for (int i = text.length - 1; i >= 0; i--)
		{
			text[i] = (byte)(iterationNumber & 0xff);
			iterationNumber >>= 8;
		}
		return computeHash(text);
	}

	public String getPassword(long iterationNumber)
	{
		byte[] hash = getHash(iterationNumber);

		int offset = hash[hash.length - 1] & 0xf;
		int binary = ((hash[offset] & 0x7f) << 24) | ((hash[offset + 1] & 0xff) << 16) | ((hash[offset + 2] & 0xff) << 8) | (hash[offset + 3] & 0xff);

		int otp = binary % DIGITS_POWER[this.numberOfDigits];

		String result = "" + otp;
		while (result.length() < this.numberOfDigits)
		{
			result = "0" + result;
		}
		return result;
	}

}

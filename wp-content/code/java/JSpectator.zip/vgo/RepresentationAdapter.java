public class RepresentationAdapter implements RepresentationIF {
	public RepresentationAdapter() {
	}

	public void setChannel(String channel){
	}

	public void spectatorJoin(String nick){
	}

	public void spectatorLeave(String nick){
	}

	public void playerJoin(int slot,String nick){
	}

	public void playerLeave(int slot){
	}

	public void updateTeam(int slot,String team){
	}

	public void updateField(int slot,char[][] field){
	}

	public void partyMessage(int slot,String msg){
	}

	public void partyAct(int slot,String msg){
	}

	public void spectatorMessage(String spectator,String msg){
	}

	public void spectatorAct(String spectator,String msg){
	}

	public void gameMessage(int slot,String msg){
	}

	public void gameSpecial(int slot,String special){
	}

	public void gameEvent(int slot,int event){
	}

	public void updateWinlist(String[][] winlist) {
	}

	public void playerEvent(int slot,int status){
	}

}
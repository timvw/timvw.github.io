import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import java.util.*;

public class JChat extends JFrame implements ConstantsIF {
	private MessageProcessor proc;
	private Container c;
	private EventHandler listener;
	private JEditorPane chatText;
	private JScrollPane chatScroll;
	private JTextField chatInput;

	public JChat(MessageProcessor processor) {
		super(APP_NAME);
		proc = processor;
		c = getContentPane();
		c.setLayout(new BorderLayout());
		listener = new EventHandler();
		chatText = new JEditorPane();
		chatText.setContentType("text/html");
		chatText.setEditable(false);
		chatScroll = new JScrollPane(chatText,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		chatScroll.setPreferredSize(new Dimension(300,300));
		c.add(chatScroll,BorderLayout.CENTER);
		chatInput = new JTextField(50);
		chatInput.addActionListener(listener);
		c.add(chatInput,BorderLayout.SOUTH);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		pack();
	}

	public void addMessage(String spectator,String msg) {
		HTMLDocument doc = (HTMLDocument) chatText.getDocument();
		Element e = doc.getDefaultRootElement().getElement(0).getElement(0);
		try {
			doc.insertBeforeEnd(e,"*"+spectator+"* "+msg+"<br>");
			chatText.setCaretPosition(doc.getLength());
		} catch (Exception ex) {
			System.out.println(ex.toString());
		}
	}

	public void addMessage(String msg) {
		addMessage("--> ",msg);
	}

	public void clear() {
		chatText.setText("");
	}

	class EventHandler implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == chatInput) {
				String in = chatInput.getText();
				if (in.length() != 0) {
					if (in.startsWith("/me")) {
						proc.sendSpectatorAct(in.substring(3));
						addMessage("<font color=\"magenta\">*** "+in.substring(3)+"</font>");
					} else {
						proc.sendSpectatorMessage(in);
						addMessage(in);
					}
					chatInput.setText("");
				}
			}
		}
	}
}

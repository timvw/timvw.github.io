import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JMultiInputBox extends JDialog {
	private static final int LENGTH_INPUT = 15;

	public static String[] getValues(JFrame fr,String title,Question[] question) {
		JDialog dialog = new JDialog();
		Container c = dialog.getContentPane();
		c.setLayout(new GridLayout(question.length,2));
		JLabel[] label = new JLabel[question.length];
		JTextField[] input = new JTextField[question.length];
		for(int i=0;i<question.length;i++) {
			label[i] = new JLabel(question[i].getQuestion());
			c.add(label[i]);
			if (question[i].getType() == Question.PASSWORD) {
				input[i] = new JPasswordField(LENGTH_INPUT);
			} else {
				input[i] = new JTextField(LENGTH_INPUT);
			}
			c.add(input[i]);
		}
		String[] result = new String[question.length];
		int choice = JOptionPane.showOptionDialog(fr,c,title,JOptionPane.DEFAULT_OPTION,JOptionPane.QUESTION_MESSAGE ,null,new Object[]{"Login","Cancel"},null);
		if(choice == JOptionPane.OK_OPTION) {
			for(int i=0;i<question.length;i++) {
				result[i] = input[i].getText();
			}
		}
		return result;
	}

	public static String[] getValues(String title,Question[] question) {
		return getValues(null,title,question);
	}

	public static String[] getValues(Question[] question) {
		return getValues("Question",question);
	}
}
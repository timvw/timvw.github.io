public class Player implements ConstantsIF {
	private String nick;
	private String team;
	private char[][] playField;

	public Player(String nick) {
		this.nick = nick;
		playField = new char[CNT_COLS][CNT_ROWS];
		clearField();
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getNick() {
		return nick;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getTeam() {
		if (team == null || team.length() == 0) {
			return null;
		} else {
			return team;
		}
	}

	public char[][] getField() {
		return playField;
	}

	public void clearField () {
		for (int x=0;x<playField.length;x++) {
			for (int y=0;y<playField[x].length;y++) {
				playField[x][y] = 0;
			}
		}
	}

	public void updateField(String buf) {
		char p;
  	char blocktype,x,y;
  	int bailout = 0;
  	int teller = 0;

  	if (buf.length() == (playField.length * playField[0].length)) {
  		teller = 0;
  		if ((buf.charAt(teller) > '/') || (buf.charAt(teller) < '!')) {
    	 	p = buf.charAt(teller);
    	 	for (int i=0;i<playField.length;i++) {
    	 		for (int j=0;j<playField[i].length;j++) {
    	    	blocktype = p;
   	       	teller++;
   	       	playField[i][j]= (char) (blocktype - '0');
        	}
    	  }
   	 	} else {
				bailout=1;
			}
   	} else {
			p = buf.charAt(teller);
			while (bailout == 0 && (p != 255) && (teller < buf.length())) {
      	blocktype = p;
      	if ((blocktype > '/') || (blocktype < '!')) {
      		bailout=1;
      	} else {
      		teller++;
      		if (teller < buf.length()) {
      			p = buf.charAt(teller);
      		}
      		blocktype -= '!';
      		while (bailout == 0 && (p != 255) && ((teller+1) < buf.length()) && (p >= '3') && (p <= '>')) {
        		x = p;
        		teller++;
          	y = buf.charAt(teller);
          	teller++;
          	if (teller < buf.length()) {
          		p = buf.charAt(teller);
          	}
						if ((x >= '3') && (x <= '>') && (y >= '3') && (y <= 'H')) {
          		x -= '3';
            	y -= '3';
            	playField[x][y] = blocktype;
          	}
          }
        }
      }
    }
	}
}
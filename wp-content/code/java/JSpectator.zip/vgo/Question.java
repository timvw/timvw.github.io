public class Question {
	public static final int TEXT 			= 0;
	public static final int PASSWORD 	= 1;

	private String question;
	private int type;

	public Question(String question,int type) {
		this.question = question;
		if (type >= 0 && type <= PASSWORD) {
			this.type = type;
		} else {
			this.type = TEXT;
		}
	}

	public Question(String question) {
		this(question,TEXT);
	}

	public String getQuestion() {
		return question;
	}

	public int getType() {
		return type;
	}
}
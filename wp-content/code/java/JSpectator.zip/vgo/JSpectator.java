import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JSpectator extends JFrame implements ConstantsIF, RepresentationIF {
	private Container c;
	private EventHandler listener;
	private MessageProcessor proc;
	private Communication io;
	private JGame game;
	private JChat chat;
	private JWinlist winlist;
	private JParty party;
	private JToolBar tool;
	private JButton toolConnect,toolFields,toolParty,toolWinlist,toolSpec;
	private JMenuBar menu;
	private JMenu menuFile,menuHelp;
	private JMenuItem itemOpen,itemClose,itemExit,itemAbout;

	public JSpectator () {
		super(APP_NAME);
		proc = new MessageProcessor(this);
		c = getContentPane();
		c.setLayout(new BorderLayout());
		listener = new EventHandler();
		game = new JGame(proc);
		chat = new JChat(proc);
		winlist = new JWinlist();
		party = new JParty(proc);
		c.add(party,BorderLayout.CENTER);
		c.add(createToolBar(listener),BorderLayout.SOUTH);
		setJMenuBar(createMenuBar(listener));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
	}

	protected JMenuBar createMenuBar(ActionListener a) {
		menu = new JMenuBar();
		menuFile = new JMenu("File");
		menuFile.setMnemonic(KeyEvent.VK_F);
		itemOpen = new JMenuItem("Open");
		itemOpen.setMnemonic(KeyEvent.VK_O);
		itemOpen.addActionListener(a);
		menuFile.add(itemOpen);
		itemClose = new JMenuItem("Close");
		itemClose.setMnemonic(KeyEvent.VK_C);
		itemClose.addActionListener(a);
		menuFile.add(itemClose);
		menuFile.addSeparator();
		itemExit = new JMenuItem("Exit");
		itemExit.setMnemonic(KeyEvent.VK_X);
		itemExit.addActionListener(a);
		menuFile.add(itemExit);
		menu.add(menuFile);
		menuHelp = new JMenu("Help");
		menuHelp.setMnemonic(KeyEvent.VK_H);
		itemAbout = new JMenuItem("About "+APP_NAME+"...");
		itemAbout.setMnemonic(KeyEvent.VK_A);
		itemAbout.addActionListener(a);
		menuHelp.add(itemAbout);
		menu.add(menuHelp);
		return menu;
	}

	protected JToolBar createToolBar(ActionListener a) {
		tool = new JToolBar();
		toolConnect = new JButton("connect");
		toolConnect.addActionListener(a);
		tool.add(toolConnect);
		toolFields = new JButton("fields");
		toolFields.addActionListener(a);
		tool.add(toolFields);
		toolParty = new JButton("partyline");
		toolParty.addActionListener(a);
		tool.add(toolParty);
		toolWinlist = new JButton("winlist");
		toolWinlist.addActionListener(a);
		tool.add(toolWinlist);
		toolSpec = new JButton("spectators");
		toolSpec.addActionListener(a);
		tool.add(toolSpec);
		return tool;
	}

	public void setChannel(String channel){
		party.addMessage(0,"<font color=\"green\">U have joined "+channel+"</font>");
		party.clear();
	}

	public void spectatorJoin(String nick){
		party.addSpectator(nick);
		chat.addMessage("server","spectator "+nick+" has joined");
	}

	public void spectatorLeave(String nick){
		party.removeSpectator(nick);
		chat.addMessage("server","spectator "+nick+" has left");
	}

	public void playerJoin(int slot,String nick){
		party.addPlayer(slot,nick);
		game.addPlayer(slot,nick);
	}

	public void playerLeave(int slot){
		party.removePlayer(slot);
		game.removePlayer(slot);
	}

	public void updateTeam(int slot,String team){
		party.updateTeam(slot,team);
		game.updateTeam(slot,team);
	}

	public void updateField(int slot,char[][] field){
		game.updateField(slot,field);
	}

	public void partyMessage(int slot,String msg){
		party.addMessage(slot,msg);
	}

	public void partyAct(int slot,String msg){
		party.addMessage(slot,"<font color=\"magenta\">*** "+msg+"</font>");
	}

	public void spectatorMessage(String spectator,String msg){
		chat.addMessage(spectator,msg);
	}

	public void spectatorAct(String spectator,String msg){
		chat.addMessage(spectator,"<font color=\"magenta\">*** "+msg+"</font>");
	}

	public void gameMessage(int slot,String msg){
		game.addMessage("<"+slot+"> "+msg);
	}

	public void gameSpecial(int slot,String special){
		game.addMessage("<font color=\"magenta\">*"+slot+"* special block: "+special+"</font>");
	}

	public void gameEvent(int slot,int event){
		StringBuffer str = new StringBuffer();
		str.append("<font color=\"red\">");
		switch (event) {
			case GAME_START					: str.append("game has started");game.newgame();break;
			case GAME_PAUSE					: str.append("game has been paused");break;
			case GAME_UNPAUSE 			: str.append("game has been unpaused");break;
			case GAME_STOP 					: str.append("game has stopped");break;
			case GAME_END 					: str.append("game has ended");break;
			case GAME_DISCONNECTED 	: str.append("we are disconnected!");disconnect();break;
			case GAME_INGAME 				: str.append("game is running");break;
			default									: str.append("unknown event");
		}
		str.append("</font>");
		party.addMessage(slot,str.toString());
	}

	public void updateWinlist(String[][] win) {
		winlist.updateWinlist(win);

	}

	public void playerEvent(int slot,int status){
		StringBuffer str = new StringBuffer();
		str.append("<font color=\"red\">");
		switch (status) {
			case PLAYER_WAITING 	: str.append(" is waiting");break;
			case PLAYER_INGAME 		: str.append(" is ingame");break;
			case PLAYER_LOST 			: str.append(" has lost");break;
			case PLAYER_WON				: str.append(" has won");break;
			case PLAYER_KICK			: str.append(" has been kicked");break;
			default 							: str.append(" unknown status");
		}
		str.append("</font>");
		party.addMessage(slot,str.toString());
	}

	protected void showAboutDialog() {
		JOptionPane.showMessageDialog(this,APP_NAME+" Version "+APP_VERSION+"\nBy "+APP_AUTHOR,"About "+APP_NAME,JOptionPane.INFORMATION_MESSAGE);
	}

	protected void showConnectDialog() {
		if ((io == null) || (!io.valid())) {
			Question[] question = new Question[3];
			question[0] = new Question("Hostname: ",Question.TEXT);
			question[1] = new Question("Username: ",Question.TEXT);
			question[2] = new Question("Password: ",Question.PASSWORD);
			String[] account = JMultiInputBox.getValues(this,"Account...",question);
			if (account != null && account[0] != null) {
				io = new Communication(account[0],account[1],account[2]);
				boolean open = false;
				int tries = 0;
				while (!open && tries < 5) {
					open = io.open();
					tries++;
				}
				if (open) {
					toolConnect.setText("Disconnect");
					party.addMessage(0,"Connected to "+account[0]);
					proc.setName(account[1]);
					proc.setCommunication(io);
				} else {
					party.addMessage(0,"Connecting to "+account[0]+" failed!");
					proc.setCommunication(null);
					io = null;
				}
			}
		} else {
			JOptionPane.showMessageDialog(this,"You are alreade connected!\nDisconnect first!","Error",JOptionPane.ERROR_MESSAGE);
		}
	}

	protected void showDisconnectDialog() {
		if (JOptionPane.OK_OPTION == JOptionPane.showConfirmDialog(this,"Really Disconnect?","Disconnecting...",JOptionPane.YES_NO_OPTION)) {
			disconnect();
		}
	}

	protected void disconnect() {
		if (io != null) {
			io.close();
			io = null;
			proc.setCommunication(io);
		}
		toolConnect.setText("Connect");
		party.addMessage(0,"<font color=\"red\">Disconnected!</font>");
		party.clear();
		game.clear();
		chat.clear();
	}

	class EventHandler implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == toolFields) {
				game.setVisible(true);
			} else if (e.getSource() == toolSpec) {
				chat.setVisible(true);
			} else if (e.getSource() == toolWinlist) {
				winlist.setVisible(true);
			} else if (e.getSource() == itemAbout) {
				showAboutDialog();
			} else if (e.getSource() == itemExit) {
				System.exit(0);
			} else if (e.getSource() == itemClose) {
				showDisconnectDialog();
			} else if (e.getSource() == itemOpen) {
				showConnectDialog();
			} else if (e.getSource() == toolConnect) {
				if (io != null && io.open()) {
					showDisconnectDialog();
				} else {
					showConnectDialog();
				}
			}
		}
	}

	public static void main(String[] args) {
		new JSpectator();
	}
}
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.html.*;

public class JParty extends JPanel implements ConstantsIF {
	private static final int BORDER = 10;
	private static final int WIDTH 	= 600;
	private static final int HEIGHT = 400;

	private MessageProcessor proc;
	private EventHandler listener;
	private JTextPanel text;
	private JListPanel list;
	private JEditorPane partyText;
	private JScrollPane partyScroll;
	private JTextField partyInput;
	private JList playerList,spectatorList;
	private DefaultListModel playerModel,spectatorModel;

	public JParty(MessageProcessor processor) {
		proc = processor;
		setBorder(BorderFactory.createEtchedBorder());
		listener = new EventHandler();
		setLayout(new BorderLayout(BORDER,BORDER));
		text = new JTextPanel(listener);
		text.setPreferredSize(new Dimension(WIDTH*3/4,HEIGHT));
		add(text,BorderLayout.CENTER);
		list = new JListPanel();
		list.setPreferredSize(new Dimension(WIDTH/4,HEIGHT));
		add(list,BorderLayout.EAST);
		setPreferredSize(new Dimension(WIDTH,HEIGHT));
		setVisible(true);
	}

	protected void initPlayerList() {
		for (int i=0;i<CNT_PLAYERS;i++) {
			playerModel.add(i,Integer.toString(i+1)+". ");
		}
	}

	public void clear() {
		spectatorModel.removeAllElements();
		//playerModel.removeAllElements();
		//initPlayerList();
	}

	protected String getName(int slot) {
		String name = "server";
		if (slot > 0 && slot <= CNT_PLAYERS) {
			name = ((String)playerModel.elementAt(slot-1)).substring(3);
		}
		return name;
	}

	public synchronized void addMessage(int slot,String msg) {
		HTMLDocument doc = (HTMLDocument) partyText.getDocument();
		Element e = doc.getDefaultRootElement().getElement(0).getElement(0);
		try {
			doc.insertBeforeEnd(e,"*"+getName(slot)+"* "+msg+"<br>");
			partyText.setCaretPosition(doc.getLength());
		} catch (Exception ex) {
			System.out.println(ex.toString());
		}
	}

	public void addPlayer(int slot,String nick) {
		playerModel.removeElementAt(slot-1);
		playerModel.add(slot-1,Integer.toString(slot)+". "+nick);
		addMessage(0,"<font color=\"green\">*** Player "+nick+" has joined</font>");
	}

	public void removePlayer(int slot) {
		addMessage(0,"<font color=\"green\">*** Player "+getName(slot)+" has left</font>");
		playerModel.removeElementAt(slot-1);
		playerModel.add(slot-1,Integer.toString(slot)+".");
	}

	public void addSpectator(String spectator) {
		spectatorModel.addElement(spectator);
		addMessage(0,"<font color=\"green\">*** Spectator "+spectator+" has joined</font>");
	}

	public void removeSpectator(String spectator) {
		addMessage(0,"<font color=\"green\">*** Spectator "+spectator+" has left</font>");
		spectatorModel.removeElement(spectator);
	}

	public void updateTeam(int slot,String team) {
		if (team != null && team.length() != 0) {
			addMessage(0,"*** "+getName(slot)+" is now on team "+team);
		} else {
			addMessage(0,"*** "+getName(slot)+" is now playing alone");
		}
	}

	class JTextPanel extends JPanel {
		public JTextPanel(ActionListener a) {
			setLayout(new BorderLayout(BORDER,BORDER));
			partyText = new JEditorPane();
			partyText.setContentType("text/html");
			partyText.setEditable(false);
			partyScroll = new JScrollPane(partyText,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			add(partyScroll,BorderLayout.CENTER);
			partyInput = new JTextField(50);
			partyInput.addActionListener(a);
			add(partyInput,BorderLayout.SOUTH);
			setVisible(true);
		}
	}

	class JListPanel extends JPanel {
		public JListPanel() {
			setLayout(new BorderLayout(BORDER,BORDER));
			playerModel = new DefaultListModel();
			initPlayerList();
			playerList = new JList(playerModel);
			playerList.setBorder(BorderFactory.createTitledBorder("Players"));
			add(playerList,BorderLayout.NORTH);
			spectatorModel = new DefaultListModel();
			spectatorList = new JList(spectatorModel);
			spectatorList.setBorder(BorderFactory.createTitledBorder("Spectators"));
			add(spectatorList,BorderLayout.CENTER);
			setVisible(true);
		}
	}

	class EventHandler implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == partyInput) {
				String in = partyInput.getText();
				if (in.length() != 0) {
					if (in.startsWith("/me")) {
						proc.sendPartyAct(in.substring(3));
						addMessage(0,"--> <font color=\"magenta\">"+in.substring(3)+"</font>");
					} else if (in.startsWith("/")) {
						proc.sendSpectatorMessage(in);
						addMessage(0,"--> "+in);
					} else {
						proc.sendPartyMessage(in);
						addMessage(0,"--> "+in);
					}
					partyInput.setText("");
				}
			}
		}
	}

}
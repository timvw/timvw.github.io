public interface CommunicationIF {
	public boolean open();
	public boolean close();
	public String read();
	public void write(String msg);
	public boolean valid();
}
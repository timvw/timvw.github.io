import javax.swing.*;

public class specApplet extends JApplet {
	public void init() {
		JSpectator.main(null);
	}
}
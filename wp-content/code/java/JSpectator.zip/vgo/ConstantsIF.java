public interface ConstantsIF {
	public static final String APP_NAME 			= "JSpectator";
	public static final String APP_AUTHOR 		= "Tim Van Wassenhove <timvw@tetrinet.be>";
	public static final String APP_VERSION 		= "1.0";

	public static final String VERSION 				= "1.13";
	public static final String TOKEN_TNET 		= "tetrisstart";
	public static final String TOKEN_TFAST 		= "tetrifaster";

	public static final int PORT_IRC 					= 31456;
	public static final int PORT_TETRINET 		= 31457;
	public static final int PORT_SPECTATOR 		= 31458;

	public static final int CNT_PLAYERS 			= 6;
	public static final int CNT_COLS 					= 12;
	public static final int CNT_ROWS 					= 22;

	public static final char[] SPECIALS 			= { 'a','c','n','r','s','b','g','q','o' };

	public static final int GAME_START 				= 1;
	public static final int GAME_PAUSE 				= 2;
	public static final int GAME_UNPAUSE 			= 3;
	public static final int GAME_STOP 				= 4;
	public static final int GAME_END 					= 5;
	public static final int GAME_DISCONNECTED = 6;
	public static final int GAME_INGAME 			= 7;

	public static final int PLAYER_WAITING 		= 1;
	public static final int PLAYER_INGAME 		= 2;
	public static final int PLAYER_LOST 			= 3;
	public static final int PLAYER_WON 				= 4;
	public static final int PLAYER_KICK 			= 5;

}
import java.net.*;
import java.io.*;
import java.util.*;

public class Communication implements  ConstantsIF, CommunicationIF {
	private Socket sock;
	private BufferedReader in;
	private BufferedWriter out;
	private boolean isValid;
	private String hostname,username,password;

	public Communication() {
		isValid = false;
	}

	public Communication(String hostname,String username,String password) {
		this.hostname = hostname;
		this.username = username;
		this.password = password;
		isValid = false;
	}

	public boolean open() {
		try {
			sock = new Socket(hostname,PORT_SPECTATOR);
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			write(encode(hostname,username,TOKEN_TNET,VERSION));
			String answer = read();
			StringTokenizer strTok = new StringTokenizer(answer," ");
			if(strTok.countTokens() >= 2) {
				strTok.nextToken();
				write("team "+strTok.nextToken()+" "+password);
				isValid = true;
			}
		} catch(IOException ioe) {
			isValid = false;
		} finally {
			return isValid;
		}
	}

	public boolean close() {
		try {
			in.close();
			out.close();
			sock.close();
		} catch(IOException ioe) {
		} finally {
			in = null;
			out = null;
			sock = null;
			isValid = false;
			return isValid;
		}
	}

	public String read() {
		StringBuffer input = new StringBuffer();
		try {
			int i = in.read();
			while(i!=-1 && i!=10 && i!=13 && i!=255) {
				input.append((char)i);
				i = in.read();
			}
			return input.toString();
		} catch(IOException ioe) {
			close();
		} finally {
			return input.toString();
		}
	}

	public void write(String msg) {
		try {
			out.write(msg,0,msg.length());
			out.write(255);
			out.flush();
		} catch (IOException ioe) {
			close();
		}
	}

	public boolean valid() {
		return isValid;
	}

	public static String encode (String hostname,String username,String token,String version) {
		String s = token+" "+username+" "+version;
		byte[] raw = null;
		try {
			java.net.InetAddress address = java.net.InetAddress.getByName(hostname);
			raw = address.getAddress();
		} catch(Exception e) {
			return null;
		}
		int[] ip = new int[raw.length];
		for(int i=0;i<raw.length;i++) {
			ip[i] = (int) raw[i];
			if(ip[i] < 0) {
				ip[i] = 256 + ip[i];
			}
		}
    String h = Integer.toString(54*ip[0]+41*ip[1]+29*ip[2]+17*ip[3]);
    int dec = (int)(Math.random() * 255);
    StringBuffer result = new StringBuffer();
    result.append(Integer.toHexString(dec));
    for(int i=0;i<s.length();i++) {
	    dec = ((dec + s.charAt(i)) % 255) ^ h.charAt(i % h.length());
	    if(dec < 10) {
		    result.append("0");
	    }
	    result.append(Integer.toHexString(dec));
    }
    return result.toString();
  }
}
import java.util.*;

public class MessageProcessor implements Runnable, MessageTable, ConstantsIF {
	private RepresentationIF ui;
	private CommunicationIF io;
	private Player[] player;
	private boolean running;
	private Thread t;
	private String name;
	private int slotNum;

	public MessageProcessor(RepresentationIF rep,CommunicationIF com) {
		ui = rep;
		io = com;
		player = new Player[CNT_PLAYERS];
		running = true;
		t = new Thread(this);
		t.start();
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public MessageProcessor(RepresentationIF rep) {
		this(rep,null);
	}

	public MessageProcessor(CommunicationIF com) {
		this(null,com);
	}

	public MessageProcessor() {
		this(null,null);
	}

	public void setRepresentation(RepresentationIF rep) {
		ui = rep;
	}

	public void setCommunication(CommunicationIF com) {
		io = com;
	}

	public void sendPartyMessage(int slot,String msg) {
		if (io != null) {
			io.write(OUT_PLINE+" "+slot+" // "+msg);
		}
	}

	public void sendPartyMessage(String msg) {
		sendPartyMessage(slotNum,msg);
	}

	public void sendPartyAct(int slot,String msg) {
		if (io != null) {
			io.write(OUT_PLINEACT+" "+slot+" // "+msg);
		}
	}

	public void sendPartyAct(String msg) {
		sendPartyAct(slotNum,msg);
	}

	public void sendSpectatorMessage(String msg) {
		if (io != null) {
			io.write(OUT_SMSG+" "+slotNum+" "+msg);
		}
	}

	public void sendSpectatorAct(String msg) {
		if (io != null) {
			io.write(OUT_SACT+" "+slotNum+" "+msg);
		}
	}
	public void sendGameMessage(int slot,String msg) {
		if (io != null) {
			io.write(OUT_GMSG+" "+slot+" // "+msg);
		}
	}

	public void sendGameMessage(String msg) {
		if (io != null) {
			io.write(OUT_GMSG+" {"+name+"} "+msg);
		}
	}

	public void stopRunning() {
		running = false;
	}

	public void run() {
		while(running) {
			if (ui != null && io != null && io.valid()) {
				String input = io.read();
				if ((!io.valid()) || (input == null) || (input.length() == 0)) {
					io.close();
					io = null;
					ui.gameEvent(0,GAME_DISCONNECTED);
				} else {
					StringTokenizer strTok = new StringTokenizer(input," ");
					String[] token = new String[strTok.countTokens()];
					int count = token.length;
					for (int i=0;i<token.length;i++) {
						token[i] = strTok.nextToken();
					}
					int slot = 0;
					try {
						slot = Integer.parseInt(token[1]);
					} catch (Exception e) { }

					//System.out.println(input);

					if (input.startsWith(IN_CONNECTERROR)) {
						StringBuffer strBuf = new StringBuffer();
						for (int i=2;i<count;i++) {
							strBuf.append(token[i]+" ");
						}
						io.close();
						io = null;
						ui.partyMessage(0,strBuf.toString());
						ui.gameEvent(0,GAME_DISCONNECTED);
					} else if (input.startsWith(IN_CONNECT)) {
					} else if(input.startsWith(IN_PLAYERJOIN)) {
						if (count == 3) {
							ui.playerJoin(slot,token[2]);
							player[slot-1] = new Player(token[2]);
						}
					} else if(input.startsWith(IN_PLAYERLEAVE)) {
						if (count == 2) {
							ui.playerLeave(slot);
							player[slot-1] = null;
						}
					} else if (input.startsWith(IN_KICK)) {
						ui.playerEvent(slot,PLAYER_KICK);
						ui.playerLeave(slot);
						player[slot-1] = null;
					} else if (input.startsWith(IN_TEAM)) {
						if (count == 2) {
							ui.updateTeam(slot,null);
							player[slot-1].setTeam(null);
						} else if (count == 3) {
							ui.updateTeam(slot,token[2]);
							player[slot-1].setTeam(token[2]);
						}
					} else if (input.startsWith(IN_PLINE)) {
						if (count >= 2) {
							StringBuffer strBuf = new StringBuffer();
							for (int i=2;i<count;i++) {
								strBuf.append(token[i]+" ");
							}
							ui.partyMessage(slot,strBuf.toString());
						}
					} else if (input.startsWith(IN_PLINEACT)) {
						if (count >= 2) {
							StringBuffer strBuf = new StringBuffer();
							for (int i=2;i<count;i++) {
								strBuf.append(token[i]+" ");
							}
							ui.partyAct(slot,strBuf.toString());
						}
					} else if (input.startsWith(IN_PLAYERLOST)) {
						ui.playerEvent(slot,PLAYER_LOST);
					} else if (input.startsWith(IN_PLAYERWON)) {
						ui.playerEvent(slot,PLAYER_WON);
					} else if (input.startsWith(IN_NEWGAME)) {
						ui.gameEvent(slot,GAME_START);
					} else if (input.startsWith(IN_INGAME)) {
						ui.gameEvent(slot,GAME_INGAME);
					} else if (input.startsWith(IN_PAUSE)) {
						if (count >= 3) {
							int pause = 0;
							try {
								pause = Integer.parseInt(token[2]);
							} catch (NumberFormatException nfe) {
							}
							if (pause == 0) {
								ui.gameEvent(slot,GAME_UNPAUSE);
							} else {
								ui.gameEvent(slot,GAME_PAUSE);
							}
						}
					} else if (input.startsWith(IN_ENDGAME)) {
						ui.gameEvent(slot,GAME_END);
					} else if (input.startsWith(IN_F)) {
						if (count >= 3) {
							StringBuffer strBuf = new StringBuffer();
							for (int i=2;i<count;i++) {
								strBuf.append(token[i]+" ");
							}
							player[slot-1].updateField(strBuf.toString());
							ui.updateField(slot,player[slot-1].getField());
						} else if (count == 2) {
							player[slot-1].clearField();
							ui.updateField(slot,player[slot-1].getField());
						}
					} else if (input.startsWith(IN_SB)) {
						ui.gameSpecial(slot,input);
					} else if (input.startsWith(IN_LVL)) {
						ui.gameMessage(slot,input);
					} else if (input.startsWith(IN_GMSG)) {
						if (count >= 3) {
							StringBuffer strBuf = new StringBuffer();
							for (int i=2;i<count;i++) {
								strBuf.append(token[i]+" ");
							}
							ui.gameMessage(slot,strBuf.toString());
						}
					} else if (input.startsWith(IN_WINLIST)) {
						if (count >= 2) {
							String[][] winlist = new String[count-1][3];
							for (int i=1;i<count;i++) {
								StringTokenizer st = new StringTokenizer(token[i],";");
								winlist[i-1][0] = Integer.toString(i);
								winlist[i-1][1] = st.nextToken().substring(1);
								winlist[i-1][2] = st.nextToken();
							}
							ui.updateWinlist(winlist);
						}
					} else if (input.startsWith(IN_SPECJOIN)) {
						if (count == 2) {
							ui.spectatorJoin(token[1]);
						}
					} else if (input.startsWith(IN_SPECLEAVE)) {
						if (count == 2) {
							ui.spectatorLeave(token[1]);
						}
					} else if (input.startsWith(IN_SPECLIST)) {
						if (count >= 2) {
							ui.setChannel(token[1].substring(1));
							for (int i=2;i<count;i++) {
								ui.spectatorJoin(token[i]);
								if(token[i].equals(name)) {
									slotNum = i-1;
								}
							}
						}
					} else if (input.startsWith(IN_SMSG)) {
						if (count >= 2) {
							StringBuffer strBuf = new StringBuffer();
							for (int i=2;i<count;i++) {
								strBuf.append(token[i]+" ");
							}
							ui.spectatorMessage(token[1],strBuf.toString());
						}
					} else if (input.startsWith(IN_SACT)) {
						if (count >= 2) {
							StringBuffer strBuf = new StringBuffer();
							for (int i=2;i<count;i++) {
								strBuf.append(token[i]+" ");
							}
							ui.spectatorAct(token[1],strBuf.toString());
						}
					}
				}
			}
		}
	}


}
	
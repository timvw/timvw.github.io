import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

public class JWinlist extends JFrame implements ConstantsIF {
	private static final String[] column = { "rank", "name", "points" };
	private String[][] row;
	private static final int MAX_WINLIST = 10;
	private Container c;
	private JTable winlist;
	private JTableHeader header;
	private DefaultTableModel dtm;

	public JWinlist() {
		super(APP_NAME);
		c = getContentPane();
		c.setLayout(new BorderLayout());
		initWinlist();
		c.add(header,BorderLayout.NORTH);
		c.add(winlist,BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		pack();
	}

	public void initWinlist() {
		row = new String[MAX_WINLIST][column.length];
		for (int i=0;i<row.length;i++) {
			row[i][0] = Integer.toString(i+1);
			for (int j=1;j<column.length;j++) {
				row[i][j] = "";
			}
		}
		dtm = new MyTableModel(row,column);
		winlist = new JTable(dtm);
		header = winlist.getTableHeader();
	}

	public void updateWinlist(String[][] winlist) {
		row = winlist;
		dtm.setDataVector(row,column);
	}

	class MyTableModel extends DefaultTableModel {
		public MyTableModel(Object[][] data, Object[] columnNames) {
			super(data,columnNames);
		}

		public boolean isCellEditable(int row, int column) {
			return false;
		}
	}

}
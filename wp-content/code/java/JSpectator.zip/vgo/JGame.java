import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.html.*;

public class JGame extends JFrame implements ConstantsIF {
	private static final int BLOCK_WIDTH = 10;
	private static final int BLOCK_HEIGHT = 10;
	private static final int BORDER = 10;

	private MessageProcessor proc;
	private EventHandler listener;
	private Container c;
	private JGameArea area;
	private JField[] field;
	private JTextPanel text;
	private JEditorPane gameText;
	private JScrollPane gameScroll;
	private JTextField gameInput;

	public JGame(MessageProcessor processor) {
		super(APP_NAME);
		proc = processor;
		c = getContentPane();
		c.setLayout(new BorderLayout());
		area = new JGameArea();
		area.setPreferredSize(new Dimension(5*BORDER+4*CNT_COLS*BLOCK_WIDTH,3*BORDER+2*CNT_ROWS*BLOCK_HEIGHT));
		c.add(area,BorderLayout.CENTER);
		setResizable(false);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		pack();
	}

	public synchronized void addMessage(String msg) {
		HTMLDocument doc = (HTMLDocument) gameText.getDocument();
		Element e = doc.getDefaultRootElement().getElement(0).getElement(0);
		try {
			doc.insertBeforeEnd(e,msg+"<br>");
			gameText.setCaretPosition(doc.getLength());
		} catch (Exception ex) {
			System.out.println(ex.toString());
		}
	}

	public void addPlayer(int slot,String nick) {
		field[slot-1].setNick(nick);
	}

	public void removePlayer(int slot) {
		field[slot-1].setNick(null);
	}

	public void updateTeam(int slot,String team) {
		field[slot-1].setTeam(team);
	}

	public void updateField(int slot,char[][] playField) {
		field[slot-1].updateField(playField);
	}

	public void clear() {
		for (int i=0;i<field.length;i++) {
			field[i].setNick(null);
		}
	}

	public void newgame() {
		gameText.setText("");
	}

	class JGameArea extends JPanel  {
		public JGameArea() {
			setLayout(null);
			listener = new EventHandler();
			field = new JField[CNT_PLAYERS];
			for (int i=0;i<field.length;i++) {
				field[i] = new JField();
				field[i].setSize(120,220);
				field[i].setLocation(BORDER+(i%4*(CNT_COLS*BLOCK_WIDTH+BORDER)),BORDER+(i/4*(CNT_ROWS*BLOCK_HEIGHT+BORDER)));
				add(field[i]);
			}
			text = new JTextPanel(listener);
			text.setSize(BORDER+2*CNT_COLS*BLOCK_WIDTH,CNT_ROWS*BLOCK_HEIGHT);
			text.setLocation(BORDER+2*(CNT_COLS*BLOCK_WIDTH+BORDER),2*BORDER+CNT_ROWS*BLOCK_HEIGHT);
			add(text);
			setSize(6*BORDER+4*CNT_COLS*BLOCK_WIDTH,3*BORDER+2*CNT_ROWS*BLOCK_HEIGHT+40);
			setVisible(true);
		}
	}

	class JTextPanel extends JPanel {
		public JTextPanel(ActionListener a) {
			setLayout(new BorderLayout(BORDER,BORDER));
			gameText = new JEditorPane();
			gameText.setContentType("text/html");
			gameText.setEditable(false);
			gameScroll = new JScrollPane(gameText,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			add(gameScroll,BorderLayout.CENTER);
			gameInput = new JTextField();
			gameInput.addActionListener(a);
			add(gameInput,BorderLayout.SOUTH);
			setVisible(true);
		}
	}

	class JField extends JPanel implements ConstantsIF {
		private String nick;
		private String team;
		private char[][] playField;

		public JField() {
			super();
			playField = new char[CNT_COLS][CNT_ROWS];
			setSize(CNT_COLS*BLOCK_WIDTH,CNT_ROWS*BLOCK_HEIGHT);
			setPreferredSize(new Dimension(CNT_COLS*BLOCK_WIDTH,CNT_ROWS*BLOCK_HEIGHT));
			setVisible(true);
		}

		public void paint(Graphics g) {
			g.setColor(Color.black);
			g.fillRect(0,0,CNT_COLS*BLOCK_WIDTH,CNT_ROWS*BLOCK_HEIGHT);
			g.setColor(Color.gray);
			for (int i=0;i<CNT_COLS;i++) {
				g.drawLine(i*BLOCK_WIDTH,0,i*BLOCK_WIDTH,CNT_ROWS*BLOCK_HEIGHT);
			}
			g.setColor(Color.white);
			if (nick != null) {
				g.drawString(nick,0,15);
				if (team != null && team.length() != 0) {
					g.setColor(Color.red);
					g.drawString(team,0,30);
				}
				for (int i=0;i<playField.length;i++) {
					for (int j=0;j<playField[i].length;j++) {
						drawBlock(g,i,j);
					}
				}
			} else {
				g.drawString("not playing",0,15);
			}
		}

		protected void drawBlock(Graphics g,int i,int j) {
			int block = (int) playField[i][j];
			if (block != 0) {
				g.setColor(Color.white);
				g.fillRect(i*BLOCK_WIDTH,j*BLOCK_HEIGHT,BLOCK_WIDTH,BLOCK_HEIGHT);
				switch (block) {
					case  1: g.setColor(Color.blue); break;
					case  2: g.setColor(Color.yellow); break;
					case  3: g.setColor(Color.green); break;
					case  4: g.setColor(Color.magenta);break;
					case  5: g.setColor(Color.red);break;
					case  6:
					case  7:
					case  8:
					case  9:
					case 10:
					case 11:
					case 12:
					case 13:
					case 14: g.setColor(Color.gray); break;
				}
				g.fillRect((i*BLOCK_WIDTH)+1,(j*BLOCK_HEIGHT)+1,BLOCK_WIDTH-1,BLOCK_HEIGHT-1);
				block -= 6;
				if (block >= 0) {
					g.setColor(Color.yellow);
					//char ch = SPECIALS[block];
					//String shit = Character.toString(ch);
					//g.drawString(shit,i*BLOCK_WIDTH+2,j*BLOCK_HEIGHT+9);
					g.drawChars(SPECIALS,block,1,i*BLOCK_WIDTH+2,j*BLOCK_HEIGHT+9);
				}
			}
		}

		public void setNick(String nick) {
			this.nick = nick;
			repaint();
		}

		public void setTeam(String team) {
			if (team == null || team.length() == 0) {
				this.team = null;
			} else {
				this.team = team;
			}
			repaint();
		}

		public void updateField(char[][] playField) {
			this.playField = playField;
			repaint();
		}
	}

	class EventHandler implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == gameInput) {
				String in = gameInput.getText();
				if (in.length() != 0) {
					proc.sendGameMessage(in);
					gameInput.setText("");
				}
			}
		}
	}

}
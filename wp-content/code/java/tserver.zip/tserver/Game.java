public class Game implements Constants
{
	private int misc[];
	private int blocks[];
	private int specials[];
	private int type;
	private int status;
	private long startTime;
	private int points1;
	private int points2;
	private boolean sdActivated;
	
	//constructor
	public Game ()
	{
		//set type and version to default
		type = CLASSIC;
		status = NOGAME;
		sdActivated = false;
		
		//set miscellaneous
		misc = new int[12];
		misc[0] = 0;  	//starting Height
		misc[1] = 1;  	//starting Level
		misc[2] = 2;  	//lines per Level
		misc[3] = 1;  	//level Increase
		misc[4] = 1;  	//lines per Specials
		misc[5] = 1; 		//special Added
		misc[6] = 18; 	//special Capacity
		misc[7] = 1;  	//average Levels
		misc[8] = 1;  	//classic Rules
		misc[9] = 10; 	//seconds between lines
		misc[10] = 1; 	//lines added
		misc[11] = 600;	//suddendeath starttime , 0 is no suddendeath
		
		//set block occurrence
		blocks = new int[7];
		blocks[0] = 15; //stick
		blocks[1] = 15; //blocksquare
		blocks[2] = 14; //leftl
		blocks[3] = 14; //rightl
		blocks[4] = 14; //leftz
		blocks[5] = 14; //rightz
		blocks[6] = 14; //halfcross
		
		//set specials occurrence
		specials = new int[9];
		specials[0] = 32; //addline
		specials[1] = 18; //clearline
		specials[2] = 1;  //nukefield
		specials[3] = 11; //randomclear
		specials[4] = 3;  //switchfield
		specials[5] = 14; //clear specials
		specials[6] = 1;  //gravity
		specials[7] = 6;  //quakefield
		specials[8] = 14; //blockbomb
	}
	
	//constructor
	public Game (int type,int misc[],int blocks[],int specials[])
	{
		this();
		this.type = type;
		setMisc(misc);
		setBlocks(blocks);
		setSpecials(specials);
	}
	
	//constructor 
	public Game (int type)
	{
		this();
		this.type = type;
	}
	
	//set misc options
	public synchronized boolean setMisc (int misc[])
	{
		if (misc.length == 12)
		{
			this.misc = misc;
			return true;
		}
		return false;
	}
	
	//returns misc options
	public synchronized int[] getMisc ()
	{
		return misc;
	}
		
	//set block occurence
	public synchronized boolean setBlocks (int blocks[])
	{
		if ((blocks.length == 7)&&(getSum(blocks) == 100))
		{
			this.blocks = blocks;
			return true;
		}
		return false;
	}
	
	//gives the blocks
	public synchronized int[] getBlocks ()
	{
		return blocks;
	}
	
	//set special occurrence
	public synchronized boolean setSpecials (int specials[])
	{
		if ((specials.length == 9)&&(getSum(specials) == 100))
		{
			this.specials = specials;
			return true;
		}
		return false;
	}
	
	//gives the specials
	public synchronized int[] getSpecials ()
	{
		return specials;
	}
	
	//get sum of all elements of an array
	public synchronized int getSum (int array[])
	{
		int sum = 0;
		for (int i=0;i<array.length;i++)
		{
			sum += array[i];
		}
		return sum;
	}
	
	//set startTime to t
	public synchronized void setStartTime(long t)
	{
		startTime = t;
	}
	
	//returns startTime
	public synchronized long getStartTime ()
	{
		return startTime;
	}
	
	//returns startingLevel
	public synchronized int getStartingLevel ()
	{
		return misc[1];
	}
	
	//set status to s
	public synchronized void setStatus (int s)
	{
		status = s;
	}
	
	//set suddendeath stuff
	public synchronized void setSudden (int sBetweenLines,int linesAdded,int suddenStart)
	{
		misc[9] = sBetweenLines;
		misc[10] = linesAdded;
		misc[11] = suddenStart;
	}
	
	//get suddendeath stuff
	public synchronized int[] getSudden ()
	{
		int tmp[] = new int[3];
		
		tmp[0] = misc[9];
		tmp[1] = misc[10];
		tmp[2] = misc[11];
		
		return tmp; 
	}
		
	//returns status
	public synchronized int getStatus ()
	{
		return status;
	}
	
	//returns type
	public synchronized int getType ()
	{
		return type;
	}
	
	//set points1 to p
	public synchronized void setPoints1 (int p)
	{
		points1 = p;
	}
	
	//get points1
	public synchronized int getPoints1 ()
	{
		return points1;
	}
	
	//set points2 to p
	public synchronized void setPoints2 (int p)
	{
		points2 = p;
	}
	
	//returns points2
	public synchronized int getPoints2 ()
	{
		return points2;
	}
	
	//set sdActivated to b
	public synchronized void setSdActivated (boolean b)
	{
		sdActivated = b;
	}
	
	//returns wethere suddenDeath is activated
	public synchronized boolean isSdActivated ()
	{
		return sdActivated;
	}
	
	//toString
	public synchronized String toString (int version)
	{ 
		StringBuffer strBuf = new StringBuffer();
		
		if (version == TETRINET)
		{
			strBuf.append("newgame");
		}
		else
		{
			strBuf.append("*******");
		}
		
		for (int i=0;i<7;i++)
		{
			strBuf.append(" " + misc[i]);
		}
		
		strBuf.append(" ");       
		for (int i=0;i<blocks.length;i++)
		{
			for (int j=0;j<blocks[i];j++)
			{
				strBuf.append(i+1);
			}
		}
		
		strBuf.append(" ");
		for (int i=0;i<specials.length;i++)
		{
			for(int j=0;j<specials[i];j++)
			{ 
				strBuf.append(i+1);
			}
		}
		
		strBuf.append(" " +misc[7] + " " + misc[8]);
		return strBuf.toString();
	}	
	
}
	
	
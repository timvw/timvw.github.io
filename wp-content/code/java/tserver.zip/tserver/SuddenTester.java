public class SuddenTester extends Thread implements Constants
{
	protected Channel chan;
	protected int delay;
	protected int linesToAdd;
	protected int activationTime;
	protected boolean running;
	protected Game game;
	
	//constructor
	public SuddenTester (Channel ch)
	{
		chan = ch;
		game = chan.getGame();
		int tmp[] = game.getSudden();
		delay = tmp[0]*1000;
		linesToAdd = tmp[1];
		activationTime = tmp[2]*1000;
		running = true;
		//enter main loop
		start();
	}
	
	//main loop
	public void run ()
	{
		while (running)
		{
			try
			{
				double initialStartTime = game.getStartTime();
				sleep(activationTime);
				double dif = 5000;
				if (game.getStatus() == PLAYING)
				{
					dif = game.getStartTime() - initialStartTime;
				}
				while ((dif > 0)||(game.getStatus() == PAUSED))
				{
					sleep((int)dif);
					initialStartTime += dif;
					dif = 5000;
					if (game.getStatus() == PLAYING)
					{
						dif = game.getStartTime() - initialStartTime;
					}
				}
				chan.write("gmsg * SuddenDeath has been activated");
				while (running)
				{
					sleep(delay);
					if (chan.getStatus() == PLAYING)
					{
						for (int i=0;i<linesToAdd;i++)
						{
							chan.write("sb 0 a 0");
							for (int slot=1;slot<=chan.getMaxPlayers();slot++)
							{
								Player pl = chan.getPlayer(slot);
								if (pl != null)
								{
									pl.setBlocksDropped(pl.getBlocksDropped()-1);
								}
							}
							sleep(100);
						}
					}
					else if (chan.getStatus() == NOGAME)
					{
						running = false;
					} 
				}
			}
			catch (Exception e)
			{
				running = false;
				chan = null;
			}
		}
		chan = null;
	} 
	
	//set chan to ch
	public void setChannel (Channel ch)
	{
		chan = ch;
	}
	
	//set game to g
	public void setGame (Game g)
	{
		game = g;
	}
	
	//set running to r
	public void setRunning (boolean r)
	{
		running = r;
	}
	
	//returns wether running
	public boolean isRunning ()
	{
		return running;
	}

}
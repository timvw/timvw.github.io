/* Constants.java
 *
 * This interface contains a set of constants that will be used in all classes.
 *
 * Last update: 01/10/2001 09:26
 * 
 * Comments and suggestions can be send to coders@tetrinet.be
*/

public interface Constants
{
	//files
	public final static String FILE_MOTD =  "game.motd";
	public final static String FILE_MYSQL = "game.mysql";

	//name constants
	public final static int LENGTH_NAME = 30;
	
	//timeout
	public final static int TIMEOUT_SPECTATOR = 1200000;
	public final static int TIMEOUT_NOGAME = 600000;
	public final static int TIMEOUT_INGAME = 50000;
	
	//port numbers for tcp/ip
	public final static int SPECTATORPORT = 31458;
	public final static int TETRINETPORT = 31457;
	public final static int QUERYPORT = 31456;
	public final static int IRCPORT = 6669;
	
	//versions
	public final static int TETRINET = 0;
	public final static int TETRIFAST = 1;
	
	//game constants
	public final static int MAX_PPM = 55;
	public final static int TIME_QUICK = 180000;	
	
	//status	
	public final static int NOGAME = 0;
	public final static int PLAYING = 1;
	public final static int PAUSED = 2;
	public final static int DEAD = 3;
	
	//access
	public final static int UNREGISTERED = 0;
	public final static int REGISTERED = 1;
	public final static int CHANOP = 2;
	public final static int GLOBALOP = 3;
	public final static int ADMIN = 4;
	
	/*
	 * gametypes
	 *
	 * if u make any changes to this 
	 * -> update Mysql.java function: - getWinlist
	 *																- loadChannels
	 *																- getStats
	 *
	*/
	public final static int CLASSIC = 0;
	public final static int PURE = 1;
	public final static int ONE = 2;
	public final static int SEVEN = 3;
	public final static int QUICK = 4;
	public final static int SURVIVAL = 5;
	public final static int RACER = 6;
	public final static int SNS = 7;
	
	public final static int CLASSICFAST = 20;
	public final static int PUREFAST = 21;
	public final static int ONEFAST = 22;
	public final static int SEVENFAST = 23;
	public final static int QUICKFAST = 24;
	public final static int SURVIVALFAST = 25;
	public final static int RACERFAST = 26;
	public final static int SNSFAST = 27;
  public final static int SEVENFASTSNS = 28;

	//colors
	public final static char RED         = '\u0014';
	public final static char BLACK       = '\u0004';
 	public final static char GREEN       = '\u000c'; 
  public final static char LIGHTGREEN  = '\u000e';
  public final static char DARKBLUE    = '\u0011'; 
  public final static char BLUE        = '\u0005'; 
 	public final static char CYAN        = '\u0003';    
 	public final static char AQUA        = '\u0017'; 
 	public final static char YELLOW      = '\u0019'; 
 	public final static char KAKI        = '\u0012';
 	public final static char BROWN       = '\u0010';
 	public final static char LIGHTGRAY   = '\u000f'; 
 	public final static char GRAY	       = '\u0006'; 
 	public final static char LIGHTPURPLE = '\u0008'; 
 	public final static char PURPLE      = '\u0013';     
 	public final static char BOLD        = '\u0002';
 	public final static char ITALIC      = '\u0016';
 	public final static char WHITE 		 = '\u0018';

} //Constants.java

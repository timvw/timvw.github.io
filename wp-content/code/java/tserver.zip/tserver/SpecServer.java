import java.io.*;
import java.net.*;
import java.util.*;

public class SpecServer extends Thread implements Constants
{
	static SpecServer single = null;
	
	protected ServerSocket se;
	protected TetriServer serv;

	//constructor
	private SpecServer (TetriServer t) throws Exception
	{
		se = new ServerSocket(SPECTATORPORT);
		serv = t;
		start();
	}
	
	public static SpecServer giveSpecServer (TetriServer t) throws Exception
	{
		if (single == null)
		{
			single = new SpecServer(t);
		}
		return single;
	}
	
	//main loop
	public void run ()
	{
		while (true)
		{
			try
			{
				Spectator s = new Spectator(se.accept(),serv);
			}
			catch (Exception e)
			{
				System.out.println(e.toString());
			}
		}
	}

}
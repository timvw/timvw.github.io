import java.io.*;
import java.net.*;

public class Main implements Constants
{
	public static void main (String args[]) throws Exception
	{
		TetriServer t = TetriServer.giveTetriServer();
		SpecServer s = SpecServer.giveSpecServer(t);
	}
}

		
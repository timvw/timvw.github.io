import java.io.*;
import java.util.StringTokenizer;

public class Utils implements Constants
{
	//decode initialstring
	public static String decode (String initString, String firstToken)
	{
		if ((initString == null)||(firstToken == null))
		{
			return null;
		}
		else if (initString.length() % 2 != 0)
		{
			return null;
		}

		int[] dec = new int[initString.length() / 2];
		try
		{
			for (int i = 0; i < dec.length; i++)
			{
				dec[i] = Integer.parseInt(initString.substring(i * 2, i * 2 + 2), 16);
			}
		}
		catch (NumberFormatException e)
		{
			return null;
		}

		char[] data = firstToken.toCharArray();
		int[] hashString = new int[data.length];
		for (int i = 0; i < data.length; i++)
		{
			hashString[i] = ((data[i] + dec[i]) % 255) ^ dec[i + 1];
		}

		int hashLength = 5;
		for (int i = 5; i == hashLength && i > 0; i--)
		{
			for (int j = 0; j < data.length - hashLength; j++)
			{
				if (hashString[j] != hashString[j + hashLength])
				{
					hashLength--;
				}
			}
		}

		if (hashLength == 0)
		{
			return null;
		}

		String s = "";
		for (int i = 1; i < dec.length; i++)
		{
			s += (char)(((dec[i] ^ hashString[(i - 1) % hashLength]) + 255 - dec[i - 1]) % 255);
		}

		return s.replace((char)0,(char)255);
	}


	//does n only contain digits?
	public static boolean isDigit (String n)
	{
		if (n == null)
		{
			return false;
		}
		else
		{
			boolean digit = true;
			for (int i=0;((i<n.length())&&(digit));i++)
			{
				if ((n.charAt(i) < '0')||(n.charAt(i) > '9'))
				{
					digit = false;
				}
			}
			return digit;
		}
	}

	//is n a valid name?
	public static boolean isValidName (String n)
	{
		boolean valid = true;

		//n.length() < LENGTH_NAME;
		if (n.length() > LENGTH_NAME)
		{
			valid = false;
		}

		//n != "server"
		else if (n.equalsIgnoreCase("server"))
		{
			valid = false;
		}
		//n cannot be digits only
		else if (isDigit(n))
		{
			valid = false;
		}
		else
		{
			//n can not contain other chars than this
			for (int i=0;((i<n.length())&&(valid));i++)
			{
				char ch = n.charAt(i);
      	if ( !(ch >= '0' && ch <= '9') &&
           !(ch >= 'A' && ch <= 'Z') &&
           !(ch >= 'a' && ch <= 'z') &&
           !(ch == '_' || ch == '-') &&
           !(ch == '(' || ch == ')') &&
           !(ch == '$' || ch == '@') &&
           !(ch == '<' || ch == '>') &&
           !(ch == '|' || ch == '.') &&
           !(ch == '[' || ch ==']'))
      	{
      		valid = false;
      	}
    	}
    }
    return valid;
  }

  //returns the motd
  public static String[] getMotd()
  {
		StringBuffer buf = new StringBuffer();

		try
		{
			//read in the motd file
			BufferedReader br = new BufferedReader(new FileReader(FILE_MOTD));
			String line = br.readLine();
			while (line != null)
			{
				buf.append("pline 0 "+line+"\n");
				line = br.readLine();
			}
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			buf.append("pline 0 "+RED+FILE_MOTD+" is not found on the server\n");
		}
		catch (IOException ioe)
		{
			buf.append("pline 0 "+RED+FILE_MOTD+" could not be read by the server\n");
		}
		StringTokenizer tokens = new StringTokenizer(buf.toString(),"\n");
		int cntTokens = tokens.countTokens();
		String motd[] = new String[cntTokens];
		for (int i=0;i<cntTokens;i++)
		{
			motd[i] = tokens.nextToken();
		}
		return motd;
	}

	//makes from a hostName a valid string to put in banlist
	public static String decodeHostName (String host)
	{
		StringBuffer str = new StringBuffer();
		for (int i=0;i<host.length();i++)
		{
			if (host.charAt(i) == '.')
			{
				str.append("\\.");
			}
			else if (host.charAt(i) == '*')
			{
				str.append(".*");
			}
			else
			{
				str.append(host.charAt(i));
			}
		}
		return str.toString();
	}

}
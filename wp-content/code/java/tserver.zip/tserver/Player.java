import java.io.*;
import java.net.*;
import java.text.DecimalFormat;
import java.util.StringTokenizer;
import java.util.Vector;

public class Player extends Thread implements Constants
{
	protected Socket sock;
	protected InputStream in;
	protected OutputStream out;
	protected MySQL db;
	protected boolean running;
	protected String nick;
	protected String team;
	protected int version;
	protected Channel chan;
	protected char playField[][];
	protected int status;
	protected int access;
	protected TetriServer serv;
	protected double playTime;
	protected int level;
	protected int blocksDropped;
	protected int addedToAll;
	protected int tetrisMade;
	
	public Player (Socket s,MySQL m,TetriServer t) throws IOException
	{
		serv = t;
		sock = s;
		db = m;
		in = s.getInputStream();
		out = s.getOutputStream();
		playField = new char[12][22];
		clearPlayField();
		access = UNREGISTERED;
		running = true;
		start();
	}
	
	public void run () 
	{
  	initClient();

    while (running)
    {
    	String msg = read();
    	if ((msg == null)||(msg.length() == 0))
    	{
    		disconnect("IOError");
    	}
    	else
    	{
    		StringTokenizer inTok = new StringTokenizer(msg," ");
				int cntTokens = inTok.countTokens();
				String tokens[] = new String[cntTokens];
			
				for (int i=0;i<cntTokens;i++)
				{
					tokens[i] = inTok.nextToken();
				}
												
				//partyline message
				if (tokens[0].equals("pline"))
				{
					if (cntTokens >= 3)
					{
						if (tokens[2].startsWith("/"))
						{
							//gives an overview of available commands
							if (tokens[2].equalsIgnoreCase("/help"))
							{
								write("pline 0 Available Commands on Server ");
								write("pline 0 End of Available Commands on Server");
							}

							//send <msg> to all players
							else if (tokens[2].equalsIgnoreCase("/broadcast"))
							{
								if (access >= GLOBALOP)
								{
									if (cntTokens >= 4)
									{
										StringBuffer strBuf = new StringBuffer();
										for (int i=3;i<cntTokens;i++)
										{
											strBuf.append(" "+tokens[i]);
										}
										serv.broadcast(strBuf.toString());
									}
									else
									{	
										write("pline 0 "+RED+"Usage: "+BLUE+"/broadcast <msg>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}	
							}					
							
							//kick <playernum>
							else if (tokens[2].equalsIgnoreCase("/kick"))
							{
								if (access >= CHANOP)
								{
									if (cntTokens >= 4)
									{
										try
										{
											int playernumber = Integer.parseInt(tokens[3]);
											int channum = playernumber / 10;
											int playernum = playernumber % 10;
											if (channum == 0)
											{
												Player p = chan.getPlayer(playernum);
												if (p != null)
												{
													p.disconnect("kick");
												}
												else
												{
													write("pline 0 <playernum> did not exist");
												}		
											}
											else
											{
												if (access >= GLOBALOP)
												{
													Player p = serv.getPlayer(playernumber);
													if (p != null)
													{
														p.disconnect("kick");
													}
													else
													{
														write("pline 0 <playernum> did not exist");
													}	
												}
												else
												{
													write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");	
												}
											}
										}
										catch (NumberFormatException nfe)
										{
											write("pline 0 "+RED+"Usage: "+BLUE+"/kick <playernum>");
										}
									}
									else
									{
										write("pline 0 "+RED+"Usage: "+BLUE+"/kick <playernum>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}
							}	
							
							//ban <playernum>
							else if (tokens[2].equalsIgnoreCase("/ban"))
							{
								if (access >= CHANOP)
								{
									if (cntTokens >= 4)
									{
										try
										{
											int playernumber = Integer.parseInt(tokens[3]);
											int channum = playernumber / 10;
											int playernum = playernumber % 10;
											if (channum == 0)
											{
												Player p = chan.getPlayer(playernum);
												if (p != null)
												{
													db.addBan(p.getHostName(),chan.getId());
													db.addBan(p.getHostAddress(),chan.getId());
													p.disconnect("kick");
												}
												else
												{
													write("pline 0 <playernum> did not exist");
												}	
											}
											else
											{
												if (access >= GLOBALOP)
												{
													Player p = serv.getPlayer(playernumber);
													if (p != null)
													{
														db.addBan(p.getHostName(),0);
														db.addBan(p.getHostAddress(),0);
														p.disconnect("kick");
													}
													else
													{
														write("pline 0 <playernum> did not exist");
													}	
												}
												else
												{
													write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");	
												}
											}
										}
										catch (NumberFormatException nfe)
										{
											write("pline 0 "+RED+"Usage: "+BLUE+"/ban <playernum>");
										}
									}
									else
									{
										write("pline 0 "+RED+"Usage: "+BLUE+"/ban <playernum>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}
							}								
														
							//send <msg> to <nick>
							else if (tokens[2].equalsIgnoreCase("/cmsg"))
							{
								if (cntTokens >= 5)
								{
									StringBuffer strBuf = new StringBuffer();
									for (int i=4;i<cntTokens;i++)
									{
										strBuf.append(" "+tokens[i]);
									}
									write(serv.write(nick,tokens[3],strBuf.toString()));
								}
								else
								{
									write("pline 0 "+RED+"Usage: "+BLUE+"/cmsg <nick> <msg>");
								}
							}						
														
							//send <msg> to operators
							else if (tokens[2].equalsIgnoreCase("/omsg"))
							{
								if (cntTokens >= 4)
								{
									StringBuffer strBuf = new StringBuffer();
									for (int i=3;i<cntTokens;i++)
									{
										strBuf.append(" "+tokens[i]);
									}
									write(serv.owrite(nick,strBuf.toString()));
								}
								else
								{
									write("pline 0 "+RED+"Usage: "+BLUE+"/omsg <msg>");
								}
							}		
														
							//change topic
							else if (tokens[2].equalsIgnoreCase("/topic"))
							{
								if (access >= CHANOP)
								{
									if (cntTokens >= 4)
									{
										StringBuffer strBuf = new StringBuffer();
										for (int i=3;i<cntTokens;i++)
										{
											strBuf.append(" "+tokens[i]);
										}
										chan.setTopic(strBuf.toString());
										write("pline 0 Set topic to: "+BLUE+chan.getTopic());
									}
									else
									{	
										write("pline 0 "+RED+"Usage: "+BLUE+"/topic <topic>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}		
							}	
						
							//set block occurrence
							else if (tokens[2].equalsIgnoreCase("/blocks"))
							{
								if (access >= CHANOP)
								{
									int blocks[] = chan.getGame().getBlocks();
									String blName[] = {"stick","square","leftl","rightl","leftz","rightz","cross"};
																
									if (cntTokens >= 10)
									{
										blocks = new int[7];
										try
										{
											for (int i=0;i<blocks.length;i++)
											{
												blocks[i] = Integer.parseInt(tokens[i+3]);
											}
											if (chan.getGame().setBlocks(blocks))
											{
												write("pline 0 Trying to change block occurrence: "+GREEN+"SUCCES");
											}
											else
											{
												write("pline 0 Trying to change block occurrence: "+RED+"FAILED");
											}
										}
										catch (NumberFormatException nfe)
										{
											write("pline 0 "+RED+"Usage: "+BLUE+"/blocks <stick> <square> <leftl> <rightl> <leftz> <rightz> <cross>");
										}
									}
									else
									{
										write("pline 0 Block settings for "+BLUE+chan.getName());
										for (int i=0;i<blocks.length;i++)
										{
											write("pline 0 "+blName[i]+"\t: "+RED+blocks[i]);
										}	
										write("pline 0 "+RED+"Usage: "+BLUE+"/blocks <stick> <square> <leftl> <rightl> <leftz> <rightz> <cross>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}	
							}
						
							//set specials occurrence
							else if (tokens[2].equalsIgnoreCase("/specials"))
							{
								if (access >= CHANOP)
								{
									int specials[] = chan.getGame().getSpecials();
									String sName[] = {"a","c","n","r","s","b","g","q","o"};
																	
									if (cntTokens >= 12)
									{
										specials = new int[9];
										try
										{
											for (int i=0;i<specials.length;i++)
											{
												specials[i] = Integer.parseInt(tokens[i+3]);
											}
											if (chan.getGame().setSpecials(specials))
											{
												write("pline 0 Trying to change special occurrence: "+GREEN+"SUCCES");
											}
											else
											{
												write("pline 0 Trying to change special occurrence: "+RED+"FAILED");
											}
										}
										catch (NumberFormatException nfe)
										{
											write("pline 0 "+RED+"Usage: "+BLUE+"/specials <a> <c> <n> <r> <s> <b> <g> <q> <o>");
										}																		
									}
									else
									{
										write("pline 0 Special settings for "+BLUE+chan.getName());
										for (int i=0;i<specials.length;i++)
										{
											write("pline 0 "+sName[i]+"\t: "+RED+specials[i]);
										}	
										write("pline 0 "+RED+"Usage: "+BLUE+"/specials <a> <c> <n> <r> <s> <b> <g> <q> <o>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}	
							}						
								
							//start the game
							else if (tokens[2].equalsIgnoreCase("/start"))
							{
								if ((chan.isOpByPosition(this))||(access >= CHANOP))
								{
									chan.write("startgame 1",this,1);
								}
								else
								{
									write("pline 0 "+RED+"No access to this command");
								}
							}
							
							//moves slot src and dst in channel
							else if (tokens[2].equalsIgnoreCase("/move"))
							{
								if ((chan.isFirstPlayer(this))||(access >= CHANOP))
								{
									if (cntTokens >= 5)
									{
										try 
										{
											int src = Integer.parseInt(tokens[3]);
											int dst = Integer.parseInt(tokens[4]);
											chan.movePlayer(src,dst);
										}
										catch (NumberFormatException e)
										{
											write("pline 0 "+RED+"usage: "+BLUE+"/move <source> <destination>");
										}
									}
									else
									{
										write("pline 0 "+RED+"usage: "+BLUE+"/move <source> <destination>");
									}	
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}								
							}
							
							//request winlist
							else if (tokens[2].equalsIgnoreCase("/winlist"))
							{
								if (cntTokens >= 5)
								{
									try 
									{
										int begin = Integer.parseInt(tokens[3]);
										int end = Integer.parseInt(tokens[4]);
										write("pline 0 check out the winlist via http://mysth.tetrinet.be/winlist.php");
									}
									catch (NumberFormatException e)
									{
										write("pline 0 "+RED+"usage: "+BLUE+"/winlist <begin> <end>");
									}
								}
								else
								{
									write("pline 0 "+RED+"usage: "+BLUE+"/winlist <begin> <end>");
								}	
							}
							
							//request statistics for nick
							else if (tokens[2].equalsIgnoreCase("/stats"))
							{
								if (cntTokens >= 4)
								{
									if (Utils.isValidName(tokens[3]))
									{
										write(db.getStats(tokens[3],'p'));
									}
									else
									{
										write("pline 0 "+RED+"Invalid name: "+tokens[3]);
									}
								}
								else
								{
									write("pline 0 "+RED+"usage: "+BLUE+"/stats <nick>");
								}
							}
						
							//request statistics for team
							else if (tokens[2].equalsIgnoreCase("/tstats"))
							{
								if (cntTokens >= 4)
								{
									if (Utils.isValidName(tokens[3]))
									{
										write(db.getStats(tokens[3],'t'));
									}
									else
									{
										write("pline 0 "+RED+"Invalid name: "+tokens[3]);
									}	
								}
								else
								{
									write("pline 0 "+RED+"usage: "+BLUE+"/tstats <team>");
								}	
							}
							
							//join a channel
							else if ((tokens[2].equalsIgnoreCase("/join"))||(tokens[2].equalsIgnoreCase("/j")))
							{
								if (cntTokens >= 4)
								{
									if (tokens[3].startsWith("#"))
									{
										serv.addToChannel(this,tokens[3].substring(1));
									}
									else
									{
										try
										{
											int chanNr = Integer.parseInt(tokens[3]);
											serv.addToChannel(this,chanNr);
										}
										catch (NumberFormatException nfe)
										{
											write("pline 0 "+RED+"Usage: "+BLUE+"/join <#channel | channum>");
										}
									}
								}
								else
								{
									write("pline 0 "+RED+"Usage: "+BLUE+"/join <#channel | channum>");
								}
							}
							
							//returns a list of channels
							else if (tokens[2].equalsIgnoreCase("/list"))
							{
								write(serv.listChannels());
							}
							
							//returns a list of connected players
							else if (tokens[2].equalsIgnoreCase("/who"))
							{
								write(serv.listPlayers(access));
							}
							
							//returns a list of connected operators
							else if (tokens[2].equalsIgnoreCase("/owho"))
							{
								write(serv.listOperators(access));
							}
							
							//returns a list of connected spectators
							else if (tokens[2].equalsIgnoreCase("/swho"))
							{
								if (access >= CHANOP)
								{
									write(serv.listSpectators(access));
								}
								else
								{
									write("pline 0 "+RED+" U have no access to this command");
								}
							}
							
							//unknown command
							else
							{
								write("pline 0 "+RED+"unknown command: "+tokens[2]);
								write("pline 0 Type "+BLUE+"/help "+BLACK+"for a list of available commands");
							}
						}
						else
						{
							//a partyline message
							chan.write(msg,this);
						}
					}
					
					//a partyline message
					else
					{
						chan.write(msg,this);
					}
				}
    		
    		//a partyline act
    		else if (tokens[0].equals("plineact"))
				{
					chan.write(msg,this); 
				}
				
				//a game message
				else if (tokens[0].equals("gmsg"))
				{
					//are we in a game?
					if (chan.getStatus() != NOGAME)
					{
						if (tokens[1].equals("t"))
						{
							write("gmsg * PONG");
						}
						else 
						{
							chan.write(msg);
						}
					}
					//this should not happen
					else
					{
						//disconnect("Invalid Input: "+msg);
					}
				}
				
				//request to start game
				else if (tokens[0].equals("startgame"))
				{
					if (chan.isFirstPlayer(this))
					{
						chan.write(msg,this,1);
					}
					else
					{
						disconnect("Invalid input: "+msg);
					}
				}
				
				//request to pause game
				else if (tokens[0].equals("pause"))
				{
					if ((status != NOGAME)&&(chan.isFirstPlayer(this)))
					{
						chan.write(msg,this,1);
					}
					else
					{
						disconnect("Invalid Input: "+msg);
					}
				}
				
				//this player lost
				else if (tokens[0].equals("playerlost"))
				{
					chan.write(msg,this,2);
				}
					
				//request for level update	
				else if (tokens[0].equals("lvl"))
				{
					if (status != NOGAME)
					{
						if (cntTokens >= 3)
						{
							try
							{
								int lvl = Integer.parseInt(tokens[2]);
								level = lvl;
								chan.write(msg,this,3);
							}
							catch (NumberFormatException nfe)
							{
								disconnect("illegal input: "+msg);
							}
						}
						else
						{
							disconnect("illegal input: "+msg);
						}
					}
					else
					{
						//disconnect("Invalid input: "+msg);
					}
				}
				
				//request for field update
				else if (tokens[0].equals("f"))
				{
					if (chan.getStatus() != NOGAME)
					{
						if (cntTokens >= 3)
						{
							int ok = (updatePlayField(tokens[2]));
							if (ok == 1)
							{
								chan.write(msg,this,3);
								blocksDropped++;
							}
							else
							{
								disconnect("illegal input: "+msg);
							}
						}
					}	
					else
					{
						//disconnect("illegal input: "+msg);
					}
				}
				
				//request for special block use
				else if (tokens[0].equals("sb"))
				{
					if (status != NOGAME)
					{
						if (cntTokens >= 4)
						{
							try
							{
								int specialOn = Integer.parseInt(tokens[1]);
								if (specialOn == 0)
								{
									for (int slot=1;slot<=chan.getMaxPlayers();slot++)
									{
										Player pl = chan.getPlayer(slot);
										if ((pl != null)&&(pl != this))
										{
											pl.setBlocksDropped(pl.getBlocksDropped()-1);
										}
									}
								
									int added = (int) tokens[2].charAt(2);
									added -= 48;
									addedToAll += added;
									if (added == 4)
									{
										++tetrisMade;
									}
								}
								else
								{
									Player pl = chan.getPlayer(specialOn);
									if (pl != null)
									{
										pl.setBlocksDropped(pl.getBlocksDropped()-1);
									}
								}
								chan.write(msg,this,3);	
							}
							catch (NumberFormatException nfe)
							{
								disconnect("illegal input: "+msg);
							}
						}
					}
					else
					{
						//disconnect("Illegal input: "+msg);
					}	
				}
				
    		//client changed team
    		else if (tokens[0].equals("team"))
    		{
    			if (cntTokens >= 3)
    			{
    				setTeam(tokens[2]);
    			}
    			else
    			{
    				setTeam("");
    			}
    		}
    		
    		//invalid input
    		else
    		{
    			disconnect("illegal input: "+msg);
    		}
    	}
    }
    disconnect("End of client");
	}
	
	//do initialstuf
	public synchronized void initClient()
	{
		try
		{
			//read initString from client
			int i;		
			StringBuffer strBuf = new StringBuffer();		
			while((i = in.read()) != -1 && i != 255 && i != 10 && i != 13)
			{
				strBuf.append((char)i);
			}
			String initString = strBuf.toString();
			
			//decode the initString and set version
			String init = Utils.decode(initString,"tetrisstart");
			version = TETRINET;
			if (init == null)
			{
				init = Utils.decode(initString,"tetrifaster");
				version = TETRIFAST;
			}
			//now lets try to set nick to decoded nick
			StringTokenizer parts = new StringTokenizer(init," ");
			if (parts.countTokens() >= 3)
			{
    		parts.nextToken();
    		setNick(parts.nextToken());
    		
    		//lets register this player to serv.players
				serv.addPlayer(this);
    		
    		//perfrom some access control
    		if (access == UNREGISTERED)
    		{
    			if ((db.isBanned(getHostName(),0))||(db.isBanned(getHostAddress(),0)))
					{
						write("pline 0 "+RED+"Your host is banned");
						disconnect("Your host is banned");
					}
				}
    		
    		//now fake a channel 
    		if (version == TETRINET)
				{
					write("playernum 1");
				}
				else
				{
					write(")#)(!@(*3 1");
				}
			
	  		//normally we should now recieve a teamname
	  		i = 0;
	  		strBuf = new StringBuffer();		
				while((i = in.read()) != -1 && i != 255 && i != 10 && i != 13)
				{
					strBuf.append((char)i);
				}
		  	initString = strBuf.toString();
		  	StringTokenizer t = new StringTokenizer(initString," ");
				if (t.countTokens() >= 3)
				{
					t.nextToken();
					t.nextToken();
					setTeam(t.nextToken());
				}
			
				//we got version,nick and team -> about time to send the MOTD
				write(Utils.getMotd());
				
				//now lets find this client a channel
				serv.addToChannel(this);
			}
    	else
    	{
    		disconnect("Invalid Client");
    	}
		}
		catch (Exception e)
		{
			disconnect("Invalid Client");
		}
	}
	
	//write a msg to the client
	public void write (String msg)
	{
		try
		{
			char[] lemp = msg.toCharArray();
			
			for (int i = 0; i < msg.length();i++)
			{	
				if (lemp[i] != '\n')	out.write((int)lemp[i]);
			}
			out.write(-1);
			out.flush();
		}
		catch (IOException e)
		{
			running = false;
		}
	}
	
	//write a msg to the client
	public void write (String msg[])
	{
		int i=0;
		while (i<msg.length)
		{
			for (int j=i;((j<msg.length)&&(j<i+15));j++)
			{
				write(msg[j]);
			}
			try
			{
				sleep(500);
			}
			catch (Exception e) { }
			finally
			{
				i += 15;
			}
		}
	}
	
	//read a message from the client
	public String read()
	{
		int k;
		StringBuffer strBuf = new StringBuffer();
		try
		{	
			while ((k = in.read()) != -1 && k != 255 && k != 13 && k != 10)
			{
				strBuf.append((char)k);
			}
			if (k == 255)
			{
				strBuf.append(" ");
			}
		}
		catch (IOException e) 
		{
			running = false;
		}
		finally
		{
			return strBuf.toString();
		}
	}
	
	//disconnect client from server
	public synchronized void disconnect (String msg)
	{
		//debugging help
		//System.out.println("disconnecting "+nick+": "+msg);
		if (chan != null)
		{
			chan.removePlayer(this);
		}
		if (serv != null)
		{
			serv.removePlayer(this);
			serv = null;
		}
		try
		{
			in.close();
			out.close();
			sock.close();
		}
		catch (Exception e) { }
		if (running)
		{
			write("noconnecting "+msg);
			running = false;
		}
		write("noconnecting "+msg);
	}
	
	//set nick to n
	public synchronized void setNick (String n)
	{
		if (Utils.isValidName(n))
		{
			//is this nick registered?
			if (db.isRegisteredName(n,"players"))
			{
				//require authentication
				if (version == TETRINET)
				{
					write("playernum 1");
				}
				else
				{
					write(")#)(!@(*3 1");
				}
				read(); write("team 1 ");
				write("pline 0 Nick "+BLUE+n+BLACK+" is a registered nick on this server");
				write("pline 0 Type /register <password> in the partyline to claim this nick");
				StringTokenizer strTok = new StringTokenizer(read()," ");
				if (strTok.countTokens() >= 4)
				{
					strTok.nextToken();
					strTok.nextToken();
					strTok.nextToken();
					String password = strTok.nextToken();
					if (db.isValidPassword(n,password))
					{
						nick = n;
						access = db.getAccess(nick,0);
						write("playerleave 1");
					}
					else
					{
    				write("pline 0 "+RED+"Invalid nick");
						disconnect("Invalid nick: wrong password");
					}
				}
				else
				{
					write("pline 0 "+RED+"Invalid nick");
					disconnect("Invalid nick: invalid input");
				}
			}
			else
			{
				nick = n;
			}
		}
		else
		{
			write("pline 0 "+RED+"Invalid nick");
			disconnect("Invalid nick: invalid name");
		}
	}
	
	//returns nick
	public synchronized String getNick ()
	{
		return nick;
	}
	
	//set team to t
	public synchronized void setTeam (String t)
	{
		//team name has not changed, do nothing
		if (t.equals(team)) { }
		//no team
		else if ((t.equals(""))||(t == null))
		{
			team = t;
			if (chan != null)
			{
				chan.write("team "+chan.getSlot(this)+" "+t,this);
			}
		}
		else if (Utils.isValidName(t))
		{
			if (db.isRegisteredName(t,"teams"))
			{
				//is this player a member of the team t?
				if (db.isTeamPlayer(nick,t))
				{
					team = t;
					if ((chan != null)&&(chan.getSlot(this) != 0))
					{
						chan.write("team "+chan.getSlot(this)+" "+t,this);
					}
				}
				
				else
				{
					write("pline 0 "+RED+"U are not a member of this team");
					if ((chan !=null)&&(chan.getSlot(this) != 0))
					{
						chan.write("team "+chan.getSlot(this)+" ");
					}
					else
					{
						write("team 1 ");
					}
				}
			}
			else
			{
				team = t;
				if ((chan !=null)&&(chan.getSlot(this) != 0))
				{
					chan.write("team "+chan.getSlot(this)+" "+t,this);	
				}
			}
		}
		else
		{
			write("pline 0 "+RED+"Invalid teamname: "+t);
			if ((chan !=null)&&(chan.getSlot(this) != 0))
			{
				chan.write("team "+chan.getSlot(this)+" ");		
			}
			else
			{
				write("team 1 ");
			}
		}
	}
	
	//returns team
	public synchronized String getTeam ()
	{
		return team;
	}
	
	//sets channel to ch
	public synchronized void setChannel (Channel ch)
	{
		chan = ch;
	}
	
	//returns chan
	public synchronized Channel getChannel ()
	{
		return chan;
	}
	
	//returns version
	public synchronized int getVersion ()
	{
		return version;
	}
	
	//returns hostaddress
	public synchronized String getHostAddress ()
	{
		return sock.getInetAddress().getHostAddress();
	}
	
	//returns hostname
	public synchronized String getHostName ()
	{
		return sock.getInetAddress().getHostName();
	}

		//clear the playField
	public synchronized void clearPlayField ()
	{
		for (int x=0;x<playField.length;x++)
		{
			for (int y=0;y<playField[x].length;y++)
			{
				playField[x][y] = 0;
			}
		}
	}
	
	//update the playField
	public synchronized int updatePlayField(String buf)
	{
		char p;
  	char blocktype,x,y;
  	int bailout = 0;
  	int teller = 0;
   	
  	if (buf.length() == (playField.length * playField[0].length))
  	{
  		teller = 0;
  		if ((buf.charAt(teller) > '/') || (buf.charAt(teller) < '!'))
    	{
    	 	p = buf.charAt(teller);
    	 	for (int i=0;i<playField.length;i++)
    	 	{
    	 		for (int j=0;j<playField[i].length;j++)
    	 		{
    	    	blocktype = p;
   	       	teller++;
   	       	playField[i][j]= (char) (blocktype - '0');
        	}
    	  }
   	 	}
   	 	else
			{
				bailout=1;
			}
   	}
   	
   	else
   	{
			p = buf.charAt(teller);
			while (bailout == 0 && (p != 255) && (teller < buf.length()))
    	{
      	blocktype = p;
      	if ((blocktype > '/') || (blocktype < '!')) 
      	{
      		bailout=1;
      	}
      	else
      	{
      		teller++;
      		if (teller < buf.length())
      		{
      			p = buf.charAt(teller);
      		}
      		blocktype -= '!';
      		while (bailout == 0 && (p != 255) && ((teller+1) < buf.length()) && (p >= '3') && (p <= '>'))
        	{
        		x = p;
        		teller++;
          	y = buf.charAt(teller);
          	teller++;
          	if (teller < buf.length())
          	{
          		p = buf.charAt(teller);
          	}
						
						if ((x >= '3') && (x <= '>') && (y >= '3') && (y <= 'H'))
          	{
          		x -= '3';
            	y -= '3';
            	playField[x][y] = blocktype;
          	}         
          
          	else
          	{
          		bailout=1;
          	}
          }
        }
      }
    }
  	
  	if (bailout != 0)
 		{
 			return -1;
  	}
  	return 1;
	}
	
	//returns the playField
	public synchronized String getPlayField ()
  {
    char block;
    char special[] = {'a','c','n','r','s','b','g','q','o'};
		StringBuffer str = new StringBuffer();
		str.append("f "+chan.getSlot(this)+" ");
		
    for(int y=0;y<playField[0].length;y++)
    {
      for(int x=0;x<playField.length;x++)
      {
      	block = (char) (playField[x][y]+'0');
      	if ((block >= '6') && (block <= '>'))
        {
        	block = special[block-'0'-6];
        }
        str.append(block);
      }
    }
    return str.toString();
  }

	//sets status to s
	public synchronized void setStatus (int s)
	{
		status = s;
	}
	
	//returns status
	public synchronized int getStatus ()
	{
		return status;
	}
	
	//sets access
	public synchronized void setAccess ()
	{
		if (access == REGISTERED)
		{
			int id = 0;
			if (chan != null)
			{
				id = chan.getId();
			}
			access = db.getAccess(nick,id);
		}
		else
		{
			access = UNREGISTERED;
		}
		switch (access)
		{
			case ADMIN:
				write("pline 0 AccessLevel: "+BLUE+"ADMIN"); break;
			case GLOBALOP:
				write("pline 0 AccessLevel: "+BLUE+"GLOBALOP"); break;
			case CHANOP:
				write("pline 0 AccessLevel: "+BLUE+"CHANOP"); break;
			case REGISTERED:
				write("pline 0 AccessLevel: "+BLUE+"REGISTERED"); break;
			default:
				write("pline 0 AccessLevel: "+BLUE+"UNREGISTERED");
		}
	}
	
	//returns access
	public synchronized int getAccess ()
	{
		return access;
	}
	
	//returns a string representation of player
	public synchronized String toString (int access)
	{
		StringBuffer strBuf = new StringBuffer();
		strBuf.append(BLUE+nick);
		if((team != null)&&(!team.equals("")))
		{
			strBuf.append(BLACK+", <"+PURPLE+team+BLACK+">");
		}
		if (access >= CHANOP)
		{
			strBuf.append(BLACK+"\t@ "+RED+getHostName());
		}
		return strBuf.toString();
	}
	
	//sets blocksDropped to b
	public synchronized void setBlocksDropped(int b)
	{
		blocksDropped = b;
	}
	
	//returns blocksDropped
	public synchronized int getBlocksDropped ()
	{
		return blocksDropped;
	} 
	
	//set level to l
	public synchronized void setLevel (int l)
	{
		level = l;
	}
	
	//returns level
	public synchronized int getLevel ()
	{
		return level;
	}
	
	//sets addedToAll to a
	public synchronized void setAddedToAll (int a)
	{
		addedToAll = a;
	}
	
	//returns addedToAll
	public synchronized int getAddedToAll ()
	{
		return addedToAll;
	}
	
	//sets tetrisMade to t
	public synchronized void setTetrisMade (int t)
	{
		tetrisMade = t;
	}
	
	//returns tetrisMade
	public synchronized int getTetrisMade ()
	{
		return tetrisMade;
	}
	
	//checks ppm
	public synchronized double getPpm ()
	{
		--blocksDropped;
		double ppm = ((blocksDropped * 60 * 1000.00)/playTime);
		//are we a cheater?
		if ((ppm >= MAX_PPM)&&(version == TETRINET))
		{
			db.addBan(getHostName(),0);
			db.addBan(getHostAddress(),0);
			disconnect("Congrats, U got yourself in the banlist ;)");
		}
		if (ppm < 0)
		{
			ppm = 0;
		}
		return ppm;
	}
		
	//returns statistics
	public synchronized String getStats ()
	{
		StringBuffer strBuf = new StringBuffer();
		strBuf.append(BLUE+nick);
		//strBuf.append(BLACK+" lvl: "+RED+level);
		DecimalFormat digits3 = new DecimalFormat("0.000");
		strBuf.append(BLACK+" ppm: "+RED+digits3.format(getPpm()));
		strBuf.append(BLACK+" add: "+RED+addedToAll);
		strBuf.append(BLACK+" tetris: "+RED+tetrisMade);
		return strBuf.toString();
	}
	
	//set playTime to p
	public synchronized void setPlayTime (double p)
	{
		playTime = p;
	}
	
	//returns playTime
	public synchronized double getPlayTime ()
	{
		return playTime;
	}
	
}
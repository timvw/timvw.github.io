import java.text.DecimalFormat;
import java.util.Vector;

public class ChannelSurvival extends Channel
{
	private int addedToAll;
	
	public ChannelSurvival (MySQL m,TetriServer s,int maxPlayers,int id,int type,int misc[],int blocks[],int specials[],String name,String topic)
	{
		db = m;
		serv = s;
		players = new Player[1];
		spectators = new Vector();
		if (type < CLASSICFAST)
		{
			version = TETRINET;
		}
		else
		{
			version = TETRIFAST;
		}
		game = new Game(type,misc,blocks,specials);
		this.name = name;
		this.topic = topic;
		persistant = true;
		this.id = id;
	}
	
	public synchronized void startGame (Player p)
	{	
		addedToAll = 0;
			
		//do a little countdown
		for (int t=0;t<3;t++)
		{
			try
			{
				write("pline 0 "+(3-t));
				Thread.sleep(900);
			}
			catch (InterruptedException ie) { }
		}
		
		game.setStatus(PLAYING);
		game.setStartTime(System.currentTimeMillis());
		p.setStatus(PLAYING);
		p.setBlocksDropped(0);
		p.clearPlayField();
		p.setLevel(game.getStartingLevel());
		p.setAddedToAll(0);
		p.setTetrisMade(0);
		p.write(game.toString(p.getVersion()));
		sudden = new SuddenTester(this);
	}
	
	public synchronized void checkGame (Player p)
	{
		p.write("playerlost "+getSlot(p));
		if (p.getStatus() == PLAYING)
		{
			sudden.setRunning(false);
			sudden.setChannel(null);
			p.setStatus(DEAD);
			p.setPlayTime(System.currentTimeMillis() - game.getStartTime());
			p.write("endgame");
			int dropped = p.getBlocksDropped();
			write("pline 0 Player "+BLUE+p.getNick()+BLACK+" scored "+RED+dropped+BLACK+" points");
			doStats();
			write(db.setScore(p.getNick(),dropped,game.getType()));
			//winlist changed, all channels with same winlist should inform their clients
			serv.sendWinlist(game.getType());
			p.setStatus(NOGAME);
			game.setStatus(NOGAME);
		}
	}
	
	public synchronized void doGame (Player p,String event)
	{
		int addNow = p.getAddedToAll() - addedToAll;
		if ((addNow > 0)&&(game.getStatus() == PLAYING))
		{
			addedToAll = p.getAddedToAll();
			for (int i=0;((i<addNow)&&(game.getStatus() == PLAYING));i++)
			{
				write("sb 0 c 0 ");
				p.setBlocksDropped(p.getBlocksDropped()-1);
				try
				{
					Thread.sleep(200);
				}
				catch (Exception e){ }
			}
		}
	}
	
}

		
	
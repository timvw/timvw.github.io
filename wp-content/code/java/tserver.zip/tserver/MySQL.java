import java.io.*;
import java.net.*;
import java.sql.*;
import java.text.*;
import java.util.*;

public class MySQL implements Constants
{
	static MySQL single = null;
	
	private Statement stat;
	private PreparedStatement pstmt[];
	private ResultSet result;
	
	//constructor
	private MySQL () throws Exception
	{
		//read in the mysql file
		BufferedReader br = new BufferedReader(new FileReader(FILE_MYSQL));
		String hostName = br.readLine();
		String dbName = br.readLine();
		String userName = br.readLine();
		String password = br.readLine();
			
		//load the db classes
		Class.forName("org.gjt.mm.mysql.Driver").newInstance();		
		//make connection with dbserver
		String connector = "jdbc:mysql://"+hostName+"/"+dbName+"?user="+userName+"&password="+password;
		Connection con = DriverManager.getConnection(connector);
		//create statements and preparedstatements
		stat = con.createStatement();
		pstmt = new PreparedStatement[40];
		pstmt[0] = con.prepareStatement("SELECT name FROM players WHERE name=?");
		pstmt[1] = con.prepareStatement("SELECT name FROM teams WHERE name=?");
		pstmt[2] = con.prepareStatement("SELECT id FROM players WHERE name=? AND password=?");
		pstmt[3] = con.prepareStatement("SELECT * FROM players,teams,teamplayers WHERE players.id = teamplayers.id_player AND players.name =? AND teams.id = teamplayers.id_team AND teams.name =? ");
		pstmt[4] = con.prepareStatement("SELECT host FROM banlist WHERE ? REGEXP host > 0 AND id_channel=?");	
		pstmt[5] = con.prepareStatement("SELECT type,name,points FROM winlist WHERE game_type=? ORDER BY points ASC LIMIT ?,?");
		pstmt[6] = con.prepareStatement("SELECT type,name,points FROM winlist WHERE game_type=? ORDER BY points DESC LIMIT ?,?");
		pstmt[7] = con.prepareStatement("SELECT * FROM players,admins WHERE players.name=? AND players.id = admins.id_player");
		pstmt[8] = con.prepareStatement("SELECT * FROM players,operators WHERE players.name=? AND players.id = operators.id_player AND operators.id_channel=?");
		pstmt[9] = con.prepareStatement("SELECT * FROM channel ORDER BY game_type,id");
		pstmt[10] = con.prepareStatement("INSERT INTO banlist(host,id_channel) VALUES (?,?)");
		pstmt[11] = con.prepareStatement("SELECT * FROM winlist WHERE name=? AND type='p' ORDER BY game_type ASC");
		pstmt[12] = con.prepareStatement("SELECT * FROM winlist WHERE name=? AND type='t' ORDER BY game_type ASC");
		pstmt[13] = con.prepareStatement("SELECT COUNT(*) FROM winlist WHERE game_type=? AND points < ?");
		pstmt[14] = con.prepareStatement("SELECT COUNT(*) FROM winlist WHERE game_type=? AND points > ?");
		pstmt[15] = con.prepareStatement("SELECT points FROM winlist WHERE name=? AND type='p' AND game_type=?");
		pstmt[16] = con.prepareStatement("UPDATE winlist SET points=? WHERE name=? AND type='p' AND game_type=?");					
		pstmt[17] = con.prepareStatement("INSERT INTO winlist(name,type,points,game_type) VALUES (?,'p',?,?)");		
		pstmt[18] = con.prepareStatement("SELECT points FROM winlist WHERE name=? AND type='t' AND game_type=?");
		pstmt[19] = con.prepareStatement("UPDATE winlist SET points=? WHERE name=? AND type='t' AND game_type=?");	
		pstmt[20] = con.prepareStatement("INSERT INTO winlist(name,type,points,game_type) VALUES (?,'t',?,?)");				
	}	

	public static MySQL giveMySQL () throws Exception
	{
		if (single == null)
		{
			single = new MySQL();
		}
		return single;
	}

	//load channels
	public void loadChannels (TetriServer serv)
	{
		try
		{	
			ResultSet result = pstmt[9].executeQuery();
			
			while (result.next())
			{
				int id = result.getInt("id");
				int type = result.getInt("game_type");
				String name = result.getString("name");
				String topic = result.getString("topic");
				int maxPlayers = result.getInt("max_players");
							
				int misc[] = new int[12];
				misc[0] = result.getInt("starting_height");
				misc[1] = result.getInt("starting_level");
				misc[2] = result.getInt("lines_per_level");
				misc[3] = result.getInt("level_increase");
				misc[4] = result.getInt("lines_per_special");
				misc[5] = result.getInt("special_added");
				misc[6] = result.getInt("special_capacity");
				misc[7] = result.getInt("average_levels");
				misc[8] = result.getInt("classic_rules");
				misc[9] = result.getInt("sd_sec_between_lines");
				misc[10] = result.getInt("sd_lines_added");
				misc[11] = result.getInt("sd_activate_time");
				
				int blocks[] = new int[7];
				blocks[0] = result.getInt("block_line");
				blocks[1] = result.getInt("block_square");
				blocks[2] = result.getInt("block_leftl");
				blocks[3] = result.getInt("block_rightl");
				blocks[4] = result.getInt("block_leftz");
				blocks[5] = result.getInt("block_rightz");
				blocks[6] = result.getInt("block_halfcross");

				int specials[] = new int[9];
				specials[0] = result.getInt("special_addline");
				specials[1] = result.getInt("special_clearline");
				specials[2] = result.getInt("special_nukefield");
				specials[3] = result.getInt("special_randomclear");
				specials[4] = result.getInt("special_switchfield");
				specials[5] = result.getInt("special_clearspecial");
				specials[6] = result.getInt("special_gravity");
				specials[7] = result.getInt("special_quakefield");
				specials[8] = result.getInt("special_blockbomb");
				
				switch (type)
				{
					case ONE:
					case ONEFAST:
						serv.addChannel(new ChannelOne(this,serv,maxPlayers,id,type,misc,blocks,specials,name,topic));
						break;
					case SEVENFASTSNS:
					case SEVEN:
					case SEVENFAST:
						serv.addChannel(new ChannelSeven(this,serv,maxPlayers,id,type,misc,blocks,specials,name,topic));
						break;
					case QUICK:
					case QUICKFAST:
						serv.addChannel(new ChannelQuick(this,serv,maxPlayers,id,type,misc,blocks,specials,name,topic));
						break;
					case SURVIVAL:
					case SURVIVALFAST:
						serv.addChannel(new ChannelSurvival(this,serv,maxPlayers,id,type,misc,blocks,specials,name,topic));
						break;
					case RACER:
					case RACERFAST:
						serv.addChannel(new ChannelRacer(this,serv,maxPlayers,id,type,misc,blocks,specials,name,topic));
						break;							
					default:
						serv.addChannel(new Channel(this,serv,maxPlayers,id,type,misc,blocks,specials,name,topic));
				}		
			}
		}
		catch (Exception e) 
		{ 
			System.out.println(e.toString());
		}
	}	
	
	//return winlist for gameType
	public String getWinlist (int gameType,int begin, int end)
	{
		try
		{
			//make sure we got the right query
			int i = 6;
			if ((gameType == ONE)||(gameType == SEVEN)||(gameType == ONEFAST) || (gameType == SEVENFAST) ||
			    (gameType == RACER)||(gameType == RACER)||(gameType == SEVENFASTSNS))
			{
				i = 5;
			}
			pstmt[i].clearParameters();
			pstmt[i].setInt(1,gameType);
			pstmt[i].setInt(2,begin);
			pstmt[i].setInt(3,(end-begin));
			result = pstmt[i].executeQuery();
			StringBuffer winList = new StringBuffer("winlist");	
			while (result.next())
			{
				winList.append(" ");
				winList.append(result.getString("type"));
				winList.append(result.getString("name"));
				winList.append(";");
				winList.append(result.getInt("points"));
			}
			return winList.toString();
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			return "winlist ";
		}
	}	
	
	//returns statistiscs on name
	public String[] getStats (String name,char type)
	{
		StringBuffer str = new StringBuffer();
		str.append("pline 0 Statistics for: "+BLUE+name+" \n");
		str.append("pline 0 Type \t Points \t Rank \n");
		try
		{
			int i = 11;
			if (type == 't')
			{
				i = 12;
			}
			pstmt[i].clearParameters();
			pstmt[i].setString(1,name);
			result = pstmt[i].executeQuery();
			while (result.next())
			{
				//get gameType and points
				int gameType = result.getInt("game_type");
				double points = result.getDouble("points");
				str.append("pline 0 ");
				
				String gameName = null;
				switch (gameType)
				{
					case CLASSIC: gameName = "Classic"; break;
					case PURE: gameName = "Pure Tris"; break;
					case ONE: gameName = "One"; break;
					case SEVEN: gameName = "Seven"; break;
					case QUICK: gameName = "Quick"; break;
					case SURVIVAL: gameName = "Survival"; break;
					case RACER:	gameName = "Racer"; break;
					case SNS: gameName= "SNS"; break;
					case CLASSICFAST: gameName = "FClassic"; break;
					case PUREFAST: gameName = "FPure"; break;
					case ONEFAST: gameName = "FOne"; break;
					case SEVENFAST: gameName = "FSeven"; break;	
					case SEVENFASTSNS: gameName = "FSevenSNS"; break;
					case QUICKFAST: gameName = "FQuick"; break;
					case SURVIVALFAST: gameName = "FSurvival"; break;
					case RACERFAST: gameName = "FRacer"; break;
					case SNSFAST: gameName = "FSNS"; break;
					default: gameName = "UNKNOWN";
				}
				
					
				DecimalFormat digits = new DecimalFormat("0");
				str.append(gameName+"\t "+RED+digits.format(points));
				
				//now lets get the rank
				i = 14;
				if ((gameType == ONE)||(gameType == SEVEN)||(gameType == ONEFAST) || (gameType == SEVENFAST) ||
			    (gameType == RACER)||(gameType == RACER)||(gameType == SEVENFASTSNS))
				{
					i = 13;
				}
				pstmt[i].clearParameters();
				pstmt[i].setInt(1,gameType);
				pstmt[i].setDouble(2,points);
				ResultSet result2 = pstmt[i].executeQuery();
				str.append(BLACK+"\t "+RED);
				if (result2.next())
				{
					str.append((result2.getInt("COUNT(*)")+1));
				}
				else
				{
					str.append("N/A");
				}
				str.append(" \n");
			}
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
		}
		finally
		{
			str.append("pline 0 End of Statistics");
			StringTokenizer tokens = new StringTokenizer(str.toString(),"\n");
			int cntTokens = tokens.countTokens();	
			String list[] = new String[cntTokens];
			for (int i=0;i<cntTokens;i++)
			{
				list[i] = tokens.nextToken();
			}
			return list;
		}
	}

	//is this name in the db?
	public boolean isRegisteredName (String name,String table)
	{
		try
		{
			int i = 0;
			if (table.equals("teams"))
			{
				i = 1;
			}
			pstmt[i].clearParameters();
			pstmt[i].setString(1,name);
			result = pstmt[i].executeQuery();
			if (result.next())
			{
				return true;
			}
			else
			{
				return false;
			}	
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			return false;
		}
	}
	
	//is nick a member from team?
	public boolean isTeamPlayer (String nick,String team)
	{
		try
		{
			pstmt[3].clearParameters();
			pstmt[3].setString(1,nick);
			pstmt[3].setString(2,team);
			result = pstmt[3].executeQuery();
			if (result.next())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			return false;
		}
	}
	
	//is the password for n valid?
	public boolean isValidPassword(String name,String password)
	{
		try
		{
			pstmt[2].clearParameters();
			pstmt[2].setString(1,name);
			pstmt[2].setString(2,password);
			result = pstmt[2].executeQuery();
			if (result.next())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			return false;
		}
	}

	//is this domain in the banlist for channel with id?
	public boolean isBanned (String host,int id)
	{
		try
		{
			pstmt[4].clearParameters();
			pstmt[4].setString(1,host);
			pstmt[4].setInt(2,id);
			result = pstmt[4].executeQuery();
			if (result.next())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			return false;
		}
	}

	//lookup the access level for nick
	public int getAccess (String nick,int id)
	{
		try
		{
			//is there an entry in the admins table?
			pstmt[7].clearParameters();
			pstmt[7].setString(1,nick);
			result = pstmt[7].executeQuery();
			if (result.next())
			{
				return ADMIN;
			}
			else
			{
				//is there an entry in the operators table with id=0?
				pstmt[8].clearParameters();
				pstmt[8].setString(1,nick);
				pstmt[8].setInt(2,0);
				result = pstmt[8].executeQuery();
				if (result.next())
				{
					return GLOBALOP;
				}
				else
				{
					//is there an entry with operators.id = id?
					pstmt[8].clearParameters();
					pstmt[8].setString(1,nick);
					pstmt[8].setInt(2,id);
					result = pstmt[8].executeQuery();
					if (result.next())
					{
						return CHANOP;
					}
					else
					{	
						return REGISTERED;
					}
				}
			} 
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			return  REGISTERED;
		}
	}

	//add host to banlist
	public void addBan (String host,int id)
	{
		try
		{
			pstmt[10].clearParameters();
			pstmt[10].setString(1,host);
			pstmt[10].setInt(2,id);
			result = pstmt[10].executeQuery();
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
		}
	}	

	//check if name has improved his time
	public String setTime (String name, double time,int gameType)
	{
		try
		{
			pstmt[15].clearParameters();
			pstmt[15].setString(1,name);
			pstmt[15].setInt(2,gameType);
			result = pstmt[15].executeQuery();
			if (result.next())
			{
				double oldTime = result.getDouble("points");
				if (oldTime >= time)
				{
					pstmt[16].clearParameters();
					pstmt[16].setDouble(1,time);
					pstmt[16].setString(2,name);
					pstmt[16].setInt(3,gameType);
					pstmt[16].executeQuery();
				}
				else
				{
					time = oldTime;
				}
			}
			
			else
			{
				pstmt[17].clearParameters();
				pstmt[17].setString(1,name);
				pstmt[17].setDouble(2,time);
				pstmt[17].setInt(3,gameType);
				pstmt[17].executeQuery();
			}
			
			//now lookup the rank of this player
			pstmt[13].clearParameters();
			pstmt[13].setInt(1,gameType);
			pstmt[13].setDouble(2,time);
			result = pstmt[13].executeQuery();
			result.next();
			int rank = result.getInt("COUNT(*)") + 1;
			time /= 1000.00;
			return "pline 0 "+BLUE+name+BLACK+" best time: "+RED+time+BLACK+" seconds rank: "+RED+rank;
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			return "pline 0 "+RED+"MySQL/Winlist is unavailable";
		}
	}
	
	//check if name has improved his score
	public String setScore (String name, int score,int gameType)
	{
		try
		{
			pstmt[15].clearParameters();
			pstmt[15].setString(1,name);
			pstmt[15].setInt(2,gameType);
			result = pstmt[15].executeQuery();
			if (result.next())
			{
				int oldScore = result.getInt("points");
				if (score >= oldScore)
				{
					pstmt[16].clearParameters();
					pstmt[16].setInt(1,score);
					pstmt[16].setString(2,name);
					pstmt[16].setInt(3,gameType);
					pstmt[16].executeQuery();
				}
				else
				{
					score = oldScore;
				}
			}
			
			else
			{
				pstmt[17].clearParameters();
				pstmt[17].setString(1,name);
				pstmt[17].setInt(2,score);
				pstmt[17].setInt(3,gameType);
				pstmt[17].executeQuery();
			}
			
			//now lookup the rank of this player
			pstmt[14].clearParameters();
			pstmt[14].setInt(1,gameType);
			pstmt[14].setInt(2,score);
			result = pstmt[14].executeQuery();
			result.next();
			int rank = result.getInt("COUNT(*)") + 1;
			return "pline 0 "+BLUE+name+BLACK+" best score: "+RED+score+BLACK+" rank: "+RED+rank;
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			return "pline 0 "+RED+"MySQL/Winlist is unavailable";
		}
	}	
	
	//check wether client with name is operator in chan with id
	public boolean isOperator (String nick,int id)
	{
		try
		{
			pstmt[8].clearParameters();
			pstmt[8].setString(1,nick);
			pstmt[8].setInt(2,id);
			result = pstmt[8].executeQuery();
			if (result.next())
			{
				return true;
			}
			else
			{	
				return false;
			} 
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			return false;
		}
	}
	
	//add points to winlist
	public String addPoints (String nick,char type,int points,int gameType)
	{
		try
		{
			int i = 15;
			int j = 16;
			int k = 17;
			if (type == 't')
			{
				i = 18;
				j = 19;
				k = 20;
			}
			pstmt[i].clearParameters();
			pstmt[i].setString(1,nick);
			pstmt[i].setInt(2,gameType);
			result = pstmt[i].executeQuery();
			int oldPoints = 0;
			if (result.next())
			{
				oldPoints = result.getInt("points");
				points += oldPoints;
				pstmt[j].clearParameters();
				pstmt[j].setInt(1,points);
				pstmt[j].setString(2,nick);
				pstmt[j].setInt(3,gameType);
				pstmt[j].executeQuery();
			}
			else
			{
				pstmt[k].clearParameters();
				pstmt[k].setString(1,nick);
				pstmt[k].setInt(2,points);
				pstmt[k].setInt(3,gameType);
				pstmt[k].executeQuery();
			}				
			
			//now lets get the rank
			pstmt[14].clearParameters();
			pstmt[14].setInt(1,gameType);
			pstmt[14].setDouble(2,points);
			ResultSet result2 = pstmt[14].executeQuery();
			result2.next();
			int rank = result2.getInt("COUNT(*)")+1;
			
			if (type == 'p')
			{
				return "pline 0 Player "+BLUE+nick+BLACK+" points: "+RED+points+BLACK+" rank: "+RED+rank;
			}
			else
			{
				return "pline 0 Team "+BLUE+nick+BLACK+" points: "+RED+points+BLACK+" rank: "+RED+rank;
			}
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			return "pline 0 Sorry, MySQL/Winlist is currently down";
		}
	}
	
}
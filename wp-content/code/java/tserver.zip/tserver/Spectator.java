import java.io.*;
import java.net.*;
import java.util.*;

public class Spectator extends Thread implements Constants
{
	protected Socket sock;
	protected InputStream in;
	protected OutputStream out;
	protected MySQL db;
	protected boolean running;
	protected String nick;
	protected Channel chan;
	protected int access;
	protected TetriServer serv;
	
	//constructor
	public Spectator (Socket s,TetriServer t) throws IOException
	{
		sock = s;
		in = s.getInputStream();
		out = s.getOutputStream();
		serv = t;
		db = serv.getMySQL();
		access = UNREGISTERED;
		running = true;
		start();
	}
	
	//main loop
	public void run ()
	{
		initClient();
		
		while (running)
		{
		  String msg = read();
    	if ((msg == null)||(msg.length() == 0))
    	{
    		disconnect("IOError");
    	}
    	else
    	{
    		StringTokenizer inTok = new StringTokenizer(msg," ");
				int cntTokens = inTok.countTokens();
				String tokens[] = new String[cntTokens];
			
				for (int i=0;i<cntTokens;i++)
				{
					tokens[i] = inTok.nextToken();
				}
				//System.out.println("SPECTATOR "+nick+" RECV: "+msg);
				
				//partyline message
				if (tokens[0].equals("pline"))
				{
					if (cntTokens >= 3)
					{
						if (tokens[2].startsWith("/"))
						{
							//gives an overview of available commands
							if (tokens[2].equalsIgnoreCase("/help"))
							{
								write("pline 0 Available Commands on Server ");
								write("pline 0 End of Available Commands on Server");
							}

							//send <msg> to all players
							else if (tokens[2].equalsIgnoreCase("/broadcast"))
							{
								if (access >= GLOBALOP)
								{
									if (cntTokens >= 4)
									{
										StringBuffer strBuf = new StringBuffer();
										for (int i=3;i<cntTokens;i++)
										{
											strBuf.append(" "+tokens[i]);
										}
										serv.broadcast(strBuf.toString());
									}
									else
									{	
										write("pline 0 "+RED+"Usage: "+BLUE+"/broadcast <msg>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}	
							}
							
							
							//kick <playernum>
							else if (tokens[2].equalsIgnoreCase("/kick"))
							{
								if (access >= CHANOP)
								{
									if (cntTokens >= 4)
									{
										try
										{
											int playernumber = Integer.parseInt(tokens[3]);
											int channum = playernumber / 10;
											int playernum = playernumber % 10;
											if (channum == 0)
											{
												Player p = chan.getPlayer(playernum);
												if (p != null)
												{
													p.disconnect("kick");
												}
												else
												{
													write("pline 0 <playernum> did not exist");
												}		
											}
											else
											{
												if (access >= GLOBALOP)
												{
													Player p = serv.getPlayer(playernumber);
													if (p != null)
													{
														p.disconnect("kick");
													}
													else
													{
														write("pline 0 <playernum> did not exist");
													}	
												}
												else
												{
													write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");	
												}
											}
										}
										catch (NumberFormatException nfe)
										{
											write("pline 0 "+RED+"Usage: "+BLUE+"/kick <playernum>");
										}
									}
									else
									{
										write("pline 0 "+RED+"Usage: "+BLUE+"/kick <playernum>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}
							}	
							
							//ban <playernum>
							else if (tokens[2].equalsIgnoreCase("/ban"))
							{
								if (access >= CHANOP)
								{
									if (cntTokens >= 4)
									{
										try
										{
											int playernumber = Integer.parseInt(tokens[3]);
											int channum = playernumber / 10;
											int playernum = playernumber % 10;
											if (channum == 0)
											{
												Player p = chan.getPlayer(playernum);
												if (p != null)
												{
													db.addBan(p.getHostName(),chan.getId());
													db.addBan(p.getHostAddress(),chan.getId());
													p.disconnect("kick");
												}
												else
												{
													write("pline 0 <playernum> did not exist");
												}	
											}
											else
											{
												if (access >= GLOBALOP)
												{
													Player p = serv.getPlayer(playernumber);
													if (p != null)
													{
														db.addBan(p.getHostName(),0);
														db.addBan(p.getHostAddress(),0);
														p.disconnect("kick");
													}
													else
													{
														write("pline 0 <playernum> did not exist");
													}	
												}
												else
												{
													write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");	
												}
											}
										}
										catch (NumberFormatException nfe)
										{
											write("pline 0 "+RED+"Usage: "+BLUE+"/ban <playernum>");
										}
									}
									else
									{
										write("pline 0 "+RED+"Usage: "+BLUE+"/ban <playernum>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}
							}		
							
							//send <msg> to <nick>
							else if (tokens[2].equalsIgnoreCase("/cmsg"))
							{
								if (cntTokens >= 5)
								{
									StringBuffer strBuf = new StringBuffer();
									for (int i=4;i<cntTokens;i++)
									{
										strBuf.append(" "+tokens[i]);
									}
									write(serv.write(nick,tokens[3],strBuf.toString()));
								}
								else
								{
									write("pline 0 "+RED+"Usage: "+BLUE+"/cmsg <nick> <msg>");
								}
							}		
							
							//send <msg> to operators
							else if (tokens[2].equalsIgnoreCase("/omsg"))
							{
								if (cntTokens >= 4)
								{
									StringBuffer strBuf = new StringBuffer();
									for (int i=3;i<cntTokens;i++)
									{
										strBuf.append(" "+tokens[i]);
									}
									write(serv.owrite(nick,strBuf.toString()));
								}
								else
								{
									write("pline 0 "+RED+"Usage: "+BLUE+"/omsg <msg>");
								}
							}	
							
							//change topic
							else if (tokens[2].equalsIgnoreCase("/topic"))
							{
								if (access >= CHANOP)
								{
									if (cntTokens >= 4)
									{
										StringBuffer strBuf = new StringBuffer();
										for (int i=3;i<cntTokens;i++)
										{
											strBuf.append(" "+tokens[i]);
										}
										chan.setTopic(strBuf.toString());
										write("pline 0 Set topic to: "+BLUE+chan.getTopic());
									}
									else
									{	
										write("pline 0 "+RED+"Usage: "+BLUE+"/topic <topic>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}		
							}	
						
							//set block occurrence
							else if (tokens[2].equalsIgnoreCase("/blocks"))
							{
								if (access >= CHANOP)
								{
									int blocks[] = chan.getGame().getBlocks();
									String blName[] = {"stick","square","leftl","rightl","leftz","rightz","cross"};
																
									if (cntTokens >= 10)
									{
										blocks = new int[7];
										try
										{
											for (int i=0;i<blocks.length;i++)
											{
												blocks[i] = Integer.parseInt(tokens[i+3]);
											}
											if (chan.getGame().setBlocks(blocks))
											{
												write("pline 0 Trying to change block occurrence: "+GREEN+"SUCCES");
											}
											else
											{
												write("pline 0 Trying to change block occurrence: "+RED+"FAILED");
											}
										}
										catch (NumberFormatException nfe)
										{
											write("pline 0 "+RED+"Usage: "+BLUE+"/blocks <stick> <square> <leftl> <rightl> <leftz> <rightz> <cross>");
										}
									}
									else
									{
										write("pline 0 Block settings for "+BLUE+chan.getName());
										for (int i=0;i<blocks.length;i++)
										{
											write("pline 0 "+blName[i]+"\t: "+RED+blocks[i]);
										}	
										write("pline 0 "+RED+"Usage: "+BLUE+"/blocks <stick> <square> <leftl> <rightl> <leftz> <rightz> <cross>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}	
							}
						
							//set specials occurrence
							else if (tokens[2].equalsIgnoreCase("/specials"))
							{
								if (access >= CHANOP)
								{
									int specials[] = chan.getGame().getSpecials();
									String sName[] = {"a","c","n","r","s","b","g","q","o"};
																	
									if (cntTokens >= 12)
									{
										specials = new int[9];
										try
										{
											for (int i=0;i<specials.length;i++)
											{
												specials[i] = Integer.parseInt(tokens[i+3]);
											}
											if (chan.getGame().setSpecials(specials))
											{
												write("pline 0 Trying to change special occurrence: "+GREEN+"SUCCES");
											}
											else
											{
												write("pline 0 Trying to change special occurrence: "+RED+"FAILED");
											}
										}
										catch (NumberFormatException nfe)
										{
											write("pline 0 "+RED+"Usage: "+BLUE+"/specials <a> <c> <n> <r> <s> <b> <g> <q> <o>");
										}																		
									}
									else
									{
										write("pline 0 Special settings for "+BLUE+chan.getName());
										for (int i=0;i<specials.length;i++)
										{
											write("pline 0 "+sName[i]+"\t: "+RED+specials[i]);
										}	
										write("pline 0 "+RED+"Usage: "+BLUE+"/specials <a> <c> <n> <r> <s> <b> <g> <q> <o>");
									}
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}	
							}						
								
							//start the game
							else if (tokens[2].equalsIgnoreCase("/start"))
							{
								if (access >= CHANOP)
								{
									int slot = 1;
									Player p = null;
									while ((p == null)&&(slot < 7))
									{
										p = chan.getPlayer(slot);
										slot++;
									}
									if (p != null)
									{
										chan.write("startgame 1",p,1);
									}
									else
									{
										write("pline 0 this channel contains no players, game could not be started");
									}
								}
								else
								{
									write("pline 0 "+RED+"No access to this command");
								}
							}
							
							//moves slot src and dst in channel
							else if (tokens[2].equalsIgnoreCase("/move"))
							{
								if (access >= CHANOP)
								{
									if (cntTokens >= 5)
									{
										try 
										{
											int src = Integer.parseInt(tokens[3]);
											int dst = Integer.parseInt(tokens[4]);
											chan.movePlayer(src,dst);
										}
										catch (NumberFormatException e)
										{
											write("pline 0 "+RED+"usage: "+BLUE+"/move <source> <destination>");
										}
									}
									else
									{
										write("pline 0 "+RED+"usage: "+BLUE+"/move <source> <destination>");
									}	
								}
								else
								{
									write("pline 0 U are "+RED+"not"+BLACK+" allowed to do this");
								}								
							}
							
							//request winlist
							else if (tokens[2].equalsIgnoreCase("/winlist"))
							{
								if (cntTokens >= 5)
								{
									try 
									{
										int begin = Integer.parseInt(tokens[3]);
										int end = Integer.parseInt(tokens[4]);
										write("pline 0 check out the winlist via http://mysth.tetrinet.be/winlist.php");
									}
									catch (NumberFormatException e)
									{
										write("pline 0 "+RED+"usage: "+BLUE+"/winlist <begin> <end>");
									}
								}
								else
								{
									write("pline 0 "+RED+"usage: "+BLUE+"/winlist <begin> <end>");
								}	
							}
							
							//request statistics for nick
							else if (tokens[2].equalsIgnoreCase("/stats"))
							{
								if (cntTokens >= 4)
								{
									if (Utils.isValidName(tokens[3]))
									{
										write(db.getStats(tokens[3],'p'));
									}
									else
									{
										write("pline 0 "+RED+"Invalid name: "+tokens[3]);
									}
								}
								else
								{
									write("pline 0 "+RED+"usage: "+BLUE+"/stats <nick>");
								}
							}
						
							//request statistics for team
							else if (tokens[2].equalsIgnoreCase("/tstats"))
							{
								if (cntTokens >= 4)
								{
									if (Utils.isValidName(tokens[3]))
									{
										write(db.getStats(tokens[3],'t'));
									}
									else
									{
										write("pline 0 "+RED+"Invalid name: "+tokens[3]);
									}	
								}
								else
								{
									write("pline 0 "+RED+"usage: "+BLUE+"/tstats <team>");
								}	
							}
							
							//join a channel
							else if ((tokens[2].equalsIgnoreCase("/join"))||(tokens[2].equalsIgnoreCase("/j")))
							{
								if (cntTokens >= 4)
								{
									if (tokens[3].startsWith("#"))
									{
										serv.addToChannel(this,tokens[3].substring(1));
									}
									else
									{
										try
										{
											int chanNr = Integer.parseInt(tokens[3]);
											serv.addToChannel(this,chanNr);
										}
										catch (NumberFormatException nfe)
										{
											write("pline 0 "+RED+"Usage: "+BLUE+"/join <#channel | channum>");
										}
									}
								}
								else
								{
									write("pline 0 "+RED+"Usage: "+BLUE+"/join <#channel | channum>");
								}
							}
							
							//returns a list of channels
							else if (tokens[2].equalsIgnoreCase("/list"))
							{
								write(serv.listChannels());
							}
							
							//returns a list of connected players
							else if (tokens[2].equalsIgnoreCase("/who"))
							{
								write(serv.listPlayers(access));
							}
							
							//returns a list of connected operators
							else if (tokens[2].equalsIgnoreCase("/owho"))
							{
								write(serv.listOperators(access));
							}
							
							//returns a list of connected spectators
							else if (tokens[2].equalsIgnoreCase("/swho"))
							{
								if (access >= CHANOP)
								{
									write(serv.listSpectators(access));
								}
								else
								{
									write("pline 0 "+RED+" U have no access to this command");
								}
							}
							
							//paryline message
							else
							{
								StringBuffer strBuf = new StringBuffer();
								for (int i=3;i<cntTokens;i++)
								{
									strBuf.append(" "+tokens[i]);
								}
								String msg2 = strBuf.toString();
								if (msg2 != null)
								{
									chan.write("pline 0 Spectator "+BLUE+nick+BLACK+":"+msg2);
								}
							}
						}
					}
				}					
			}
		}
		disconnect("end of client");
	}

	//write a msg to the client
	public void write (String msg)
	{
		try
		{
			char[] lemp = msg.toCharArray();
			
			for (int i = 0; i < msg.length();i++)
			{	
				if (lemp[i] != '\n')	out.write((int)lemp[i]);
			}
			out.write(-1);
			out.flush();
		}
		catch (IOException e)
		{
			running = false;
		}
	}
	
	//write a msg to the client
	public void write (String msg[])
	{
		int i=0;
		while (i<msg.length)
		{
			for (int j=i;((j<msg.length)&&(j<i+15));j++)
			{
				write(msg[j]);
			}
			try
			{
				sleep(500);
			}
			catch (Exception e) { }
			finally
			{
				i += 15;
			}
		}
	}
	
	//read a message from the client
	public String read()
	{
		int k;
		StringBuffer strBuf = new StringBuffer();
		try
		{	
			while ((k = in.read()) != -1 && k != 255 && k != 13 && k != 10)
			{
				strBuf.append((char)k);
			}
			if (k == 255)
			{
				strBuf.append(" ");
			}
		}
		catch (IOException e) 
		{
			running = false;
		}
		finally
		{
			return strBuf.toString();
		}
	}
	
	//disconnect client from server
	public synchronized void disconnect (String msg)
	{
		//debugging help
		//System.out.println("disconnecting "+nick+": "+msg);
		if (chan != null)
		{
			chan.removeSpectator(this);
		}
		if (serv != null)
		{
			serv.removeSpectator(this);
			serv = null;
		}
		try
		{
			in.close();
			out.close();
			sock.close();
		}
		catch (Exception e) { }
		if (running)
		{
			write("noconnecting "+msg);
			running = false;
		}
		write("noconnecting "+msg);
	}
	
	//init client 
	public synchronized void initClient ()
	{
		try
		{
			//read initString from client
			int i;		
			StringBuffer strBuf = new StringBuffer();		
			while((i = in.read()) != -1 && i != 255 && i != 10 && i != 13)
			{
				strBuf.append((char)i);
			}
			String initString = strBuf.toString();
			
			//decode the initString
			String init = Utils.decode(initString,"tetrisstart");
			if (init == null)
			{
				init = Utils.decode(initString,"tetrifaster");
			}
			if (init == null)
			{
				disconnect("strange decoding of initstring: "+init);
			}
			
			//now lets try to set nick to decoded nick
			StringTokenizer parts = new StringTokenizer(init," ");
			if (parts.countTokens() >= 3)
			{
    		parts.nextToken();
    		setNick(parts.nextToken());
    		
    		//lets register this spectator to serv.spectators
				serv.addSpectator(this);
    		
    		//now fake a channel 
    		write("speclist ghostChannel");
				
				//about time to send the MOTD
				write(Utils.getMotd());
				
				//now lets find this client a channel
				//serv.addToChannel(this);
				write("pline 0 "+BOLD+RED+"This is a ghostChannel");
				write("pline 0 "+BOLD+RED+"U are currently NOT connected to a channel");
				write("pline 0 "+BOLD+RED+"Type /help for a list of available commands");
			}
    	else
    	{
    		disconnect("Invalid Client wrong decoding of initstring");
    	}
		}
		catch (Exception e)
		{
			disconnect("Invalid Client:exception occured");
		}
	}
	
	//returns hostaddress
	public synchronized String getHostAddress ()
	{
		return sock.getInetAddress().getHostAddress();
	}
	
	//returns hostname
	public synchronized String getHostName ()
	{
		return sock.getInetAddress().getHostName();
	}
	
	//sets access
	public synchronized void setAccess ()
	{
		if (access == REGISTERED)
		{
			int id = 0;
			if (chan != null)
			{
				id = chan.getId();
			}
			access = db.getAccess(nick,id);
		}
		else
		{
			access = UNREGISTERED;
		}
		switch (access)
		{
			case ADMIN:
				write("pline 0 AccessLevel: "+BLUE+"ADMIN"); break;
			case GLOBALOP:
				write("pline 0 AccessLevel: "+BLUE+"GLOBALOP"); break;
			case CHANOP:
				write("pline 0 AccessLevel: "+BLUE+"CHANOP"); break;
			case REGISTERED:
				write("pline 0 AccessLevel: "+BLUE+"REGISTERED"); break;
			default:
				write("pline 0 AccessLevel: "+BLUE+"UNREGISTERED");
		}
	}
	
	//returns access
	public synchronized int getAccess ()
	{
		return access;
	}
	
	//returns a string representation of spectator
	public synchronized String toString (int access)
	{
		StringBuffer strBuf = new StringBuffer();
		strBuf.append(BLUE+nick);
		if (access >= CHANOP)
		{
			strBuf.append(BLACK+"\t@ "+RED+getHostName());
		}
		return strBuf.toString();
	}
	
	//set channel to c
	public synchronized void setChannel (Channel c)
	{
		chan = c;
	}
	
	//returns channel
	public synchronized Channel getChannel ()
	{
		return chan;
	}
	
	//set nick to n
	public synchronized void setNick (String n)
	{
		if (Utils.isValidName(n))
		{
			//is this nick registered?
			if (db.isRegisteredName(n,"players"))
			{
				write("pline 0 Nick "+BLUE+n+BLACK+" is a registered nick on this server");
				write("pline 0 Type /register <password> in the partyline to claim this nick");
				StringTokenizer strTok = new StringTokenizer(read()," ");
				if (strTok.countTokens() >= 4)
				{
					strTok.nextToken();
					strTok.nextToken();
					strTok.nextToken();
					String password = strTok.nextToken();
					if (db.isValidPassword(n,password))
					{
						nick = n;
						access = db.getAccess(nick,0);
						write("specleave "+nick);
					}
					else
					{
    				write("pline 0 "+RED+"Invalid nick");
						disconnect("Invalid nick: wrong password");
					}
				}
				else
				{
					write("pline 0 "+RED+"Invalid nick");
					disconnect("Invalid nick: invalid input");
				}
			}
			else
			{
				write("pline 0 "+RED+"Only Operators are allowed to spectate");
				disconnect("Invalid nick: not an operator");
			}
		}
		else
		{
			write("pline 0 "+RED+"Invalid nick");
			disconnect("Invalid nick: invalid name");
		}
	}
	
	//returns nick
	public synchronized String getNick ()
	{
		return nick;
	}
	
}	
import java.util.StringTokenizer;
import java.util.Vector;

public class Channel implements Constants
{
	protected String name;
	protected String topic;
	protected int id;
	protected int version;
	protected Player players[];
	protected Vector spectators;
	protected MySQL db;
	protected Game game;
	protected boolean persistant;
	protected TetriServer serv;
	protected SuddenTester sudden;
	
	//constructor
	protected Channel () { }
	
	//constructor
	public Channel (MySQL m,TetriServer s,int version)
	{
		db = m;
		serv = s;
		id = 0;
		name = "Channel";
		topic = " ";
		this.version = version;
		players = new Player[6];
		spectators = new Vector();
		persistant = false;
		game = new Game();
	}
	
	//constructor
	public Channel (MySQL m,TetriServer s,int maxPlayers,int id,int type,int misc[],int blocks[],int specials[],String name,String topic)
	{
		db = m;
		serv = s;
		if ((maxPlayers <= 0)||(maxPlayers > 6))
		{
			maxPlayers = 6;
		}
		players = new Player[maxPlayers];
		spectators = new Vector();
		if (type < CLASSICFAST)
		{
			version = TETRINET;
		}
		else
		{
			version = TETRIFAST;
		}
		game = new Game(type,misc,blocks,specials);
		this.name = name;
		this.topic = topic;
		persistant = true;
		this.id = id;
	}	
	
	
	//try to add player
	public synchronized void addPlayer (Player p,int slot)
	{
		//first check if this slot is empty
		if (players[slot-1] == null)
		{
			//now check if p has the right version
			if (p.getVersion() == version)
			{
				//now check if p is not banned from this channel
				if ((!db.isBanned(p.getHostName(),id))&&(!db.isBanned(p.getHostAddress(),id)))
				{
					//remove p from his old chan
					Channel ch = p.getChannel();
					if (ch != null)
					{
						ch.removePlayer(p);
					}
					
					players[slot-1] = p;
					p.setChannel(this);
					
					//tell p he joined on slot
					if (p.getVersion() == TETRINET)
					{
						p.write("playernum "+slot);
					}
					else
					{
						p.write(")#)(!@(*3 "+slot);
					}
					
					//now lets talk about the others
					for (int i=0;i<players.length;i++)
					{
						if ((players[i] != null)&&(players[i] != p))
						{
							//tell p who the others are
							p.write("playerjoin "+(i+1)+" "+players[i].getNick());
							//tell p what teams the others are on
							if ((players[i].getTeam() != null)&&(!players[i].getTeam().equals("")))
							{
								p.write("team "+(i+1)+" "+players[i].getTeam());
							}
							//tell the others that p joined
							players[i].write("playerjoin "+slot+" "+p.getNick());
							//tell the others what team p is on
							if ((p.getTeam() != null)&&(!p.getTeam().equals("")))
							{
								players[i].write("team "+slot+" "+p.getTeam());
							}
						}
					}
			
					//tell the spectators this player has entered the channel
					specWrite("playerjoin "+slot+" "+p.getNick());
					if ((p.getTeam() != null)&&(!p.getTeam().equals("")))
					{
						specWrite("team "+slot+" "+p.getTeam());
					}
					
					//tell p in what state this channel is
					if (game.getStatus() != NOGAME)
					{
						p.write("ingame");
						if (game.getStatus() == PAUSED)
						{
							p.write("pause 1");
						}
						//make sure p loses this game
						p.setStatus(NOGAME);
						write("playerlost "+slot);
						
						//send p the others their playField
						for (int i=0;i<players.length;i++)
						{
							if ((players[i] != null)&&(players[i] != p))
							{
								if (players[i].getStatus() != PLAYING)
								{
									p.write("playerlost "+(i+1));
								}
								else
								{
									p.write(players[i].getPlayField());
								}
							}
						}
					}	
					
					//say hello to p
					p.write("pline 0 Welcome in "+BLUE+name+BLACK+", "+topic);
			
					//send winlist of this channel type
					p.write(db.getWinlist(game.getType(),0,10));
					
					//now change access level
					if (players[slot-1].getAccess() <= CHANOP)
					{
						players[slot-1].setAccess();
					}
					
					//do last sanity check
					if (p == null)
					{
						write("playerleave "+slot);
					}					
				}
				//p is banned from this channel
				else
				{
					p.write("pline 0 "+RED+"U are banned from this channel");
				}
			}
			//p has invalid version
			else
			{
				p.write("pline 0 "+RED+"U have an invalid version for this channel");
			}
		}
		//slot was not empty
		else
		{
			p.write("pline 0 "+RED+"Invalid slot");
		}	
	}

	//add a player to this channel
	public synchronized void addPlayer (Player p)
	{
		int slot = getEmptySlot();
		if (slot > 0)
		{
			addPlayer(p,slot);
		}
		else
		{
			p.write("pline O "+RED+"Channel "+BLUE+name+RED+" is already full");
		}
	}
	
	//removes a player from this channel
	public synchronized void removePlayer (int slot)
	{
		//find out if there is a player on this slot
		if ((slot > 0)&&(slot <= players.length)&&(players[slot-1] != null))
		{
			players[slot-1].setChannel(null);

			//if there was a game running, tell the others slot has lost
			if (game.getStatus() != NOGAME)
			{
				write("playerlost "+slot,players[slot-1],2);
				players[slot-1].setStatus(NOGAME);
				players[slot-1].write("endgame");
			}
						
			for (int i=0;i<players.length;i++)
			{
				if (players[i] != null)
				{
					//tell the others slot is leaving
					players[i].write("playerleave "+slot);
					//tell slot the others are leaving
					if (slot != (i+1))
					{
						players[slot-1].write("playerleave "+(i+1));
					}
				}
			}
			
			//tell the spectators p is leaving
			specWrite("playerleave "+slot);
				
			players[slot-1] = null;
			
			//if this channel is empty but not persistant, we should remove it
			boolean empty = true;
			for (int i=0;i<players.length;i++)
			{
				if (players[i] != null)
				{
					empty = false;
				}
			}
			if (spectators.size() > 0)
			{
				empty = false;
			}
			if ((empty)&&(!persistant))
			{
				serv.removeChannel(this);
			}
		}
	}
	
	//removes player on slot from this channel
	public synchronized void removePlayer (Player p)
	{
		int slot = getSlot(p);
		removePlayer(slot);
	}
	
	//add a spectator to this channel
	public synchronized void addSpectator (Spectator s)
	{
		//do some access control
		if ((s.getAccess() >= GLOBALOP)||(db.isOperator(s.getNick(),id)))
		{
			Channel ch = s.getChannel();
			if (ch != null)
			{
				ch.removeSpectator(s);
			}
		
			spectators.addElement(s);		
			s.setChannel(this);
			//tell s what channel he has joined
			s.write("speclist "+name);
			//tell who the other spectators are
			if (spectators.size() > 0)
			{
				for (int i=0;i<spectators.size();i++)
				{
					Spectator sp = (Spectator) spectators.elementAt(i);
					s.write("specjoin "+sp.getNick());
					sp.write("specjoin "+s.getNick());
				}
			}
			//now tell who the players are
			for (int i=0;i<players.length;i++)
			{
				if (players[i] != null)
				{
					s.write("playerjoin "+(i+1)+" "+players[i].getNick());
					if (players[i].getTeam() != null)
					{
						s.write("team " + (i+1) + " " + players[i].getTeam());
					}
				}
			}
			
			//tell s in what state this channel is
			if ((game.getStatus() == PLAYING)||(game.getStatus() == PAUSED))
			{
				s.write("ingame");
				if (game.getStatus() == PAUSED)
				{
					s.write("pause 1");
				}
				//send s the others their playField
				for (int i=0;i<players.length;i++)
				{
					if (players[i] != null)
					{
						if (players[i].getStatus() != PLAYING)
						{
							s.write("playerlost "+(i+1));
						}
						else
						{
							s.write(players[i].getPlayField());
						}
					}
				}
			}
			//send winlist of this channel type
			s.write(db.getWinlist(game.getType(),0,10));
		}
		else
		{
			s.write("pline 0 U are not an operator in this channel");
		}		
	}
	
	//remove spectator from this channel
	public synchronized void removeSpectator (Spectator s)
	{
		if (spectators.size() != 0)
		{
			for (int i=0;i<spectators.size();i++)
			{
				//tell s the spectators are leaving
				Spectator sp = (Spectator) spectators.elementAt(i);
				if (sp != s)
				{
					sp.write("specleave "+s.getNick());
					s.write("specleave "+sp.getNick());
				}
				else
				{
					s.write("specleave "+s.getNick());
				}
			}
			spectators.removeElement(s);
			s.setChannel(null);
		}
		
		//now tell s the players are leaving
	 	for (int i=0;i<players.length;i++)
		{
			if (players[i] != null)
			{
				s.write("playerleave "+(i+1));
			}
		}
	}
	
	//write a msg to all spectators
	public void specWrite (String msg)
	{
		if (spectators.size() > 0)
		{
			for (int i=0;i<spectators.size();i++)
			{
				Spectator s = (Spectator) spectators.elementAt(i);
				s.write(msg);
			}
		}
	}
	
	//returns the slot where player is in
	public synchronized int getSlot (Player p)
	{
		for (int i=0;i<players.length;i++)
		{
			if (players[i] == p)
			{
				return (i+1);
			}
		}
		return 0;
	}

	//switches players on slot source and destinations
	public synchronized void movePlayer (int source, int destination)
	{
		if ((game.getStatus() == NOGAME)&&(source != destination))
		{
			if ((source > 0)&&(source <= players.length)&&(destination > 0)&&(destination <= players.length))
			{
				Player p1 = players[source-1];
				Player p2 = players[destination-1];
				boolean wasPersistant = persistant;
				persistant = true;
				removePlayer(source);
				removePlayer(destination);
				if (p1 != null)
				{
					addPlayer(p1,destination);
				}
				if (p2 != null)
				{
					addPlayer(p2,source);
				}
				persistant = wasPersistant;
			}
		}
	}

	//is this channel full?
	public synchronized boolean isFull ()
	{
		for (int i=0;i<players.length;i++)
		{
			if (players[i] == null)
			{
				return false;
			}
		}
		return true;
	}
	
	//returns an empty slot
	public synchronized int getEmptySlot ()
	{
		for (int i=0;i<players.length;i++)
		{
			if (players[i] == null)
			{
				return (i+1);
			}
		}
		return 0;
	}

	//returns id
	public synchronized int getId ()
	{
		return id;
	}

	//write a message to all connected players
	public void write (String msg)
	{
		for (int i=0;i<players.length;i++)
		{
			if (players[i] != null)
			{
				players[i].write(msg);
			}
		}
		specWrite(msg);
	}
	
	//write a message to all connect players, except p
	public void write (String msg,Player p)
	{
		for (int i=0;i<players.length;i++)
		{
			if ((players[i] != null)&&(players[i] != p))
			{
				players[i].write(msg);
			}
		}
		specWrite(msg);
	}		
	
	//returns version
	public synchronized int getVersion ()
	{
		return version;
	}
	
	//sets topic to t
	public synchronized void setTopic (String t)
	{
		topic = t;
	}
	
	//returns topic
	public synchronized String getTopic ()
	{
		return topic;
	}
	
	//sets name to n
	public synchronized void setName (String n)
	{
		if(Utils.isValidName(n))
		{
			name = n;
		}
	}
	
	//returns name
	public synchronized String getName ()
	{
		return name;
	}
	
	//writes a msg to player on slot
	public void write (String msg,int slot)
	{
		if ((slot > 0)&&(slot <= players.length))
		{
			if (players[slot] != null)
			{
				players[slot].write(msg);
			}
		}
	}
	
	//returns the player on slot
	public synchronized Player getPlayer (int slot)
	{
		if ((slot > 0)&&(slot <= players.length))
		{
			return players[slot-1];
		}
		else
		{
			return null;
		}
	}

	//returns the spectator on slot
	public synchronized Spectator getSpectator (int slot)
	{
		if (spectators.size() > 0)
		{
			if ((slot > 0)&&(slot <= spectators.size()))
			{
				return (Spectator) (spectators.elementAt(slot-1));
			}
		}
		return null;
	}
	
	//returns the paxPlayer
	public synchronized int getMaxPlayers ()
	{
		return players.length;
	}
	
	public synchronized String toString()
	{
		StringBuffer strBuf = new StringBuffer();
		strBuf.append(BLUE+name+BLACK+" - "+topic+" ");
		if (game.getStatus() == PLAYING)
		{
			strBuf.append("("+RED+"ingame) ");
		}
		else if (game.getStatus() == PAUSED)
		{
			strBuf.append("("+RED+"paused) ");
		}
		else
		{
			strBuf.append("("+GREEN+"waiting) ");
		}
		strBuf.append(BLACK);

		int cnt = numPlayers();
		if (cnt < players.length)
		{
			strBuf.append("("+GREEN+numPlayers()+BLACK+" of "+RED+players.length+BLACK+") ");
		}
		else
		{
			strBuf.append("("+RED+numPlayers()+BLACK+" of "+RED+players.length+BLACK+") ");
		}
		return strBuf.toString();
	}
	
	//returns the number of players in this channel
	public synchronized int numPlayers ()
	{
		int total = 0;
		for (int i=0;i<players.length;i++)
		{
			if (players[i] != null)
			{
				++total;
			}
		}
		return total;
	}
	
	//returns the number of operators in this channel
	public synchronized int numOperators ()
	{
		int total = 0;
		for (int i=0;i<players.length;i++)
		{
			if (players[i] != null)
			{
				if (players[i].getAccess() >= CHANOP)
				{
					++total;
				}
			}
		}
		return total;
	}
	
	//returns the number of Spectators in this channel
	public synchronized int numSpectators ()
	{	
		return spectators.size();
	}
	
	//returns wether this channel is empty
	public synchronized boolean isEmpty ()
	{
		for (int i=0;i<players.length;i++)
		{
			if (players[i] != null)
			{
				return false;
			}
		}
		if (spectators.size() > 0 )
		{
			return false;
		}
		return true;
	}
	
	public synchronized boolean isOpByPosition (Player p)
	{
		boolean found = false;
		int cnt = 0;
		for (int i=0;((i<players.length)&&(!found));i++)
		{
			if (players[i] != null)
			{
				if (players[i] == p)
				{
					found = true;
				}
				++cnt;
			}
		}
		if ((found)&&(cnt <= 2))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
	
	//returns wether p is the first player in players
	public synchronized boolean isFirstPlayer (Player p)
	{
		for (int i=0;i<players.length;i++)
		{
			if (players[i] != null)
			{
				if (players[i] == p)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		return false;
	}
	
	//writes a msg, actually it's a gameEvent
	public void write (String msg,Player p,int type)
	{
		//someone started/stopped/paused/unpaused
		if (type == 1)
		{
			int status = game.getStatus();
			if ((msg.startsWith("pause 0"))&&(status == PAUSED))
			{
				//unpause
				unpauseGame(p);	
			}

			else if ((msg.startsWith("pause 1"))&&(status == PLAYING))
			{
				//pause
				pauseGame(p);
			}

			else if ((msg.startsWith("startgame 0"))&&((status == PLAYING)||(status == PAUSED)))
			{
				//stop
				stopGame(p);
			}

			else if ((msg.startsWith("startgame 1"))&&(status == NOGAME))
			{
				//start
				startGame(p);
			}
		}
		
		//someone died	
		else if (type == 2)
		{
			checkGame(p);
		}
		
		//another game event happened
		else if (type == 3)
		{
			write(msg,p);
			doGame(p,msg);
		}
	}
	
	//pause the game
	public synchronized void pauseGame (Player p)
	{
		write("pause 1");
		game.setStatus(PAUSED);
		long playTime = game.getStartTime();
		game.setStartTime(System.currentTimeMillis() - playTime);
		write("pline 0 Player "+BLUE+p.getNick()+BLACK+" has "+RED+"paused "+BLACK+"the game");
	}
	
	//unpause the game
	public synchronized void unpauseGame (Player p)
	{
		write("pause 0");
		game.setStatus(PLAYING);
		long playTime = game.getStartTime();
		game.setStartTime(System.currentTimeMillis() - playTime);
		write("pline 0 Player "+BLUE+p.getNick()+BLACK+" has "+RED+"unpaused "+BLACK+"the game");	
	}
	
	//stop the game
	public synchronized void stopGame (Player p)
	{		
		sudden.setRunning(false);
		sudden.setChannel(null);	
		write("endgame");
		game.setStatus(NOGAME);
		for (int i=0;i<players.length;i++)
		{
			if (players[i] != null)
			{
				players[i].setStatus(NOGAME);
			}
		}
	}
	
	//start the game
	public synchronized void startGame (Player p)
	{
		int cntPlayer = 0;
		int cntUnique = 0;
		String name = p.getTeam();
		int slot = getSlot(p);

		write("pline 0 Player "+BLUE+p.getNick()+BLACK+" has "+RED+"started "+BLACK+"the game");
			
		for (int i=0;i<players.length;i++)
		{
			if (players[i] != null)
			{
				if(!players[i].getTeam().equals(name))
				{
					++cntUnique;
				}
				if((players[i].getTeam() != null)&&(players[i].getTeam().equals(""))&&((i+1) != slot))
				{
					++cntUnique;
				}
				cntPlayer++;
			}
		}
		if (((cntUnique >= 1)&&(cntPlayer > 1))||(cntPlayer == 1))
		{
			//do a little countdown
			for (int t=0;t<3;t++)
			{
				try
				{
					write("pline 0 "+(3-t));
					Thread.sleep(900);
				}
				catch (InterruptedException ie) { }
			}
			
			//specWrite(game.toString(TETRINET));
			game.setStartTime(System.currentTimeMillis());
			game.setStatus(PLAYING);
			
			for (int i=0;i<players.length;i++)
			{
				if (players[i] != null)
				{
					players[i].setStatus(PLAYING);
					players[i].clearPlayField();
					players[i].setBlocksDropped(0);
					players[i].setAddedToAll(0);
					players[i].setTetrisMade(0);
					players[i].setLevel(game.getStartingLevel());
					players[i].write(game.toString(players[i].getVersion()));
				}
			}
			
			//start a suddendeath tester
			sudden = new SuddenTester(this);
			
			//tell the spectators the game has begon
			specWrite(game.toString(TETRINET));
			
			if (cntPlayer > 4)
			{
				game.setPoints1(3);
				game.setPoints2(1);
			}
			else if (cntPlayer > 1)
			{
				game.setPoints1(1);
				game.setPoints2(0);
			}
			else 
			{
				game.setPoints1(0);
				game.setPoints2(0);
			}
		}
		else
		{
			p.write("pline 0 "+RED+"Game could not be started");
		}
	}
	
	//check if there is still a game going on
	public synchronized void checkGame (Player p)
	{
		//tell everybody p has lost
		write("playerlost "+getSlot(p));
		if (p.getStatus() == PLAYING)
		{
			//do some stats perparations
			p.setStatus(DEAD);
			p.setPlayTime(System.currentTimeMillis() - game.getStartTime());
			//find out if we got a winner
			int alive = 0;
			String name = null;
			Player pAlive = null;
			for (int i=0;i<players.length;i++)
			{
				if ((players[i] != null)&&(players[i].getStatus() == Player.PLAYING))
				{	
					if (name == null)
					{
						if (!players[i].getTeam().equals(""))
						{
							name = players[i].getTeam();
							alive++;
						}
						else
						{
							alive++;
						}
					}
					else
					{
						if (!players[i].getTeam().equals(name))
						{
							alive++;
						}
					}
					pAlive = players[i];
				}
			}
			//so we have got a winner
			if (alive <= 1)
			{
				//tell everybody the game has ended
				write("endgame");
				for (int i=0;i<players.length;i++)
				{
					if ((players[i] != null)&&(players[i].getStatus() == Player.PLAYING))
					{
						players[i].setPlayTime(System.currentTimeMillis() - game.getStartTime());
						players[i].setStatus(Player.DEAD);
					}
				}
		
				if (pAlive == null)
				{
					write("pline 0 Single Player Game has been "+RED+"ended");
					doStats();
				}
				else
				{
					write("playerwon "+getSlot(pAlive));
					if (name != null)
					{
						write("pline 0 Team "+BLUE+pAlive.getTeam()+BLACK+" has "+RED+"won "+BLACK+"the game");
					}
					else
					{
						write("pline 0 Player "+BLUE+pAlive.getNick()+BLACK+" has "+RED+"won "+BLACK+"the game");
					}
					doStats();
				}
				
				//update the winlist
				if ((pAlive != null)&&(game.getPoints1() > 0))
				{
					if ((!pAlive.getTeam().equals(""))&&(pAlive.getTeam() != null))
					{
						write(db.addPoints(pAlive.getTeam(),'t',game.getPoints1(),game.getType()));
					}
					else
					{
						write(db.addPoints(pAlive.getNick(),'p',game.getPoints1(),game.getType()));
					}					
				}
				if ((p != null)&&(game.getPoints2() > 0))
				{
					if ((!p.getTeam().equals(""))&&(p.getTeam() != null))
					{
						write(db.addPoints(p.getTeam(),'t',game.getPoints2(),game.getType()));
					}
					else
					{
						write(db.addPoints(p.getNick(),'p',game.getPoints2(),game.getType()));
					}
				}
			  serv.sendWinlist(game.getType());
			  
			  //update the players status
				for (int i=0;i<players.length;i++)
				{
					if (players[i] != null)
					{
						players[i].setStatus(NOGAME);
					}
				}
				//update the channel status
				game.setStatus(NOGAME); 
			}
		}
	}
	
	//handler for game events
	public synchronized void doGame (Player p, String msg)
	{
	}
	
	//do the stats of this game
	public synchronized void doStats ()
	{
		for (int i=0;i<players.length;i++)
		{
			if ((players[i] != null)&&(players[i].getStatus() == DEAD))
			{
				write("pline 0 Player "+players[i].getStats());
			}
		}
	}
	
	//returns status
	public synchronized int getStatus ()
	{
		return game.getStatus();
	}
	
	//returns the gameType
	public synchronized int getGameType ()
	{
		return game.getType();
	}
	
	//returns the game
	public synchronized Game getGame ()
	{
		return game;
	}
	
	//returns the startTime of the game
	public synchronized double getStartTime ()
	{
		return game.getStartTime();
	}
	
	//returns the server
	public synchronized TetriServer getServer ()
	{
		return serv;
	}
	
}


	
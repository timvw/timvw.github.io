import java.text.DecimalFormat;
import java.util.Vector;

public class ChannelRacer extends Channel
{
	private int blocks;
	
	public ChannelRacer (MySQL m,TetriServer s,int maxPlayers,int id,int type,int misc[],int blocks[],int specials[],String name,String topic)
	{
		db = m;
		serv = s;
		players = new Player[1];
		spectators = new Vector();
		if (type < CLASSICFAST)
		{
			version = TETRINET;
		}
		else
		{
			version = TETRIFAST;
		}
		game = new Game(type,misc,blocks,specials);
		this.name = name;
		this.topic = topic;
		persistant = true;
		this.id = id;
	}
	
	public synchronized void startGame (Player p)
	{		
		//start from 0
		blocks = 0;
		
		//do a little countdown
		for (int t=0;t<3;t++)
		{
			try
			{
				write("pline 0 "+(3-t));
				Thread.sleep(900);
			}
			catch (InterruptedException ie) { }
		}
		
		game.setStatus(PLAYING);
		game.setStartTime(System.currentTimeMillis());
		p.setStatus(PLAYING);
		p.setBlocksDropped(0);
		p.clearPlayField();
		p.setLevel(game.getStartingLevel());
		p.setAddedToAll(0);
		p.setTetrisMade(0);
		p.write(game.toString(p.getVersion()));
		sudden = new SuddenTester(this);
	}
	
	public synchronized void checkGame (Player p)
	{
		p.write("playerlost "+getSlot(p));
		if (p.getStatus() == PLAYING)
		{
			sudden.setRunning(false);
			sudden.setChannel(null);
			p.setStatus(DEAD);
			p.setPlayTime(System.currentTimeMillis() - game.getStartTime());
			p.write("endgame");
			p.write("pline 0 Single Player Game has been "+RED+"ended");
			doStats();
			p.setStatus(NOGAME);
			game.setStatus(NOGAME);
		}
	}
	
	public synchronized void doGame (Player p,String event)
	{
		if (p.getBlocksDropped() != blocks)
		{
			blocks = p.getBlocksDropped();
		}
		
		if (blocks >= 200)
		{
			if (game.getStatus() == PLAYING)
			{
				stopGame(p);
				double playTime = System.currentTimeMillis() - game.getStartTime();
				p.setPlayTime(playTime);
				DecimalFormat digits3 = new DecimalFormat("0.000");				
				write("pline 0 Player "+BLUE+p.getNick()+BLACK+" did the job in "+RED+digits3.format(playTime/1000.00)+BLACK+" seconds");
				write("pline 0 "+p.getStats());
				if (p != null)
				{
					write(db.setTime(p.getNick(),playTime,game.getType()));
					//winlist changed, all channels with same winlist should inform their clients
					serv.sendWinlist(game.getType());
				}
			}
		}
	}
	
}

		
	
import java.io.*;
import java.net.*;
import java.util.*;

public class TetriServer extends Thread implements Constants
{
	static TetriServer single = null;
	
	protected MySQL db;
	protected ServerSocket se;
	protected Vector channels;
	protected Vector players;
	protected Vector spectators;
	
	//constructor
	private TetriServer () throws Exception
	{
		se = new ServerSocket(TETRINETPORT);
		channels = new Vector();
		players = new Vector();
		spectators = new Vector();
		db = MySQL.giveMySQL();;
		db.loadChannels(this);
		start();
	}
	
	public static TetriServer giveTetriServer () throws Exception
	{
		if (single == null)
		{
			single = new TetriServer();
		}
		return single;
	}
	
	//main loop
	public void run ()
	{
		while (true)
		{
			try
			{
				Player p = new Player(se.accept(),db,this);
			}
			catch (Exception e)
			{
				System.out.println(e.toString());
			}
		}
	}

	//add a channel to channels
	public synchronized void addChannel (Channel ch)
	{
		//has ch a unique name?
		boolean exists = false;
		if (channels.size() > 0)
		{
			for (int i=0;((i<channels.size())&&(!exists));i++)
			{
				Channel c = (Channel) channels.elementAt(i);
				if (c.getName().equalsIgnoreCase(ch.getName()))
				{
					exists = true;
				}
			}
		}
		//as longs as ch hasn't got a unique name, change ch's name
		while (exists)
		{
			ch.setName(ch.getName()+"-");
			exists = false;
			if (channels.size() > 0)
			{
				for (int i=0;((i<channels.size())&&(!exists));i++)
				{
					Channel c = (Channel) channels.elementAt(i);
					if (c.getName().equalsIgnoreCase(ch.getName()))
					{
						exists = true;
					}
				}
			}
		}
		//now ch has a unique name
		channels.addElement(ch);
	}
	
	//remove a channel from channels
	public synchronized void removeChannel (Channel ch)
	{
		channels.removeElement(ch);
	}
	
	//returns a list of channels
	public synchronized String[] listChannels ()
	{
		String list[] = new String[channels.size()+2];
		list[0] = "pline 0 Channels List (Type /join #channel)";
		if (channels.size() > 0)
		{
			for (int i=0;i<channels.size();i++)
			{
				Channel c = (Channel) channels.elementAt(i);
				StringBuffer buf = new StringBuffer();
				buf.append("pline 0 ("+(i+1)+") ");
				buf.append(c.toString());
				list[i+1] = buf.toString();
			}
		}
		list[list.length-1] = "pline 0 End of Channels List";
		return list;
	}
		
	//gives an overview of the connected players
	public synchronized String[] listPlayers (int access)
	{
		StringBuffer str = new StringBuffer();
		str.append("pline 0 Players List \n");
		
		if (channels.size() > 0)
		{
			for (int i=0;i<channels.size();i++)
			{
				Channel chan = (Channel) channels.elementAt(i);
				if (!chan.isEmpty())
				{
					str.append("pline 0 ");
					if (!chan.isFull())
					{
						str.append("["+GREEN+chan.getName()+"]  \n");
					}
					else
					{
						str.append("["+RED+chan.getName()+"] \n");
					}
				
					for (int j=0;j<chan.getMaxPlayers();j++)
					{
						Player pl = chan.getPlayer(j+1);
						if (pl != null)
						{
							str.append("pline 0 ("+(i+1)+(j+1)+") "+pl.toString(access)+"\n");
						}
					}
					str.append("\n");
				}
			}
		}
		str.append("pline 0 End of Players List");
		StringTokenizer tokens = new StringTokenizer(str.toString(),"\n");
		int cntTokens = tokens.countTokens();	
		String list[] = new String[cntTokens];
		for (int i=0;i<cntTokens;i++)
		{
			list[i] = tokens.nextToken();
		}
		return list;
	}

	//gives an overview of the connected spectators
	public synchronized String[] listSpectators (int access)
	{
		StringBuffer str = new StringBuffer();
		str.append("pline 0 Spectators List \n");
		
		if (channels.size() > 0)
		{
			for (int i=0;i<channels.size();i++)
			{
				Channel chan = (Channel) channels.elementAt(i);
				if (chan.numSpectators() > 0)
				{
					str.append("pline 0 ");
					if (!chan.isFull())
					{
						str.append("["+GREEN+chan.getName()+"]  \n");
					}
					else
					{
						str.append("["+RED+chan.getName()+"] \n");
					}
				
					for (int j=0;j<chan.numSpectators();j++)
					{
						Spectator s = chan.getSpectator(j+1);
						if (s != null)
						{
							str.append("pline 0 ("+(i+1)+(j+1)+") "+s.toString(access)+"\n");
						}
					}
					str.append("\n");
				}
			}
		}
		str.append("pline 0 End of Spectators List");
		StringTokenizer tokens = new StringTokenizer(str.toString(),"\n");
		int cntTokens = tokens.countTokens();	
		String list[] = new String[cntTokens];
		for (int i=0;i<cntTokens;i++)
		{
			list[i] = tokens.nextToken();
		}
		return list;
	}

	//gives an overview of the connected operators
	public synchronized String[] listOperators (int access)
	{
		StringBuffer str = new StringBuffer();
		str.append("pline 0 Operators List \n");
		
		if (channels.size() > 0)
		{
			for (int i=0;i<channels.size();i++)
			{
				Channel chan = (Channel) channels.elementAt(i);
				if ((!chan.isEmpty())&&(chan.numOperators() > 0))
				{
					str.append("pline 0 ");
					if (!chan.isFull())
					{
						str.append("["+GREEN+chan.getName()+"]  \n");
					}
					else
					{
						str.append("["+RED+chan.getName()+"] \n");
					}
				
					for (int j=0;j<chan.getMaxPlayers();j++)
					{
						Player pl = chan.getPlayer(j+1);
						if (pl != null)
						{
							if (pl.getAccess() >= CHANOP)
							{
								str.append("pline 0 ("+(i+1)+(j+1)+") "+pl.toString(access)+"\n");
							}
						}
					}
					str.append("\n");
				}
			}
		}
		str.append("pline 0 End of Operators List");
		StringTokenizer tokens = new StringTokenizer(str.toString(),"\n");
		int cntTokens = tokens.countTokens();	
		String list[] = new String[cntTokens];
		for (int i=0;i<cntTokens;i++)
		{
			list[i] = tokens.nextToken();
		}
		return list;
	}
	
	//add player to channel with name
	public synchronized void addToChannel (Player p, String name)
	{
		if (channels.size() > 0)
		{
			boolean found = false;
			for (int i=0;((i<channels.size())&&(!found));i++)
			{
				Channel ch = (Channel) channels.elementAt(i);
				if (ch.getName().equalsIgnoreCase(name))
				{
					ch.addPlayer(p);
					found = true;
				}
			}
			if (!found)
			{
				p.write("pline 0 Channel does not exist");
			}		
		}
		else
		{
			p.write("pline 0 Channel does not exist");
		}
	}

	//add spectator to channel with name
	public synchronized void addToChannel (Spectator s, String name)
	{
		if (channels.size() > 0)
		{
			boolean found = false;
			for (int i=0;((i<channels.size())&&(!found));i++)
			{
				Channel ch = (Channel) channels.elementAt(i);
				if (ch.getName().equalsIgnoreCase(name))
				{
					ch.addSpectator(s);
					found = true;
				}
			}
			if (!found)
			{
				s.write("pline 0 Channel does not exist");
			}		
		}
		else
		{
			s.write("pline 0 Channel does not exist");
		}
	}
	
	//add p to c
	public synchronized void addToChannel (Player p, int chanNum)
	{
		if ((chanNum > 0)&&(chanNum <= channels.size()))
		{
			Channel ch = (Channel) channels.elementAt(chanNum-1);
			ch.addPlayer(p);
		}
		else
		{
			p.write("pline 0 Channel does not exist");
		}
	}
	
	//add s to c
	public synchronized void addToChannel (Spectator s, int chanNum)
	{
		if ((chanNum > 0)&&(chanNum <= channels.size()))
		{
			Channel ch = (Channel) channels.elementAt(chanNum-1);
			ch.addSpectator(s);
		}
		else
		{
			s.write("pline 0 Channel does not exist");
		}
	}
	
	//add a player to a channel
	public synchronized void addToChannel (Player p)
	{
		boolean found = false;
		if (channels.size() > 0)
		{
			for (int i=0;((i<channels.size())&&(!found));i++)
			{
				Channel ch = (Channel) channels.elementAt(i);
				int version = ch.getVersion();
				int slot = ch.getEmptySlot();
				boolean banned = true;
				if ((!db.isBanned(p.getHostName(),ch.getId()))&&(!db.isBanned(p.getHostAddress(),ch.getId())))
				{
					banned = false;
				}
				if ((slot != 0)&&(p.getVersion() <= version)&&(!banned))
				{
					ch.addPlayer(p);
					found = true;
				}
			}
		}
		if (!found)
		{
			Channel ch = new Channel(db,this,p.getVersion());
			addChannel(ch);
			ch.addPlayer(p);
		}
	}

	//add a spectator to a channel
	/*
	public synchronized void addToChannel (Spectator s)
	{
		if (channels.size() > 0)
		{
			Channel ch = (Channel) channels.elementAt(0);
			ch.addSpectator(s);
		}
		else
		{
			Channel ch = new Channel(db,this,TETRINET);
			addChannel(ch);
			ch.addSpectator(s);
		}
	}
	*/
	
	//adds a player to players
	public synchronized void addPlayer (Player p)
	{
		boolean found = false;
		if (players.size() > 0)
		{
			for (int i=0;((i<players.size())&&(!found));i++)
			{
				Player pl = (Player) players.elementAt(i);
				if (pl.getNick().equalsIgnoreCase(p.getNick()))
				{
					found = true;
				}
			}
		}
		if (spectators.size() > 0)
		{
			for (int i=0;((i<spectators.size())&&(!found));i++)
			{
				Spectator sl = (Spectator) spectators.elementAt(i);
				if (sl.getNick().equalsIgnoreCase(p.getNick()))
				{
					found = true;
				}
			}
		}		
		if (!found)
		{
			players.addElement(p);
		}
		else
		{			
			p.write("noconnecting this nick already exists on server");
			p.disconnect("Nick already exists on server");
		}
	}
	
	//adds s to spectators
	public synchronized void addSpectator (Spectator s)
	{
		boolean found = false;
		if (players.size() > 0)
		{
			for (int i=0;((i<players.size())&&(!found));i++)
			{
				Player pl = (Player) players.elementAt(i);
				if (pl.getNick().equalsIgnoreCase(s.getNick()))
				{
					found = true;
				}
			}
		}
		if (spectators.size() > 0)
		{
			for (int i=0;((i<spectators.size())&&(!found));i++)
			{
				Spectator sl = (Spectator) spectators.elementAt(i);
				if (sl.getNick().equalsIgnoreCase(s.getNick()))
				{
					found = true;
				}
			}
		}
		
		if (!found)
		{
			spectators.addElement(s);
		}
		else
		{			
			s.write("noconnecting this nick already exists on server");
			s.disconnect("Nick already exists on server");
		}
	}
	
	//removes p from players
	public synchronized void removePlayer (Player p)
	{
		players.removeElement(p);
	}
	
	//removes s from spectators
	public synchronized void removeSpectator (Spectator s)
	{
		spectators.removeElement(s);
	}
	
	//returns player with playernum
	public synchronized Player getPlayer (int playerNum)
	{
		int chan = playerNum / 10;
		int slot = playerNum % 10;
		if ((chan > 0)&&(chan <= channels.size()))
		{
			Channel ch = (Channel) channels.elementAt(chan);
			return ch.getPlayer(slot);
		}
		else
		{
			return null;
		}
	}
	
	//broadcast a message to all players
	public synchronized void broadcast (String msg)
	{
		if (players.size() > 0)
		{
			for (int i=0;i<players.size();i++)
			{
				Player p = (Player) players.elementAt(i);
				p.write("pline 0 "+RED+"Server Broadcast Message: "+BLACK+msg);
			}
		}
		if (spectators.size() > 0)
		{
			for (int i=0;i<spectators.size();i++)
			{
				Spectator s = (Spectator) spectators.elementAt(i);
				s.write("pline 0 "+RED+"Server Broadcast Message: "+BLACK+msg);
			}
		}
	}
	
	//send to all channels with gameType the winlist
	public synchronized void sendWinlist (int gameType)
	{
		String winlist = db.getWinlist(gameType,0,10);
		if ((winlist != null)&&(channels.size() > 0))
		{
			for (int i=0;i<channels.size();i++)
			{
				Channel ch = (Channel) channels.elementAt(i);
				if (ch.getGameType() == gameType)
				{
					ch.write(winlist);
				}
			}
		}
	}
	
	//returns our MySQL connection
	public synchronized MySQL getMySQL ()
	{
		return db;
	}
	
	//write <msg> to <nick>
	public synchronized String write (String sender,String nick,String msg)
	{
		String tmp = "pline 0 Sending msg to "+BLUE+nick+RED+" failed";
		boolean found = false;
		if (players.size() > 0)
		{
			for (int i=0;((i<players.size())&&(!found));i++)
			{
				Player p = (Player) players.elementAt(i);
				if (p.getNick().equalsIgnoreCase(nick))
				{
					found = true;
					tmp = "pline 0 Sending msg to "+BLUE+nick+GREEN+" succeeded";
					p.write("pline 0 MSG from "+BLUE+sender+BLACK+" : "+msg);
				}
			}
		}
		return tmp;
	}
	
	//write <msg> to operators
	public synchronized String owrite(String sender,String msg)
	{
		int cnt = 0;
		if (players.size() > 0)
		{
			for (int i=0;i<players.size();i++)
			{
				Player p = (Player) players.elementAt(i);
				if (p.getAccess() >= CHANOP)
				{
					p.write("pline 0 OMSG from "+BLUE+sender+BLACK+" : "+msg);
					++cnt;
				}
			}
		}
		if (spectators.size() > 0)
		{
			for (int i=0;i<spectators.size();i++)
			{
				Spectator s = (Spectator) spectators.elementAt(i);
				s.write("pline 0 OMSG from "+BLUE+sender+BLACK+" : "+msg);
				++cnt;
			}
		}
		return "pline 0 Send <msg> succesfully to "+RED+cnt+BLACK+" operators";
	}
	
}
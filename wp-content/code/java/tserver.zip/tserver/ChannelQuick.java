import java.text.DecimalFormat;
import java.util.Vector;

class TimeTester extends Thread implements Constants
{
	private TetriServer serv;
	private MySQL db;
	private Channel chan;
	private Game game;
	private boolean running;
	
	//constructor
	public TimeTester (Channel ch)
	{
		chan = ch;
		game = chan.getGame();
		serv = chan.getServer();
		db = serv.getMySQL();
		running = true;
		start();
	}
			
	//main loop		
	public void run ()
	{		
		while (running)
		{
			try
			{
				double initialStartTime = game.getStartTime();
				
				//sleep until only 90seconds are left
				sleep(TIME_QUICK-90000);
				double dif = 5000;
				if (game.getStatus() == PLAYING)
				{
					dif = game.getStartTime() - initialStartTime;
				}
				while ((dif > 0)||(game.getStatus() == PAUSED))
				{
					sleep((int)dif);
					initialStartTime += dif;
					dif = 5000;
					if (game.getStatus() == PLAYING)
					{
						dif = game.getStartTime() - initialStartTime;
					}
				}
				chan.write("gmsg * 90 seconds left");
				
				//sleep until only 60 seconds are left
				sleep(30000);
				if (game.getStatus() == PLAYING)
				{
					dif = game.getStartTime() - initialStartTime;
				}
				while ((dif > 0)||(game.getStatus() == PAUSED))
				{
					sleep((int)dif);
					initialStartTime += dif;
					dif = 5000;
					if (game.getStatus() == PLAYING)
					{
						dif = game.getStartTime() - initialStartTime;
					}
				}
				chan.write("gmsg * 60 seconds left");
				
				//sleep until only 30 seconds are left
				sleep(30000);
				if (game.getStatus() == PLAYING)
				{
					dif = game.getStartTime() - initialStartTime;
				}
				while ((dif > 0)||(game.getStatus() == PAUSED))
				{
					sleep((int)dif);
					initialStartTime += dif;
					dif = 5000;
					if (game.getStatus() == PLAYING)
					{
						dif = game.getStartTime() - initialStartTime;
					}
				}
				chan.write("gmsg * 30 seconds left");
				
				//sleep until only 10 seconds are left
				sleep(20000);
				if (game.getStatus() == PLAYING)
				{
					dif = game.getStartTime() - initialStartTime;
				}
				while ((dif > 0)||(game.getStatus() == PAUSED))
				{
					sleep((int)dif);
					initialStartTime += dif;
					dif = 5000;
					if (game.getStatus() == PLAYING)
					{
						dif = game.getStartTime() - initialStartTime;
					}
				}
				chan.write("gmsg * 10 seconds left");
				
				
				//sleep until only 0 seconds are left
				sleep(10000);
				if (game.getStatus() == PLAYING)
				{
					dif = game.getStartTime() - initialStartTime;
				}
				while ((dif > 0)||(game.getStatus() == PAUSED))
				{
					sleep((int)dif);
					initialStartTime += dif;
					dif = 5000;
					if (game.getStatus() == PLAYING)
					{
						dif = game.getStartTime() - initialStartTime;
					}
				}
				
				chan.write("gmsg * Game Over");
				if (game.getStatus() == PLAYING)
				{
					Player p = chan.getPlayer(1);
					Channel ch = chan;
					chan.stopGame(p);
					chan = ch;
					double playTime = System.currentTimeMillis() - game.getStartTime();
					p.setPlayTime(playTime);
					int addToAll = p.getAddedToAll();
					chan.write("pline 0 Player "+BLUE+p.getNick()+BLACK+" added "+RED+addToAll+BLACK+" lines");
					chan.write("pline 0 "+p.getStats());
					if (p != null)
					{
						chan.write(db.setScore(p.getNick(),addToAll,game.getType()));
						//winlist changed, all channels with same winlist should inform their clients
						serv.sendWinlist(game.getType());
					}
					chan = null;
				}
				running = false;
			}
			catch (Exception e)
			{
				running = false;
				chan = null;
			}
		}
		chan = null;
		game = null;
		running = false;
	}
	
	//set chan to ch
	public void setChannel (Channel ch)
	{
		chan = ch;
	}
	
	//set game to g
	public void setGame (Game g)
	{
		game = g;
	}
	
	//set running to r
	public void setRunning (boolean r)
	{
		running = r;
	}
	
	//returns wether running
	public boolean isRunning ()
	{
		return running;
	}
}


public class ChannelQuick extends Channel
{
	private int addedToAll;
	private TimeTester time;
	
	public ChannelQuick (MySQL m,TetriServer s,int maxPlayers,int id,int type,int misc[],int blocks[],int specials[],String name,String topic)
	{
		db = m;
		serv = s;
		players = new Player[1];
		spectators = new Vector();
		if (type < CLASSICFAST)
		{
			version = TETRINET;
		}
		else
		{
			version = TETRIFAST;
		}
		game = new Game(type,misc,blocks,specials);
		this.name = name;
		this.topic = topic;
		persistant = true;
		this.id = id;
	}
	
	public synchronized void startGame (Player p)
	{		
		//start from 0
		addedToAll = 0;
		
		//do a little countdown
		for (int t=0;t<3;t++)
		{
			try
			{
				write("pline 0 "+(3-t));
				Thread.sleep(900);
			}
			catch (InterruptedException ie) { }
		}
		
		game.setStatus(PLAYING);
		game.setStartTime(System.currentTimeMillis());
		p.setStatus(PLAYING);
		p.setBlocksDropped(0);
		p.clearPlayField();
		p.setLevel(game.getStartingLevel());
		p.setAddedToAll(0);
		p.setTetrisMade(0);
		p.write(game.toString(p.getVersion()));
		sudden = new SuddenTester(this);
		time = new TimeTester(this);
	}
	
	//stop the game
	public synchronized void stopGame (Player p)
	{		
		sudden.setRunning(false);
		sudden.setChannel(null);
		time.setRunning(false);
		time.setChannel(null);	
		write("endgame");
		game.setStatus(NOGAME);
		for (int i=0;i<players.length;i++)
		{
			if (players[i] != null)
			{
				players[i].setStatus(NOGAME);
			}
		}
	}	
	
	public synchronized void checkGame (Player p)
	{
		p.write("playerlost "+getSlot(p));
		if (p.getStatus() == PLAYING)
		{
			sudden.setRunning(false);
			sudden.setChannel(null);
			time.setRunning(false);
			time.setChannel(null);
			p.setStatus(DEAD);
			p.setPlayTime(System.currentTimeMillis() - game.getStartTime());
			p.write("endgame");
			p.write("pline 0 Single Player Game has been "+RED+"ended");
			doStats();
			p.setStatus(NOGAME);
			game.setStatus(NOGAME);
		}
	}
	
	public synchronized void doGame (Player p,String event)
	{
		if (game.getStatus() == PLAYING)
		{
			if (p.getAddedToAll() > addedToAll)
			{
				addedToAll = p.getAddedToAll();
				double playTime = System.currentTimeMillis() - game.getStartTime();
				DecimalFormat digits3 = new DecimalFormat("0.000");				
				write("gmsg * Scored "+addedToAll+" after "+digits3.format(playTime/1000.00)+" seconds");
			}
		}
	}
	
}

		
	
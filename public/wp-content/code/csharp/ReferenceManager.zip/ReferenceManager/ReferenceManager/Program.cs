using System.Collections.Generic;
using System.Reflection;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.VersionControl.Client;
using System.IO;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System;

namespace Be.TimVW.Tools
{
    class Program
    {
        static void Main()
        {
            string tfsServerName = "buildprd01";
            string projectsPath = @"D:\Projects\Fluxys\Ulmo";

            Console.WriteLine( "Connecting to TFS [" + tfsServerName + "]..." );
            TeamFoundationServer teamFoundationServer = TeamFoundationServerFactory.GetServer( tfsServerName );

            Console.WriteLine( Environment.NewLine + "Modified ProjectFiles:" );
            List<Workspace> workSpacesWithUpdatedProjectFiles = UpdateReferencesInProjectFiles( teamFoundationServer, projectsPath );

            Console.WriteLine( Environment.NewLine + "Modified Workspaces: " );
            foreach( Workspace workSpace in workSpacesWithUpdatedProjectFiles )
            {
                Console.WriteLine( workSpace.Name );
            }

            //int workItemId = -1;
            //CheckInPendingChanges( teamFoundationServer, workItemId, workSpacesWithUpdatedProjectFiles );

            Console.Write( "{0}Press any key to continue...", Environment.NewLine );
            Console.ReadKey();
        }

        private static List<Workspace> UpdateReferencesInProjectFiles( TeamFoundationServer teamFoundationServer, string projectsPath )
        {
            VersionControlServer versionControlServer = (VersionControlServer) teamFoundationServer.GetService( typeof( VersionControlServer ) );

            List<Workspace> workSpacesWithUpdatedProjectFiles = new List<Workspace>();
            foreach( string projectFileName in ProjectFile.Find( projectsPath ) )
            {
                Workspace workSpace = versionControlServer.GetWorkspace( Path.GetFullPath( projectFileName ) );
                workSpace.PendEdit( projectFileName );

                if( UpdateReferencesInProjectFile( projectFileName ) )
                {
                    Console.WriteLine( projectFileName );
                    if( !workSpacesWithUpdatedProjectFiles.Contains( workSpace ) )
                    {
                        workSpacesWithUpdatedProjectFiles.Add( workSpace );
                    }
                }
                else
                {
                    workSpace.Undo( projectFileName );
                }
            }
            return workSpacesWithUpdatedProjectFiles;
        }

        private static bool UpdateReferencesInProjectFile( string projectFileName )
        {
            bool updated = false;
            ProjectFile projectFile = new ProjectFile( projectFileName );
            foreach( AssemblyReference assemblyReference in projectFile.AssemblyReferences )
            {
                string referencePathToMatch = @"\\central.fluxys.int\DFS\BuildOutput\Framework\2.2\".ToLower();
                if( assemblyReference.HintPath.ToLower().StartsWith( referencePathToMatch ) )
                {
                    string newHintPath = assemblyReference.HintPath.Replace( @"\2.2\", @"\2.3\" );
                    assemblyReference.HintPath = newHintPath;

                    AssemblyName assemblyName = AssemblyName.GetAssemblyName( assemblyReference.HintPath );
                    assemblyReference.AssemblyName = assemblyName.FullName + ", processorArchitecture=" + assemblyName.ProcessorArchitecture;

                    updated = true;
                }
            }

            if( updated )
            {
                projectFile.Save();
            }

            return updated;
        }

        private static void CheckInPendingChanges( TeamFoundationServer teamFoundationServer, int workItemId, List<Workspace> workSpacesWithUpdatedProjectFiles )
        {
            WorkItemStore workItemStore = (WorkItemStore) teamFoundationServer.GetService( typeof( WorkItemStore ) );

            WorkItem workItem = workItemStore.GetWorkItem( workItemId );
            WorkItemCheckinInfo[] workItemChanges = new WorkItemCheckinInfo[] { new WorkItemCheckinInfo( workItem, WorkItemCheckinAction.Associate ) };
            foreach( Workspace workSpace in workSpacesWithUpdatedProjectFiles )
            {
                PendingChange[] pendingChanges = workSpace.GetPendingChanges();
                workSpace.CheckIn( pendingChanges, string.Empty, null, workItemChanges, null );
            }
        }
    }
}

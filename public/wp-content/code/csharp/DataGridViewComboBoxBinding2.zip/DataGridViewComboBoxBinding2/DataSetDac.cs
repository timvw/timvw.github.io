using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace DataGridViewComboBoxBinding
{
    public static class DataSetDac
    {
        public static PersonsDataSet Find()
        {
            PersonsDataSet personsDataSet = new PersonsDataSet();

            personsDataSet.PersonType.Rows.Add(new object[] { 0, "A geeky person" });
            personsDataSet.PersonType.Rows.Add(new object[] { 1, "A coward" });
            personsDataSet.PersonType.Rows.Add(new object[] { 2, "Feeling hot hot hot" });
            personsDataSet.PersonType.Rows.Add(new object[] { -1, "(None)" });

            personsDataSet.Person.Rows.Add(new object[] { "Timvw", 0 });
            personsDataSet.Person.Rows.Add(new object[] { "John Doe", 1 });
            personsDataSet.Person.Rows.Add(new object[] { "An Onymous", 1 });
            personsDataSet.Person.Rows.Add(new object[] { "Jenna Jameson", 2 });
            personsDataSet.Person.Rows.Add(new object[] { "Null Able", -1 });

            return personsDataSet;
        }

        public static PersonsDataSet.PersonTypeDataTable FindPersonTypes(PersonsDataSet.PersonRow person)
        {
            // by default, all persons simply have one of the available persontypecodes
            PersonsDataSet personsDataSet = Find();

            if (person.PersonTypeId.Equals(0))
            {
                // geeks are doomed to stay geeks
                personsDataSet.PersonType.Rows.RemoveAt(2);
                personsDataSet.PersonType.Rows.RemoveAt(1);
            }

            return personsDataSet.PersonType;
        }
    }
}

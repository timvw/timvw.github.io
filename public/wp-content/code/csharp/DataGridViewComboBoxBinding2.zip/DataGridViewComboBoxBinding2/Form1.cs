using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DataGridViewComboBoxBinding
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            PersonsDataSet personsDataSet = DataSetDac.Find();

            this.dataGridView1.AutoGenerateColumns = false;
            this.ColumnName.DataPropertyName = "Name";
            this.ColumnPersonTypeCode.DataPropertyName = "PersonTypeId";
            this.ColumnPersonTypeCode.DisplayMember = "Label";
            this.ColumnPersonTypeCode.ValueMember = "Id";
            this.ColumnPersonTypeCode.DataSource = personsDataSet.PersonType;

            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = personsDataSet.Person;
            this.dataGridView1.DataSource = bindingSource;
        }

        void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (this.dataGridView1.CurrentCell.ColumnIndex == this.ColumnPersonTypeCode.Index)
            {
                BindingSource bindingSource = (BindingSource)this.dataGridView1.DataSource;
                PersonsDataSet.PersonRow person = (PersonsDataSet.PersonRow)((DataRowView)bindingSource.Current).Row;
                PersonsDataSet.PersonTypeDataTable personTypeDataTable = DataSetDac.FindPersonTypes(person);

                DataGridViewComboBoxEditingControl comboBox = (DataGridViewComboBoxEditingControl)e.Control;
                comboBox.DataSource = personTypeDataTable;
                comboBox.SelectedValue = person.PersonTypeId;

                comboBox.SelectionChangeCommitted -= this.comboBox_SelectionChangeCommitted;
                comboBox.SelectionChangeCommitted += this.comboBox_SelectionChangeCommitted;
            }
        }

        void comboBox_SelectionChangeCommitted(object sender, EventArgs e)
        {
            this.dataGridView1.EndEdit();
        }
    }
}
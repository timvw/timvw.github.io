using System;
using System.Collections.Generic;
using System.Text;
using Be.TimVanWassenhove.ContextBoundSamples.PersonContract;
using Be.TimVanWassenhove.ContextBoundSamples.PersonEndPoint;
using System.Runtime.Remoting;
using System.Threading;

namespace Be.TimVanWassenhove.ContextBoundSamples.DemoApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            IPersonService personService = new PersonService();
            Person[] persons = personService.Find();
            personService.Delete(persons[0]);

            // why can't i catch this exception???
            //try
            //{
            //    personService.Delete(new Person(9, "Joshua", DateTime.Now));
            //}
            //catch (Exception e) {
            //    ;
            //}

            Console.Write("{0}Press any key to continue...", Environment.NewLine);
            Console.ReadKey();
        }
    }
}
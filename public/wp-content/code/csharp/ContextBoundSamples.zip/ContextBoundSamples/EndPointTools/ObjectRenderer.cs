using System;
using System.Collections.Generic;
using System.Text;
using log4net.ObjectRenderer;
using System.IO;
using System.Reflection;
using System.Collections;

namespace Be.TimVanWassenhove.ContextBoundSamples.EndPointTools
{
    public class ObjectRenderer : IObjectRenderer
    {
        #region Private Fields

        private int depth;
        private int level;
        private int position;
        private TextWriter textWriter;

        #endregion

        #region Constructors

        public ObjectRenderer()
        {
        }

        public ObjectRenderer(TextWriter textWriter)
        {
            this.depth = 10;
            this.level = 0;
            this.position = 0;
            this.textWriter = textWriter;
        }

        #endregion

        #region Static Members

        public static void RenderObject(object obj, TextWriter textWriter)
        {
            new ObjectRenderer(textWriter).WriteObject(string.Empty, obj);
        }

        #endregion

        #region IObjectRenderer Members

        public void RenderObject(RendererMap rendererMap, object obj, TextWriter textWriter)
        {
            new ObjectRenderer(textWriter).WriteObject(string.Empty, obj);
        }

        #endregion

        #region Private Members

        private void WriteObject(string prefix, object obj)
        {
            if (obj == null || obj is ValueType || obj is string)
            {
                this.WriteIndent();
                this.Write(prefix);
                this.WriteValue(obj);
                this.WriteLine();
            }
            else if (obj is IEnumerable)
            {
                foreach (object element in (IEnumerable)obj)
                {
                    if (element is IEnumerable && !(element is string))
                    {
                        this.WriteIndent();
                        this.Write(prefix);
                        this.Write("...");
                        this.WriteLine();
                        if (this.level < this.depth)
                        {
                            this.level++;
                            this.WriteObject(prefix, element);
                            this.level--;
                        }
                    }
                    else
                    {
                        this.WriteObject(prefix, element);
                    }
                }
            }
            else
            {
                MemberInfo[] members = obj.GetType().GetMembers(BindingFlags.Public | BindingFlags.Instance);
                this.WriteIndent();
                this.Write(prefix);
                bool propWritten = false;
                foreach (MemberInfo m in members)
                {
                    FieldInfo f = m as FieldInfo;
                    PropertyInfo p = m as PropertyInfo;
                    if (f != null || p != null)
                    {
                        if (propWritten)
                        {
                            this.WriteTab();
                        }
                        else
                        {
                            propWritten = true;
                        }
                        this.Write(m.Name);
                        this.Write("=");
                        Type t = f != null ? f.FieldType : p.PropertyType;
                        if (t.IsValueType || t == typeof(string))
                        {
                            this.WriteValue(f != null ? f.GetValue(obj) : p.GetValue(obj, null));
                        }
                        else
                        {
                            if (typeof(IEnumerable).IsAssignableFrom(t))
                            {
                                this.Write("...");
                            }
                            else
                            {
                                this.Write("{ }");
                            }
                        }
                    }
                }
                if (propWritten) this.WriteLine();
                if (this.level < this.depth)
                {
                    foreach (MemberInfo m in members)
                    {
                        FieldInfo f = m as FieldInfo;
                        PropertyInfo p = m as PropertyInfo;
                        if (f != null || p != null)
                        {
                            Type t = f != null ? f.FieldType : p.PropertyType;
                            if (!(t.IsValueType || t == typeof(string)))
                            {
                                object value = f != null ? f.GetValue(obj) : p.GetValue(obj, null);
                                if (value != null)
                                {
                                    this.level++;
                                    this.WriteObject(m.Name + ": ", value);
                                    this.level--;
                                }
                            }
                        }
                    }
                }
            }
        }

        private void WriteValue(object obj)
        {
            if (obj == null)
            {
                this.Write("null");
            }
            else if (obj is DateTime)
            {
                this.Write(((DateTime)obj).ToShortDateString());
            }
            else if (obj is ValueType || obj is string)
            {
                this.Write(obj.ToString());
            }
            else if (obj is IEnumerable)
            {
                this.Write("...");
            }
            else
            {
                this.Write("{ }");
            }
        }

        private void WriteIndent()
        {
            this.textWriter.Write(new string(' ', this.level));
        }

        private void WriteLine()
        {
            this.textWriter.WriteLine();
            this.position = 0;
        }

        private void Write(string s)
        {
            if (s != null)
            {
                this.textWriter.Write(s);
                this.position += s.Length;
            }
        }

        private void WriteTab()
        {
            this.Write("  ");
            while (this.position % 8 != 0) this.Write(" ");
        }

        #endregion
    }
}

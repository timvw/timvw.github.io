using System.Runtime.Remoting.Messaging;
using log4net;
using System;

namespace Be.TimVanWassenhove.ContextBoundSamples.EndPointTools
{
    public class LoggingSink : IMessageSink
    {
        #region Private Fields

        private IMessageSink nextSink;

        #endregion

        #region Constructors

        public LoggingSink(IMessageSink nextSink)
        {
            this.nextSink = nextSink;
        }

        #endregion

        #region IMessageSink Members

        public IMessageCtrl AsyncProcessMessage(IMessage msg, IMessageSink replySink)
        {
            return this.nextSink.AsyncProcessMessage(msg, replySink);
        }

        public IMessageSink NextSink
        {
            get { return this.nextSink; }
        }

        public IMessage SyncProcessMessage(IMessage msg)
        {
            IMethodMessage methodMessage = msg as IMethodMessage;
            ILog log = LogManager.GetLogger(methodMessage.TypeName);
            log.Debug(methodMessage);

            IMessage message = this.nextSink.SyncProcessMessage(msg);

            IMethodReturnMessage methodReturnMessage = message as IMethodReturnMessage;
            if (methodReturnMessage != null)
            {
                log.Debug(methodReturnMessage);
            }

            return message;
        }

        #endregion
    }
}

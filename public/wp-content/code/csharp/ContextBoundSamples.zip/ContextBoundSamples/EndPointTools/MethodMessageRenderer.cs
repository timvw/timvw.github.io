using System;
using System.Collections.Generic;
using System.Text;
using log4net.ObjectRenderer;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace Be.TimVanWassenhove.ContextBoundSamples.EndPointTools
{
    public class MethodMessageRenderer : IObjectRenderer
    {
        #region Constructors

        public MethodMessageRenderer()
        {
        }

        #endregion

        #region IObjectRenderer Members

        public void RenderObject(RendererMap rendererMap, object obj, TextWriter writer)
        {
            IMethodMessage methodMessage = obj as IMethodMessage;
            writer.WriteLine("{0}Calling: {1}{2}Params:", Environment.NewLine, methodMessage.MethodName, Environment.NewLine);
            ObjectRenderer.RenderObject(methodMessage.Args, writer);
            writer.WriteLine();

        }

        #endregion
    }
}

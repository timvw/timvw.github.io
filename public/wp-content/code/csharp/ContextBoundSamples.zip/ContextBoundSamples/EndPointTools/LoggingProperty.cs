using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;
using System.Reflection;

namespace Be.TimVanWassenhove.ContextBoundSamples.EndPointTools
{
    public class LoggingProperty : IContextProperty, IContributeServerContextSink
    {
        #region Static Members

        public static string GetName()
        {
            return MethodBase.GetCurrentMethod().DeclaringType.FullName;
        }

        #endregion

        #region IContextProperty Members

        public void Freeze(Context newContext)
        {
        }

        public bool IsNewContextOK(Context newCtx)
        {
            LoggingProperty loggingProperty = newCtx.GetProperty(LoggingProperty.GetName()) as LoggingProperty;
            return loggingProperty != null;
        }

        public string Name
        {
            get { return LoggingProperty.GetName(); }
        }

        #endregion

        #region IContributeServerContextSink Members

        public IMessageSink GetServerContextSink(IMessageSink nextSink)
        {
            IMessageSink loggingSink = new LoggingSink(nextSink);
            return loggingSink;
        }

        #endregion
    }
}

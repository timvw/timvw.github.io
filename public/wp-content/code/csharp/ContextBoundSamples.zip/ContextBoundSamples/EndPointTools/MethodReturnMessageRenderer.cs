using System;
using System.Collections.Generic;
using System.Text;
using log4net.ObjectRenderer;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace Be.TimVanWassenhove.ContextBoundSamples.EndPointTools
{
    public class MethodReturnMessageRenderer : IObjectRenderer
    {
        #region Constructors

        public MethodReturnMessageRenderer()
        {
        }

        #endregion

        #region IObjectRenderer Members

        public void RenderObject(RendererMap rendererMap, object obj, TextWriter writer)
        {
            IMethodReturnMessage methodReturnMessage = obj as IMethodReturnMessage;
            writer.WriteLine("{0}Called: {1}{2}Params:", Environment.NewLine, methodReturnMessage.MethodName, Environment.NewLine);
            ObjectRenderer.RenderObject(methodReturnMessage.Args, writer);
            if (methodReturnMessage.MethodName != ".ctor")
            {
                writer.WriteLine("{0}ReturnValue:", Environment.NewLine);
                ObjectRenderer.RenderObject(methodReturnMessage.ReturnValue, writer);
            }
            if (methodReturnMessage.Exception != null)
            {
                writer.WriteLine("{0}Exception:", Environment.NewLine);
                ObjectRenderer.RenderObject(methodReturnMessage.Exception, writer);
            }
            writer.WriteLine();
        }

        #endregion
    }
}

using System;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Activation;
using System.Reflection;

namespace Be.TimVanWassenhove.ContextBoundSamples.EndPointTools
{
    [AttributeUsage(AttributeTargets.Class)]
    public class LoggingAttribute : ContextAttribute
    {
        #region Private Fields

        private bool enabled;

        #endregion

        #region Constructors

        public LoggingAttribute()
            : this(true)
        {

        }

        public LoggingAttribute(bool enabled)
            : base(MethodBase.GetCurrentMethod().DeclaringType.FullName)
        {
            this.enabled = enabled;
        }

        #endregion

        #region Overriden Members

        public override void GetPropertiesForNewContext(IConstructionCallMessage ctorMsg)
        {
            if (this.enabled)
            {
                LoggingProperty loggingProperty = new LoggingProperty();
                ctorMsg.ContextProperties.Add(loggingProperty);
            }
        }

        public override bool IsContextOK(Context ctx, IConstructionCallMessage ctorMsg)
        {
            if (this.enabled)
            {
                LoggingProperty loggingProperty = ctx.GetProperty(LoggingProperty.GetName()) as LoggingProperty;
                return loggingProperty != null;
            }
            else
            {
                return true;
            }
        }

        #endregion
    }
}

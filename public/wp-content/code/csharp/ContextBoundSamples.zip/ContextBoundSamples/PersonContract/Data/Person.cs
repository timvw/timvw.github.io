using System;

namespace Be.TimVanWassenhove.ContextBoundSamples.PersonContract
{
    [Serializable]
    public class Person : IComparable<Person>
    {
        #region Private Fields

        private int id;
        private string name;
        private DateTime birthday;
        private Person[] children;

        #endregion

        #region Constructors

        public Person(int id, string name, DateTime birthday)
            : this(id, name, birthday, new Person[0])
        {
        }

        public Person(int id, string name, DateTime birthday, Person[] children)
        {
            this.id = id;
            this.name = name;
            this.birthday = birthday;
            this.children = children;
        }

        #endregion

        #region Public Properties

        public int Id
        {
            get { return this.id; }
            set { this.id = value; }
        }

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public DateTime Birthday
        {
            get { return this.birthday; }
            set { this.birthday = value; }
        }

        public Person[] Children
        {
            get { return this.children; }
            set { this.children = value; }
        }

        #endregion

        #region Overriden Members

        public override bool Equals(object obj)
        {
            return CompareTo(obj as Person) == 0;
        }

        public override int GetHashCode()
        {
            return this.id.GetHashCode();
        }

        #endregion

        #region IComparable<Person> Members

        public int CompareTo(Person other)
        {
            if (other == null) { 
                return 1; 
            }

            return this.id.CompareTo(other.id);
        }

        #endregion
    }
}

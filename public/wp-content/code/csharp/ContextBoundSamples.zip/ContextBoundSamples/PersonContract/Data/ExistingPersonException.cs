using System;
using System.Runtime.Remoting;
using System.Runtime.Serialization;

namespace Be.TimVanWassenhove.ContextBoundSamples.PersonContract
{
    [Serializable]
    public class ExistingPersonException : ArgumentException
    {
        #region Constructors

        public ExistingPersonException()
            : base("The Person exists already.")
        {

        }

        public ExistingPersonException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        #endregion
    }
}

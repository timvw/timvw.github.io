using System;
using System.Runtime.Remoting;
using System.Runtime.Serialization;

namespace Be.TimVanWassenhove.ContextBoundSamples.PersonContract
{
    [Serializable]
    public class UnknownPersonException : ArgumentException
    {
        #region Constructors

        public UnknownPersonException()
            : base("The Person is unknown.")
        {

        }

        public UnknownPersonException(SerializationInfo info, StreamingContext context)
            :base(info, context)
        {
        }

        #endregion
    }
}

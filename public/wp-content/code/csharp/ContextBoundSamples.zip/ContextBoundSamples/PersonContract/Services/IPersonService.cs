namespace Be.TimVanWassenhove.ContextBoundSamples.PersonContract
{
    public interface IPersonService
    {
        void Create(Person person);
        Person Read(int personId);
        void Update(Person person);
        void Delete(Person person);
        Person[] Find();
    }
}

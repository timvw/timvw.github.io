using System;
using System.Collections.Generic;
using Be.TimVanWassenhove.ContextBoundSamples.PersonContract;
using Be.TimVanWassenhove.ContextBoundSamples.EndPointTools;

namespace Be.TimVanWassenhove.ContextBoundSamples.PersonEndPoint
{
    [Logging]
    public class PersonService : ContextBoundObject, IPersonService
    {
        #region Private Fields

        private List<Person> persons;

        #endregion

        #region Constructors

        public PersonService()
        {
            this.persons = new List<Person>();
            this.persons.Add(new Person(1, "Tim", new DateTime(1980, 4, 30)));
            this.persons.Add(new Person(2, "John", new DateTime(1982, 1, 30)));
            this.persons.Add(new Person(3, "Mike", new DateTime(1984, 2, 20), new Person[] { new Person(4, "Sun", DateTime.Now) }));
        }

        #endregion

        #region IPersonService Members

        public void Create(Person person)
        {
            if (this.persons.Contains(person))
            {
                throw new ArgumentException("Person exists already");
            }

            this.persons.Add(person);
        }

        public Person Read(int personId)
        {
            return null;
        }

        public void Update(Person person)
        {
            if (!this.persons.Contains(person))
            {
                throw new UnknownPersonException();
            }
        }

        public void Delete(Person person)
        {
            if (!this.persons.Remove(person))
            {
                throw new UnknownPersonException();
            }
        }

        public Person[] Find()
        {
            return this.persons.ToArray();
        }

        #endregion
    }
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Remoting;

namespace Be.TimVanWassenhove.ContextBoundSamples
{
    public static class RemotingHelper
    {
        static RemotingHelper()
        {
            RemotingConfiguration.Configure(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile, false);
        }

        private static object GetService(string fullName)
        {
            WellKnownClientTypeEntry[] wellKnownClientTypeEntries = RemotingConfiguration.GetRegisteredWellKnownClientTypes();
            foreach (WellKnownClientTypeEntry welknownClientTypeEntry in wellKnownClientTypeEntries)
            {
                if (welknownClientTypeEntry.ObjectType.FullName == fullName)
                {
                    return Activator.GetObject(welknownClientTypeEntry.ObjectType, welknownClientTypeEntry.ObjectUrl);
                }
            }

            throw new ArgumentException(fullName + " is not a wellKnownClientType.");
        }

        public static T GetService<T>()
        {
            return (T)RemotingHelper.GetService(typeof(T).FullName);
        }
    }
}

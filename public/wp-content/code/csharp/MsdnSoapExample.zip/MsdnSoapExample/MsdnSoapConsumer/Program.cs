using System;
using System.Collections.Generic;
using System.Text;

namespace MsdnSoapConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            BookWebService bookWs = new BookWebService();
            Console.WriteLine(bookWs.GetAuthor("001-29912344-12"));

            Console.Write("{0}Press any key to continue...", Environment.NewLine);
            Console.ReadKey();
        }
    }
}

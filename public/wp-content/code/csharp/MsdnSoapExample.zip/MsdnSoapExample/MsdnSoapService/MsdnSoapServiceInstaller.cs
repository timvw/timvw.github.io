using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;

namespace MsdnSoapService
{
    [RunInstaller(true)]
    public partial class MsdnSoapServiceInstaller : Installer
    {
        public MsdnSoapServiceInstaller()
        {
            InitializeComponent();
        }
    }
}
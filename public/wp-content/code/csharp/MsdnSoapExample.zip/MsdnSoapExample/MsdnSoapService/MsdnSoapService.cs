using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using Microsoft.Web.Services3.Addressing;
using System.Net;
using Microsoft.Web.Services3.Messaging;

namespace MsdnSoapService
{
    public partial class MsdnSoapService : ServiceBase
    {
        private EndpointReference epr;

        public MsdnSoapService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            this.RequestAdditionalTime(60000);

            // in real life you would probably register a whole lot of services via configuration file
            this.epr = GetEndpointReference("example.com", 9090, "BookWebService");
            SoapReceivers.Add(epr, typeof(BookWebService));
        }

        protected override void OnStop()
        {
            SoapReceivers.Remove(this.epr);
        }


        static EndpointReference GetEndpointReference(string host, int port, string path)
        {
            Uri address = new Uri(string.Format("soap.tcp://{0}:{1}/{2}", host, port, path));
            Uri via = new Uri(string.Format("soap.tcp://{0}:{1}/{2}", Dns.GetHostEntry(host).AddressList[0], port, path));
            return new EndpointReference(address, via);
        }
    }
}

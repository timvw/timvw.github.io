using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Services;

namespace MsdnSoapService
{
    [WebService(Namespace="soap.tcp://example.com:9090/BookWebService", Description="A webservice that exposes book related tasks")]
    public class BookWebService
    {
        [WebMethod(Description="Returns the author of the book with the given ISBN")]
        public string GetAuthor(string isbn)
        {
            // in reality we would query a resource etc...
            return "timvw";
        }
    }
}

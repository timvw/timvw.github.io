﻿using System;

namespace Demo.Infrastructure
{
    public static class ExtensionMethods
    {
        public static void Raise<T>(this EventHandler<T> eventHandler, object sender, T eventArgs) where T : EventArgs
        {
            var handler = eventHandler;
            if (ReferenceEquals(handler, null)) return;
            handler(sender, eventArgs);
        }
    }
}
namespace Demo.Infrastructure
{
    /// <summary>
    /// Represents a specification for instances of type T.
    /// </summary>
    /// <typeparam name="T">The type for which this is a specification.</typeparam>
    public interface ISpecification<T>
    {
        /// <summary>
        /// Determines if the candidate satisfied the specification.
        /// </summary>
        /// <param name="candidate">The instance of type T for which the satisfaction will be determined.</param>
        /// <returns><value>true</value> if the candidate satisfied the specification, <value>false</value> otherwise.</returns>
        bool IsSatisfiedBy(T candidate);
    }
}
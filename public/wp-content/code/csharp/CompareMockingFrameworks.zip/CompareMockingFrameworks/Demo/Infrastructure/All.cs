namespace Demo.Infrastructure
{
    public class All<T> : ISpecification<T>
    {
        public bool IsSatisfiedBy(T candidate)
        {
            return true;
        }
    }
}
﻿using System;
using Demo.Infrastructure;

namespace Demo.Domain
{
    public class ProductDetailPresenter
    {
        private readonly IProductRepository repository;
        private readonly IProductDetailView view;

        public ProductDetailPresenter(IProductDetailView view, IProductRepository repository)
        {
            this.view = view;
            this.view.EditClick += this.view_EditClick;
            this.repository = repository;
        }

        public event EventHandler<EventArgs> UserClick;

        private void view_EditClick(object sender, EventArgs e)
        {
            this.UserClick.Raise(this, EventArgs.Empty);

            this.view.DisplayEditButton(false);
            this.view.DisplayOkButton(true);
            this.view.DisplayCancelButton(true);

            try
            {
                var categories = this.repository.FindCategories(new All<ICategory>());
                this.view.DisplayCategories(categories);

                var defaultCategory = this.repository.GetCategory(this.view.CategoryId);
                this.view.DisplayDefaultCategory(defaultCategory);
            }
            catch
            {
                this.view.DisplayError("Oops. Something went wrong.");
            }
        }
    }
}
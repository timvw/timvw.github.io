namespace Demo.Domain
{
    public interface ICategory
    {
        int Id { get; }
        string Name { get; set; }
    }
}
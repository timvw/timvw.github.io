using System;
using System.Collections.Generic;

namespace Demo.Domain
{
    public interface IProductDetailView
    {
        int CategoryId { get; set; }
        event EventHandler EditClick;

        void DisplayEditButton(bool visible);
        void DisplayOkButton(bool visible);
        void DisplayCancelButton(bool visible);

        void DisplayCategories(IEnumerable<ICategory> categories);
        void DisplayDefaultCategory(ICategory category);
        void DisplayError(string message);
    }
}
using System.Collections.Generic;
using Demo.Infrastructure;

namespace Demo.Domain
{
    public interface IProductRepository
    {
        IEnumerable<ICategory> FindCategories(ISpecification<ICategory> specification);
        ICategory GetCategory(int categoryId);
    }
}
﻿using System;
using System.Collections.Generic;
using Demo.Domain;
using Demo.Infrastructure;
using Rhino.Mocks;
using Rhino.Mocks.Constraints;
using Xunit;

namespace Demo.RhinoMock.ProductDetailPresentation
{
    public class WhenUserClicksEdit
    {
        protected IEnumerable<ICategory> categories;
        protected MockRepository mockRepository = new MockRepository();
        protected IProductDetailView productDetailView;
        protected IProductRepository productRepository;
        protected ProductDetailPresenter sut;
        protected EventHandler<EventArgs> userClickEventHandler;

        /// <summary>
        /// Given the context and exercise the system operation we want to test.
        /// </summary>
        public WhenUserClicksEdit()
        {
            this.Given();
            this.When();
        }

        /// <summary>
        /// Given the context for a user that begins to edit a product.
        /// </summary>
        protected virtual void Given()
        {
            this.mockRepository = new MockRepository();
            this.productDetailView = this.mockRepository.DynamicMock<IProductDetailView>();
            this.productRepository = this.mockRepository.DynamicMock<IProductRepository>();
            this.categories = this.mockRepository.DynamicMock<IEnumerable<ICategory>>();
            this.userClickEventHandler = this.mockRepository.DynamicMock<EventHandler<EventArgs>>();

            SetupResult
                .For(this.productRepository.FindCategories(null)).IgnoreArguments()
                .Return(this.categories);

            SetupResult
                .For(this.productRepository.GetCategory(0)).IgnoreArguments()
                .Do((Delegates.Function<ICategory, int>)(categoryId =>
                {
                    if (categoryId % 2 == 0) throw new ArgumentException("I don't like even numbers.");

                    var category = this.mockRepository.DynamicMock<ICategory>();
                    SetupResult.For(category.Id).Return(categoryId);
                    return category;
                }));

            SetupResult
                .For(this.productDetailView.CategoryId)
                .Return(3);

            this.sut = new ProductDetailPresenter(this.productDetailView, this.productRepository);
            this.sut.UserClick += this.userClickEventHandler;

            this.mockRepository.ReplayAll();
        }

        /// <summary>
        /// Exercise the system operation we want to test.
        /// </summary>
        protected virtual void When()
        {
            this.productDetailView
                .GetEventRaiser(x => x.EditClick += null)
                .Raise(this.productDetailView, EventArgs.Empty);
        }

        [Fact]
        public void ShouldHideEditButton()
        {
            this.productDetailView.AssertWasCalled(
                view => view.DisplayEditButton(false));
        }

        [Fact]
        public void ShouldDisplayOkButton()
        {
            this.productDetailView.AssertWasCalled(
                view => view.DisplayOkButton(true));
        }

        [Fact]
        public void ShouldDisplayCancelButton()
        {
            this.productDetailView.AssertWasCalled(
                view => view.DisplayCancelButton(true));
        }

        [Fact]
        public void ShouldLookupCategories()
        {
            this.productRepository.AssertWasCalled(
                repository => repository.FindCategories(Arg<ISpecification<ICategory>>
                    .Matches(Is.TypeOf(typeof(All<ICategory>)))));
        }

        [Fact]
        public void ShouldLookupCategoriesAtMostOneTime()
        {
            this.productRepository.AssertWasCalled(
                repository => repository.FindCategories(null),
                constraints => constraints.IgnoreArguments().Repeat.Once());
        }

        [Fact]
        public void ShouldDisplayCategories()
        {
            this.productDetailView.AssertWasCalled(
                view => view.DisplayCategories(this.categories));
        }

        [Fact]
        public void ShouldRaiseUserClickEvent()
        {
            this.userClickEventHandler.AssertWasCalled(
                eventHandler => eventHandler(this.sut, EventArgs.Empty));
        }

        [Fact]
        public void ShouldRetrieveCategory()
        {
            this.productRepository.AssertWasCalled(
                repository => repository.GetCategory(this.productDetailView.CategoryId));
        }

        [Fact]
        public void ShouldDisplayDefaultCategory()
        {
            this.productDetailView.AssertWasCalled(
                view => view.DisplayDefaultCategory(Arg<ICategory>.Is.Anything));
        }
    }
}
using System;
using Rhino.Mocks;
using Xunit;

namespace Demo.RhinoMock.ProductDetailPresentation
{
    public class WhenUserClicksEditAndCategoriesAreNotFound : WhenUserClicksEdit
    {
        protected override void Given()
        {
            base.Given();
            
            this.productRepository.BackToRecord();

            SetupResult
                .For(this.productRepository.FindCategories(null)).IgnoreArguments()
                .Throw(new Exception());

            this.productRepository.Replay();
        }

        [Fact]
        public void ShouldDisplayError()
        {
            this.productDetailView.AssertWasCalled(
                view => view.DisplayError(Arg<string>.Is.Anything));
        }
    }
}
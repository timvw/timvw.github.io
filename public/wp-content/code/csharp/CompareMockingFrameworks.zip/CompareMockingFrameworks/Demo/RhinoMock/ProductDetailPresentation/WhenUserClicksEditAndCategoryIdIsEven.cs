using System;
using Rhino.Mocks;
using Xunit;

namespace Demo.RhinoMock.ProductDetailPresentation
{
    public class WhenUserClicksEditAndCategoryIdIsEven : WhenUserClicksEdit
    {
        protected override void Given()
        {
            base.Given();

            this.productDetailView.BackToRecord(BackToRecordOptions.Expectations);

            SetupResult
                .For(this.productDetailView.CategoryId)
                .Return(2);

            this.productDetailView.Replay();
        }

        [Fact]
        public void ShouldDisplayError()
        {
            this.productDetailView.AssertWasCalled(
                view => view.DisplayError(Arg<string>.Is.Anything));
        }

        [Fact]
        public void CategoryIdShouldBeEven()
        {
            Assert.True(this.productDetailView.CategoryId % 2 == 0);
        }

        [Fact]
        public void ShouldThrowWhenCategoryWithEvenIdIsRequested()
        {
            Assert.Throws<ArgumentException>(() => this.productRepository.GetCategory(this.productDetailView.CategoryId));
        }
    }
}
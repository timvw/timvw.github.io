﻿using System;
using Demo.Domain;
using Demo.Infrastructure;
using Moq;
using Xunit;

namespace Demo.Moq.ProductDetailPresentation
{
    public class WhenUserClicksEditAndCategoriesAreNotFound : WhenUserClicksEdit
    {
        protected override void Given()
        {
            base.Given();

            this.productRepositoryMock
                .Setup(repository => repository.FindCategories(It.IsAny<ISpecification<ICategory>>()))
                .Throws(new Exception());
        }

        [Fact]
        public void ShouldDisplayError()
        {
            this.productDetailViewMock.Verify(
                view => view.DisplayError(It.IsAny<string>()));
        }
    }
}
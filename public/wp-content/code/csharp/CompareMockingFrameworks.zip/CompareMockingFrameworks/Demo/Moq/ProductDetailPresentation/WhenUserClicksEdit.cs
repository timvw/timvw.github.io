﻿using System;
using System.Collections.Generic;
using Demo.Domain;
using Demo.Infrastructure;
using Moq;
using Xunit;

namespace Demo.Moq.ProductDetailPresentation
{
    public class WhenUserClicksEdit
    {
        protected ProductDetailPresenter sut;

        protected Mock<IProductDetailView> productDetailViewMock;
        protected Mock<IProductRepository> productRepositoryMock;
        protected Mock<IEnumerable<ICategory>> categoriesMock;
        protected bool userClicked;

        /// <summary>
        /// Given the context and exercise the system operation we want to test.
        /// </summary>
        public WhenUserClicksEdit()
        {
            this.Given();
            this.When();
        }

        /// <summary>
        /// Given the context for a user that begins to edit a product.
        /// </summary>
        protected virtual void Given()
        {
            this.productDetailViewMock = new Mock<IProductDetailView>();
            this.productRepositoryMock = new Mock<IProductRepository>();
            this.categoriesMock = new Mock<IEnumerable<ICategory>>();

            this.productRepositoryMock
                .Setup(x => x.FindCategories(It.IsAny<ISpecification<ICategory>>()))
                .Returns(this.categoriesMock.Object);

            this.productRepositoryMock
                .Setup(repository => repository.GetCategory(It.IsAny<int>()))
                .Returns<int>(categoryId =>
                {
                    if (categoryId % 2 == 0) throw new ArgumentException("I don't like even numbers.");

                    var category = new Mock<ICategory>();
                    category.Setup(cat => cat.Id).Returns(categoryId);
                    return category.Object;
                });

            this.productDetailViewMock
                .Setup(view => view.CategoryId)
                .Returns(3);

            this.sut = new ProductDetailPresenter(this.productDetailViewMock.Object, this.productRepositoryMock.Object);
            this.sut.UserClick += (sender, args) => this.userClicked = true;
        }

        /// <summary>
        /// Perform the behavior we want to test.
        /// </summary>
        protected virtual void When()
        {
            this.productDetailViewMock
                .Raise(view => view.EditClick += null, this.productDetailViewMock.Object, EventArgs.Empty);
        }

        [Fact]
        public void ShouldHideEditButton()
        {
            this.productDetailViewMock.Verify(
                view => view.DisplayEditButton(false));
        }

        [Fact]
        public void ShouldDisplayOkButton()
        {
            this.productDetailViewMock.Verify(
                view => view.DisplayOkButton(true));
        }

        [Fact]
        public void ShouldDisplayCancelButton()
        {
            this.productDetailViewMock.Verify(
                view => view.DisplayCancelButton(true));
        }

        [Fact]
        public void ShouldLookupCategories()
        {
            this.productRepositoryMock.Verify(
                repository => repository.FindCategories(It.Is<ISpecification<ICategory>>(
                    specification => specification.GetType() == typeof(All<ICategory>))));
        }

        [Fact]
        public void ShouldLookupCategoriesAtMostOneTime()
        {
            this.productRepositoryMock.Verify(
                repository => repository.FindCategories(It.IsAny<ISpecification<ICategory>>()), Times.Exactly(1));
        }

        [Fact]
        public void ShouldDisplayCategories()
        {
            this.productDetailViewMock.Verify(
                view => view.DisplayCategories(It.Is<IEnumerable<ICategory>>(
                    categoriesEnumerable => ReferenceEquals(categoriesEnumerable, this.categoriesMock.Object))));
        }

        [Fact]
        public void ShouldRaiseUserClickEvent()
        {
            Assert.True(this.userClicked);
        }

        [Fact]
        public void ShouldRetrieveCategory()
        {
            var view = this.productDetailViewMock.Object;

            this.productRepositoryMock.Verify(
                repository => repository.GetCategory(view.CategoryId));
        }

        [Fact]
        public void ShouldDisplayDefaultCategory()
        {
            this.productDetailViewMock.Verify(
                view => view.DisplayDefaultCategory(It.IsAny<ICategory>()));
        }
    }
}
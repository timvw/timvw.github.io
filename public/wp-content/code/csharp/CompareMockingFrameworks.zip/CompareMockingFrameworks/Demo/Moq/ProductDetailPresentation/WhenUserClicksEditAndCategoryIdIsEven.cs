﻿using Moq;
using Xunit;

namespace Demo.Moq.ProductDetailPresentation
{
    public class WhenUserClicksEditAndCategoryIdIsEven : WhenUserClicksEdit
    {
        protected override void Given()
        {
            base.Given();

            this.productDetailViewMock
                .Setup(view => view.CategoryId)
                .Returns(2);
        }

        [Fact]
        public void ShouldDisplayError()
        {
            this.productDetailViewMock.Verify(
                view => view.DisplayError(It.IsAny<string>()));
        }
    }
}
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DataGridViewComboBoxBinding
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.dataGridView1.AutoGenerateColumns = false;
            this.ColumnName.DataPropertyName = "Name";
            this.ColumnPersonTypeCode.DataPropertyName = "PersonTypeCode";
            this.ColumnPersonTypeCode.DisplayMember = "Label";
            this.ColumnPersonTypeCode.ValueMember = "PersonTypeCode";
            this.ColumnPersonTypeCode.DataSource = FindPersonTypes();

            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = FindPersons();
            this.dataGridView1.DataSource = bindingSource;
        }

        void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (this.dataGridView1.CurrentCell.ColumnIndex == this.ColumnPersonTypeCode.Index)
            {
                BindingSource bindingSource = this.dataGridView1.DataSource as BindingSource;
                Person person = bindingSource.Current as Person;
                BindingList<PersonType> bindingList = this.FindPersonTypes(person);

                DataGridViewComboBoxEditingControl comboBox = e.Control as DataGridViewComboBoxEditingControl;
                comboBox.DataSource = bindingList;
                if (person.PersonTypeCode != null)
                {
                    comboBox.SelectedValue = person.PersonTypeCode;
                }
                else
                {
                    comboBox.SelectedValue = string.Empty;
                }

                comboBox.SelectionChangeCommitted -= this.comboBox_SelectionChangeCommitted;
                comboBox.SelectionChangeCommitted += this.comboBox_SelectionChangeCommitted;
            }
        }

        void comboBox_SelectionChangeCommitted(object sender, EventArgs e)
        {
            this.dataGridView1.EndEdit();
        }

        private BindingList<Person> FindPersons()
        {
            BindingList<Person> bindingList = new BindingList<Person>();
            bindingList.Add(new Person("Timvw", PersonTypeCode.Geek));
            bindingList.Add(new Person("John Doe", PersonTypeCode.Anonymous));
            bindingList.Add(new Person("An Onymous", PersonTypeCode.Anonymous));
            bindingList.Add(new Person("Jenna Jameson", PersonTypeCode.Babe));
            bindingList.Add(new Person("Null Able", null));
            return bindingList;
        }

        private BindingList<PersonType> FindPersonTypes()
        {
            BindingList<PersonType> bindingList = new BindingList<PersonType>();
            bindingList.Add(new PersonType("A geeky person", PersonTypeCode.Geek));
            bindingList.Add(new PersonType("A coward", PersonTypeCode.Anonymous));
            bindingList.Add(new PersonType("Feeling hot hot hot", PersonTypeCode.Babe));
            bindingList.Add(new PersonType(string.Empty, null));
            return bindingList;
        }

        private BindingList<PersonType> FindPersonTypes(Person person)
        {
            // by default, all persons simply have one of the available persontypecodes
            BindingList<PersonType> bindingList = FindPersonTypes();

            if (person.PersonTypeCode != null && person.PersonTypeCode.Equals(PersonTypeCode.Geek))
            {
                // geeks are doomed to stay geeks
                bindingList.RemoveAt(2);
                bindingList.RemoveAt(1);
            }

            return bindingList;
        }
    }

    //enum PersonTypeCode
    //{
    //    Geek = 0,
    //    Anonymous = 1,
    //    Babe = 2
    //}

    class PersonTypeCode
    {
        public static PersonTypeCode Geek
        {
            get { return new PersonTypeCode(0); }
        }

        public static PersonTypeCode Anonymous
        {
            get { return new PersonTypeCode(1); }
        }

        public static PersonTypeCode Babe
        {
            get { return new PersonTypeCode(2); }
        }

        private int id;

        public PersonTypeCode(int id)
        {
            this.id = id;
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (obj == this) return true;
            PersonTypeCode personTypeCode = obj as PersonTypeCode;
            if (personTypeCode == null) return false;
            return this.id == personTypeCode.id;
        }

        public override int GetHashCode()
        {
            return this.id.GetHashCode();
        }
    }

    class PersonType
    {
        private PersonTypeCode personTypeCode;
        private string label;

        public PersonType(string label, PersonTypeCode city)
        {
            this.label = label;
            this.personTypeCode = city;
        }

        public string Label
        {
            get { return this.label; }
            set { this.label = value; }
        }

        public PersonTypeCode PersonTypeCode
        {
            get { return this.personTypeCode; }
            set { this.personTypeCode = value; }
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (obj == this) return true;
            PersonType personType = obj as PersonType;
            if (personType == null) return false;
            return this.personTypeCode == personType.personTypeCode;
        }

        public override int GetHashCode()
        {
            return this.label.GetHashCode();
        }
    }

    class Person
    {
        private PersonTypeCode personTypeCode;
        private string name;

        public Person(string name, PersonTypeCode personTypeCode)
        {
            this.name = name;
            this.personTypeCode = personTypeCode;
        }

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public PersonTypeCode PersonTypeCode
        {
            get { return this.personTypeCode; }
            set { this.personTypeCode = value; }
        }
    }
}
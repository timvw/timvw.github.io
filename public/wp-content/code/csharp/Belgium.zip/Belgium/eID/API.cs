using System;
using System.Runtime.InteropServices;
using eID.Interop;
using eID.SmartCardAPI;

namespace eID.API
{
    #region Enumerations
    public enum ReturnCode : int
    {
        /// <summary>
        /// Function succeeded
        /// </summary>
        OK = 0,

        /// <summary>
        /// Unknown system error (see system error code)
        /// </summary>
        E_SYSTEM = 1,

        /// <summary>
        /// Unknown PC/SC error (see PC/SC error code)
        /// </summary>
        E_PCSC = 2,

        /// <summary>
        /// Unknown card error (see card status word)
        /// </summary>
        E_CARD = 3,

        /// <summary>
        /// Invalid parameter (NULL pointer, out of bound, etc.)
        /// </summary>
        E_BAD_PARAM = 4,

        /// <summary>
        /// An internal consistency check failed
        /// </summary>
        E_INTERNAL = 5,

        /// <summary>
        /// The supplied handle was invalid
        /// </summary>
        E_INVALID_HANDLE = 6,

        /// <summary>
        /// The data buffer to receive returned data is too small for the 
        /// returned data
        /// </summary>
        E_INSUFFICIENT_BUFFER = 7,

        /// <summary>
        /// An internal communications error has been detected
        /// </summary>
        E_COMM_ERROR = 8,

        /// <summary>
        /// A specified timeout value has expired
        /// </summary>
        E_TIMEOUT = 9,

        /// <summary>
        /// Unknown card detected
        /// </summary>
        E_UNKNOWN_CARD = 10,

        /// <summary>
        /// Input on pinpad cancelled
        /// </summary>
        E_KEYPAD_CANCELLED = 11,

        /// <summary>
        /// Timout returned from pinpad
        /// </summary>
        E_KEYPAD_TIMEOUT = 12,

        /// <summary>
        /// The two PINs did not match
        /// </summary>
        E_KEYPAD_PIN_MISMATCH = 13,

        /// <summary>
        /// Message too long on pinpad
        /// </summary>
        E_KEYPAD_MSG_TOO_LONG = 14,

        /// <summary>
        ///  Invalid PIN length
        /// </summary>
        E_INVALID_PIN_LENGTH = 15,

        /// <summary>
        /// Error in a signature verification or a certificate validation
        /// </summary>
        E_VERIFICATION = 16,

        /// <summary>
        ///  Library not initialized
        /// </summary>
        E_NOT_INITIALIZED = 17,

        /// <summary>
        /// An internal error has been detected, but the source is unknown
        /// </summary>
        E_UNKNOWN = 18,

        /// <summary>
        /// Function is not supported
        /// </summary>
        E_UNSUPPORTED_FUNCTION = 19,

        /// <summary>
        /// Incorrect library version
        /// </summary>
        E_INCORRECT_VERSION = 20,

        /// <summary>
        /// Wrong Root Certificate
        /// </summary>
        E_INVALID_ROOT_CERT = 21,

        /// <summary>
        /// Certificate validation failed
        /// </summary>
        E_VALIDATION = 22
    }

    public enum CertificateReturnCode : int
    {
        /// <summary>
        /// Validation has occurred successfully.
        /// </summary>
        CERT_VALIDATED_OK = 0,

        /// <summary>
        /// No validation has been done.
        /// </summary>
        CERT_NOT_VALIDATED = 1,

        /// <summary>
        /// Unable to get issuer certificate
        /// </summary>
        UNABLE_TO_GET_ISSUER_CERT = 2,

        /// <summary>
        /// Unable to get certificate CRL
        /// </summary>
        UNABLE_TO_GET_CRL = 3,

        /// <summary>
        /// Unable to decrypt certificate's signature
        /// </summary>
        UNABLE_TO_DECRYPT_CERT_SIGNATURE = 4,

        /// <summary>
        /// Unable to decrypt CRL's signature
        /// </summary>
        UNABLE_TO_DECRYPT_CRL_SIGNATURE = 5,

        /// <summary>
        /// Unable to decode issuer public key
        /// </summary>
        UNABLE_TO_DECODE_ISSUER_PUBLIC_KEY = 6,

        /// <summary>
        /// Certificate signature failure
        /// </summary>
        CERT_SIGNATURE_FAILURE = 7,

        /// <summary>
        /// CRL signature failure
        /// </summary>
        CRL_SIGNATURE_FAILURE = 8,

        /// <summary>
        /// Certificate is not yet valid
        /// </summary>
        CERT_NOT_YET_VALID = 9,

        /// <summary>
        /// Certificate has expired
        /// </summary>
        CERT_HAS_EXPIRED = 10,

        /// <summary>
        /// CRL is not yet valid
        /// </summary>
        CRL_NOT_YET_VALID = 11,

        /// <summary>
        /// CRL has expired
        /// </summary>
        CRL_HAS_EXPIRED = 12,

        /// <summary>
        /// Format error in certificate's notBefore field
        /// </summary>
        ERR_IN_CERT_NOT_BEFORE_FIELD = 13,

        /// <summary>
        /// Format error in certificate's notAfter field
        /// </summary>
        ERR_IN_CERT_NOT_AFTER_FIELD = 14,

        /// <summary>
        /// Format error in CRL's lastUpdate field
        /// </summary>
        ERR_IN_CRL_LAST_UPDATE_FIELD = 15,

        /// <summary>
        /// Format error in CRL's nextUpdate field
        /// </summary>
        ERR_IN_CRL_NEXT_UPDATE_FIELD = 16,

        /// <summary>
        /// Out of memory
        /// </summary>
        OUT_OF_MEM = 17,

        /// <summary>
        /// Self signed certificate
        /// </summary>
        DEPTH_ZERO_SELF_SIGNED_CERT = 18,

        /// <summary>
        /// Self signed certificate in certificate chain
        /// </summary>
        SELF_SIGNED_CERT_IN_CHAIN = 19,

        /// <summary>
        /// Unable to get local issuer certificate
        /// </summary>
        UNABLE_TO_GET_ISSUER_CERT_LOCALLY = 20,

        /// <summary>
        /// Unable to verify the first certificate
        /// </summary>
        UNABLE_TO_VERIFY_LEAF_SIGNATURE = 21,

        /// <summary>
        /// Certificate chain too long
        /// </summary>
        CERT_CHAIN_TOO_LONG = 22,

        /// <summary>
        /// Certificate revoked
        /// </summary>
        CERT_REVOKED = 23,

        /// <summary>
        /// Invalid CA certificate
        /// </summary>
        INVALID_CA = 24,

        /// <summary>
        /// Path length constraint exceeded
        /// </summary>
        PATH_LENGTH_EXCEEDED = 25,

        /// <summary>
        /// Unsupported certificate purpose
        /// </summary>
        INVALID_PURPOSE = 26,

        /// <summary>
        /// Certificate not trusted
        /// </summary>
        CERT_UNTRUSTED = 27,


        /// <summary>
        /// Certificate rejected 
        /// </summary>
        CERT_REJECTED = 28,

        /// <summary>
        /// Subject issuer mismatch
        /// </summary>
        SUBJECT_ISSUER_MISMATCH = 29,

        /// <summary>
        /// Authority and subject key identifier mismatch
        /// </summary>
        AKID_SKID_MISMATCH = 30,

        /// <summary>
        /// Authority and issuer serial number mismatch
        /// </summary>
        AKID_ISSUER_SERIAL_MISMATCH = 31,

        /// <summary>
        /// Key usage does not include certificate signing
        /// </summary>
        KEYUSAGE_NO_CERTSIGN = 32,

        /// <summary>
        /// Unable to get CRL issuer certificate
        /// </summary>
        UNABLE_TO_GET_CRL_ISSUER = 33,

        /// <summary>
        /// Unhandled critical extension
        /// </summary>
        UNHANDLED_CRITICAL_EXTENSION = 34,

        /// <summary>
        /// Unknown certificate status
        /// </summary>
        CERT_UNKNOWN = 35
    }

    public enum SignatureReturnCode : int
    {
        /// <summary>
        /// The signature is not validated
        /// </summary>
        NOT_VALIDATED = -2,

        /// <summary>
        /// Error verifying the signature
        /// </summary>
        PROCESSING_ERROR = -1,

        /// <summary>
        /// The signature is valid
        /// </summary>
        VALID = 0,

        /// <summary>
        /// The signature is not valid
        /// </summary>
        INVALID = 1,

        /// <summary>
        /// The signature is valid and wrong RRN certificate
        /// </summary>
        VALID_WRONG_RRNCERT = 2,

        /// <summary>
        /// The signature is not valid and wrong RRN certificate
        /// </summary>
        INVALID_WRONG_RRNCERT = 3
    }

    public enum Policy : int
    {
        /// <summary>
        /// No policy used
        /// </summary>
        None = 0,

        /// <summary>
        /// OCSP policy used
        /// </summary>
        OCSP = 1,

        /// <summary>
        /// CRL policy used
        /// </summary>
        CRL = 2,

        /// <summary>
        /// OCSP and CRL policy used
        /// </summary>
        BOTH = 3
    }

    public enum OCSPFlag : int
    {
        /// <summary>
        /// OCSP Policy is Not Used
        /// </summary>
        NotUsed = 0,

        /// <summary>
        /// OCSP Policy is Optional
        /// </summary>
        Optional = 1,

        /// <summary>
        /// OCSP Policy is Mandatory
        /// </summary>
        Mandatory = 2
    }

    public enum CRLFlag : int
    {
        /// <summary>
        /// CRL Policy is Not Used
        /// </summary>
        NotUsed = 0,

        /// <summary>
        /// CRL Policy is Optional
        /// </summary>
        Optional = 1,

        /// <summary>
        /// CRL Policy is Mandatory
        /// </summary>
        Mandatory = 2
    }

    public enum PinType : int
    {
        PKCS15 = 0,
        OS = 1
    }

    public enum PinUsage : int
    {
        Authentication = 1,
        Signing = 2
    }
    #endregion Enumerations

    #region Structures
    [StructLayout(LayoutKind.Sequential)]
    public struct Status
    {
        /// <summary>
        /// General Error Code
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public ReturnCode General;

        /// <summary>
        /// System Error Code
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public int System;

        /// <summary>
        /// PC/SC Error Code
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public int PCSC;

        /// <summary>
        /// Card Status Word
        /// </summary>
        [MarshalAs(UnmanagedType.I2)]
        public short CardSW;

        /// <summary>
        /// Reserved for future use
        /// </summary>
        [MarshalAs(UnmanagedType.I2)]
        public short RFU1;
        [MarshalAs(UnmanagedType.I2)]
        public short RFU2;
        [MarshalAs(UnmanagedType.I2)]
        public short RFU3;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct Certif
    {
        /// <summary>
        /// byte stream encoded certificate 
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_CERT_LEN, ArraySubType = UnmanagedType.U1)]
        public byte[] certif;

        /// <summary>
        /// Size in bytes of the encoded certificate
        /// </summary>
        public int CertifLength;

        /// <summary>
        /// Label of the certificate (Authentication, Signature, CA, Root,�)
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_CERT_LABEL_LEN + 1, ArraySubType = UnmanagedType.I1)]
        public char[] CertifLabel;

        /// <summary>
        /// Validation status 			
        /// </summary>
        public int CertifStatus;

        /// <summary>
        /// Reserved for future use
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.U1)]
        public byte[] RFU;
    };

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct CertifCheck
    {
        /// <summary>
        /// Policy used
        /// </summary>
        public Policy UsedPolicy;

        /// <summary>
        /// Array of BEID_Certif structures
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_CERT_NUMBER)]
        public Certif[] Certificates;

        /// <summary>
        /// Number of elements in Array
        /// </summary>
        public int Length;

        /// <summary>
        /// Status of signature (for ID and Address) or hash (for Picture) on retrieved field
        /// </summary>
        public int SignatureCheck;

        /// <summary>
        /// Reserved for future use 
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.U1)]
        public byte[] RFU;
    };

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct Pin
    {
        /// <summary>
        /// The PinType
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public PinType PinType;

        /// <summary>
        /// PIN reference or ID
        /// </summary>
        [MarshalAs(UnmanagedType.U1)]
        public byte ID;

        /// <summary>
        /// Usage code
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public PinUsage UsageCode;

        /// <summary>
        /// May be NULL for usage known by the middleware
        /// </summary>
        [MarshalAs(UnmanagedType.LPStr)]
        public string ShortUsage;

        /// <summary>
        /// May be NULL for usage known by the middleware
        /// </summary>
        [MarshalAs(UnmanagedType.LPStr)]
        public string LongUsage;

        /// <summary>
        /// Reserved for future use
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.U1)]
        public byte[] RFU;
    };

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct PinInfo
    {
        /// <summary>
        /// PinType
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public PinType PinType;

        /// <summary>
        /// PIN reference or ID
        /// </summary>
        [MarshalAs(UnmanagedType.U1)]
        public byte ID;

        /// <summary>
        /// Usage code
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public PinUsage UsageCode;

        [MarshalAs(UnmanagedType.I4)]
        public int TriesLeft;

        [MarshalAs(UnmanagedType.I4)]
        public int Flags;

        [MarshalAs(UnmanagedType.LPStr)]
        public string Label;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.U1)]
        public byte[] RFU;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct Pins
    {
        /// <summary>
        /// Array of Pin structures
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_PINS)]
        public PinInfo[] pins;

        /// <summary>
        /// Number of elements in Array
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public int PinsLength;

        /// <summary>
        /// Reserved for future use
        /// </summary>
        public byte[] RFU;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct IDData
    {
        [MarshalAs(UnmanagedType.I2)]
        public short Version;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_CARD_NUMBER_LEN + 1)]
        public char[] CardNumber;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_CHIP_NUMBER_LEN + 1)]
        public char[] ChipNumber;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_DATE_BEGIN_LEN + 1)]
        public char[] ValidityDateBegin;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_DATE_END_LEN + 1)]
        public char[] ValidityDateEnd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_DELIVERY_MUNICIPALITY_LEN + 1)]
        public byte[] Municipality;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_NATIONAL_NUMBER_LEN + 1)]
        public char[] NationalNumber;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_NAME_LEN + 1)]
        public byte[] Name;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_FIRST_NAME1_LEN + 1)]
        public byte[] FirstName1;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_FIRST_NAME2_LEN + 1)]
        public byte[] FirstName2;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_FIRST_NAME3_LEN + 1)]
        public byte[] FirstName3;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_NATIONALITY_LEN + 1)]
        public char[] Nationality;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_BIRTHPLACE_LEN + 1)]
        public byte[] BirthLocation;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_BIRTHDATE_LEN + 1)]
        public char[] BirthDate;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_SEX_LEN + 1)]
        public char[] Sex;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_NOBLE_CONDITION_LEN + 1)]
        public byte[] NobleCondition;

        [MarshalAs(UnmanagedType.I4)]
        public int DocumentType;

        [MarshalAs(UnmanagedType.Bool)]
        public bool WhiteCane;

        [MarshalAs(UnmanagedType.Bool)]
        public bool YellowCane;

        [MarshalAs(UnmanagedType.Bool)]
        public bool ExtendedMinority;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_HASH_PICTURE_LEN, ArraySubType = UnmanagedType.U1)]
        public byte[] HashPhoto;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.U1)]
        public byte[] RFU;
    };

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct Address
    {
        [MarshalAs(UnmanagedType.U2)]
        public short Version;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_STREET_LEN + 1)]
        public byte[] Street;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_STREET_NR + 1)]
        public char[] StreetNumber;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_STREET_BOX_NR + 1)]
        public char[] BoxNumber;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_ZIP_LEN + 1)]
        public char[] Zip;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_MUNICIPALITY_LEN + 1)]
        public byte[] Municipality;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_COUNTRY_LEN + 1)]
        public char[] Country;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.U1)]
        public byte[] RFU;
    };

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct VersionInfo
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        public byte[] SerialNumber;

        [MarshalAs(UnmanagedType.U1)]
        public byte ComponentCode;

        [MarshalAs(UnmanagedType.U1)]
        public byte OSNumber;

        [MarshalAs(UnmanagedType.U1)]
        public byte OSVersion;

        [MarshalAs(UnmanagedType.U1)]
        public byte SoftmaskNumber;

        [MarshalAs(UnmanagedType.U1)]
        public byte SoftmaskVersion;

        [MarshalAs(UnmanagedType.U1)]
        public byte AppletVersion;

        [MarshalAs(UnmanagedType.U2)]
        public short GlobalOSVersion;

        [MarshalAs(UnmanagedType.U1)]
        public byte AppletInterfaceVersion;

        [MarshalAs(UnmanagedType.U1)]
        public byte PKCS1Support;

        [MarshalAs(UnmanagedType.U1)]
        public byte KeyExchangeVersion;

        [MarshalAs(UnmanagedType.U1)]
        public byte ApplicationLifeCycle;

        [MarshalAs(UnmanagedType.U1)]
        public byte GraphPerso;

        [MarshalAs(UnmanagedType.U1)]
        public byte ElecPerso;

        [MarshalAs(UnmanagedType.U1)]
        public byte ElecPersoInterface;

        [MarshalAs(UnmanagedType.U1)]
        public byte Reserved;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.U1)]
        public byte[] RFU;
    }

    [StructLayout(LayoutKind.Sequential)]
    public class Bytes
    {
        public BytePtr Data;

        [MarshalAs(UnmanagedType.U4)]
        public int Length;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.U1)]
        public byte[] RFU;

        public Bytes(int length)
        {
            this.Data = new BytePtr(length);
            this.Length = length;
            this.RFU = new byte[6];
        }

        public Bytes(byte[] data)
        {
            this.Data = new BytePtr(data);
            this.Length = data.Length;
            this.RFU = new byte[6];
        }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct Raw
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_RAW_ID_LEN, ArraySubType = UnmanagedType.U1)]
        byte[] idData;

        [MarshalAs(UnmanagedType.I4)]
        int IdLength;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_SIGNATURE_LEN, ArraySubType = UnmanagedType.U1)]
        byte[] IdSigData;

        [MarshalAs(UnmanagedType.I4)]
        int IdSigLength;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_RAW_ADDRESS_LEN, ArraySubType = UnmanagedType.U1)]
        byte[] AddrData;

        [MarshalAs(UnmanagedType.I4)]
        int AddrLength;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_SIGNATURE_LEN, ArraySubType = UnmanagedType.U1)]
        byte[] AddrSigData;

        [MarshalAs(UnmanagedType.I4)]
        int AddrSighLength;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_PICTURE_LEN, ArraySubType = UnmanagedType.U1)]
        byte[] PictureData;

        [MarshalAs(UnmanagedType.I4)]
        int PictureLength;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_CARD_DATA_SIG_LEN, ArraySubType = UnmanagedType.U1)]
        byte[] CardData;

        [MarshalAs(UnmanagedType.I4)]
        int CardDataLength;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_SIGNATURE_LEN, ArraySubType = UnmanagedType.U1)]
        byte[] TokenInfo;

        [MarshalAs(UnmanagedType.I4)]
        int TokenInfoLength;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_CERT_LEN, ArraySubType = UnmanagedType.U1)]
        byte[] CertRN;

        [MarshalAs(UnmanagedType.I4)]
        int CertRNLength;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_CHALLENGE_LEN, ArraySubType = UnmanagedType.U1)]
        byte[] Challenge;

        [MarshalAs(UnmanagedType.I4)]
        int ChallengeLength;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = EidLib.MAX_RESPONSE_LEN, ArraySubType = UnmanagedType.U1)]
        byte[] Response;

        [MarshalAs(UnmanagedType.I4)]
        int ResponseLength;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.U1)]
        byte[] RFU;
    }
    #endregion Structures

    public class EidLib
    {
        #region Constants
        public const string BEID_DLL = "Eidlib.dll";

        public const int INTERFACE_VERSION = 2;
        public const int INTERFACE_COMPAT_VERSION = 1;

        public const int MAX_CARD_NUMBER_LEN = 12;
        public const int MAX_CHIP_NUMBER_LEN = 32;
        public const int MAX_DATE_BEGIN_LEN = 10;
        public const int MAX_DATE_END_LEN = 10;
        public const int MAX_DELIVERY_MUNICIPALITY_LEN = 80;
        public const int MAX_NATIONAL_NUMBER_LEN = 11;
        public const int MAX_NAME_LEN = 110;
        public const int MAX_FIRST_NAME1_LEN = 95;
        public const int MAX_FIRST_NAME2_LEN = 50;
        public const int MAX_FIRST_NAME3_LEN = 3;
        public const int MAX_NATIONALITY_LEN = 3;
        public const int MAX_BIRTHPLACE_LEN = 80;
        public const int MAX_BIRTHDATE_LEN = 10;
        public const int MAX_SEX_LEN = 1;
        public const int MAX_NOBLE_CONDITION_LEN = 50;
        public const int MAX_DOCUMENT_TYPE_LEN = 2;
        public const int MAX_SPECIAL_STATUS_LEN = 2;
        public const int MAX_HASH_PICTURE_LEN = 20;

        public const int MAX_STREET_LEN = 80;
        public const int MAX_STREET_NR = 10;
        public const int MAX_STREET_BOX_NR = 6;
        public const int MAX_ZIP_LEN = 4;
        public const int MAX_MUNICIPALITY_LEN = 67;
        public const int MAX_COUNTRY_LEN = 4;

        public const int MAX_RAW_ADDRESS_LEN = 512;
        public const int MAX_RAW_ID_LEN = 1024;
        public const int MAX_PICTURE_LEN = 4096;
        public const int MAX_CERT_LEN = 2048;
        public const int MAX_CERT_NUMBER = 10;
        public const int MAX_CERT_LABEL_LEN = 256;
        public const int MAX_SIGNATURE_LEN = 256;
        public const int MAX_CARD_DATA_LEN = 28;
        public const int MAX_CARD_DATA_SIG_LEN = MAX_SIGNATURE_LEN + MAX_CARD_DATA_LEN;
        public const int MAX_CHALLENGE_LEN = 20;
        public const int MAX_RESPONSE_LEN = 128;
        public const int MAX_PINS = 3;
        public const int MAX_PIN_LABEL_LEN = 256;
        #endregion Constants

        #region High Level API
        public static Status Init(string readerName, OCSPFlag ocsp, CRLFlag crl, out IntPtr cardHandle)
        {
            return InitEx(readerName, ocsp, crl, out cardHandle, INTERFACE_VERSION, INTERFACE_COMPAT_VERSION);
        }

        [DllImport(BEID_DLL, EntryPoint = "BEID_InitEx", SetLastError = true)]
        public static extern Status InitEx(string readerName, OCSPFlag ocsp, CRLFlag crl, out IntPtr cardHandle, int interfaceVersion, int interfaceCompVersion);

        [DllImport(BEID_DLL, EntryPoint = "BEID_Exit", SetLastError = true)]
        public static extern Status Exit();

        [DllImport(BEID_DLL, EntryPoint = "BEID_GetID", SetLastError = true)]
        public static extern Status GetID(out IDData data, out CertifCheck check);

        [DllImport(BEID_DLL, EntryPoint = "BEID_GetAddress", SetLastError = true)]
        public static extern Status GetAddress(out Address address, out CertifCheck check);

        [DllImport(BEID_DLL, EntryPoint = "BEID_GetPicture", SetLastError = true)]
        public static extern Status GetPicture(Bytes picture, out CertifCheck check);

        [DllImport(BEID_DLL, EntryPoint = "BEID_GetRawData", SetLastError = true)]
        public static extern Status GetRawData(out Raw rawData);

        [DllImport(BEID_DLL, EntryPoint = "BEID_SetRawData", SetLastError = true)]
        public static extern Status SetRawData(Raw rawData);

        [DllImport(BEID_DLL, EntryPoint = "BEID_GetCertificates", SetLastError = true)]
        public static extern Status GetCertificates(out CertifCheck certifCheck);

        [DllImport(BEID_DLL, EntryPoint = "BEID_GetRawFile", SetLastError = true)]
        public static extern Status GetRawFile(Bytes rawFile);

        [DllImport(BEID_DLL, EntryPoint = "BEID_setRawFile", SetLastError = true)]
        public static extern Status SetRawFile(Bytes rawFile);
        #endregion High Level API

        #region Mid Level API
        [DllImport(BEID_DLL, EntryPoint = "BEID_GetVersionInfo", SetLastError = true)]
        public static extern Status GetVersionInfo(ref VersionInfo versionInfo, bool signature, Bytes SignedStatus);

        [DllImport(BEID_DLL, EntryPoint = "BEID_BeginTransaction", SetLastError = true)]
        public static extern Status BeginTransaction();

        [DllImport(BEID_DLL, EntryPoint = "BEID_EndTransaction", SetLastError = true)]
        public static extern Status EndTransaction();

        [DllImport(BEID_DLL, EntryPoint = "BEID_SelectApplication", SetLastError = true)]
        public static extern Status SelectApplication(Bytes Application);

        [DllImport(BEID_DLL, EntryPoint = "BEID_VerifyPIN", SetLastError = true)]
        public static extern Status VerifyPIN(ref Pin pinData, string pin, out int triesLeft);

        [DllImport(BEID_DLL, EntryPoint = "BEID_ChangePIN", SetLastError = true)]
        public static extern Status ChangePin(ref Pin pinData, string oldPin, string newPin, out int triesLeft);

        [DllImport(BEID_DLL, EntryPoint = "BEID_GetPINStatus", SetLastError = true)]
        public static extern Status GetPinStatus(ref Pin pinData, out int triesLeft, bool signature, out Bytes signedStatus);

        [DllImport(BEID_DLL, EntryPoint = "BEID_ReadFile", SetLastError = true)]
        public static extern Status ReadFile(Bytes fileID, Bytes outData, ref Pin pinData);

        [DllImport(BEID_DLL, EntryPoint = "BEID_WriteFile", SetLastError = true)]
        public static extern Status WriteFile(Bytes fileID, Bytes inData, ref Pin pinData);

        [DllImport(BEID_DLL, EntryPoint = "BEID_GetPINs", SetLastError = true)]
        public static extern Status GetPINs(out Pins pins);

        [DllImport(BEID_DLL, EntryPoint = "BEID_Certif_Check", SetLastError = true)]
        public static extern Status VerifyCRL(CertifCheck certifCheck, bool download);

        [DllImport(BEID_DLL, EntryPoint = "BEID_Cetif_Check", SetLastError = true)]
        public static extern Status VerifyOCSP(CertifCheck certifCheck);
        #endregion Mid Level API

        #region Low Level API
        [DllImport(BEID_DLL, EntryPoint = "BEID_FlushCache", SetLastError = true)]
        public static extern Status FlushCache();

        [DllImport(BEID_DLL, EntryPoint = "BEID_SendAPDU", SetLastError = true)]
        public static extern Status SendAPDU(Bytes cmdAPDU, ref Pin pinData, Bytes respAPDU);

        [DllImport(BEID_DLL, EntryPoint = "BEID_ReadBinary", SetLastError = true)]
        public static extern Status ReadBinary(Bytes fileID, int iOffset, int iCount, Bytes outData);
        #endregion Low Level API
    }
}
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace eID.SmartCardAPI
{
    #region Enumerations
    public enum ReturnCode : int
    {
        NO_ERROR = 0
    }

    public enum Scope : int
    {
        /// <summary>
        /// The context is a user context, and any
        /// database operations are performed within the
        /// domain of the user
        /// </summary>
        User = 0,

        /// <summary>
        /// The context is that of the current terminal,
        /// and any database operations are performed
        /// within the domain of that terminal.  (The
        /// calling application must have appropriate
        /// access permissions for any database actions.)
        /// </summary>
        Terminal = 1,

        /// <summary>
        /// The context is the system context, and any 
        /// database operations are performed within the
        /// domain of the system.  (The calling
        /// application must have appropriate access
        /// </summary>
        System = 2
    }
    #endregion Enumerations

    public class SCard
    {
        #region Constants
        public const string WINSCARD_DLL = "winscard.dll";
        #endregion

        #region Imports
        [DllImport(WINSCARD_DLL, EntryPoint = "SCardEstablishContext", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern ReturnCode EstablishContext(Scope scope, IntPtr pvReserved1, IntPtr pvReserved2, ref IntPtr context);

        [DllImport(WINSCARD_DLL, EntryPoint = "SCardReleaseContext", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern ReturnCode ReleaseContext(IntPtr context);

        [DllImport(WINSCARD_DLL, EntryPoint = "SCardListReaders", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern ReturnCode ListReaders(IntPtr context, string groups, string readers, ref int size);
        #endregion Imports

        #region Methods
        public static List<String> GetReaderNames()
        {
            List<String> readers = new List<String>();

            IntPtr context = IntPtr.Zero;
            if (EstablishContext(Scope.User, IntPtr.Zero, IntPtr.Zero, ref context) == ReturnCode.NO_ERROR)
            {
                int size = 2048;
                if (ListReaders(context, null, null, ref size) == ReturnCode.NO_ERROR)
                {
                    string names = new string(' ', size);
                    if (ListReaders(context, null, names, ref size) == ReturnCode.NO_ERROR)
                    {
                        while (names.Length > 0)
                        {
                            int end = names.IndexOf('\0');
                            if (end != -1)
                            {
                                string reader = names.Substring(0, end);
                                if (reader.Length > 0)
                                {
                                    readers.Add(reader);
                                }
                            }
                            names = names.Substring(end + 1);
                        }
                    }
                }

                ReleaseContext(context);
                context = IntPtr.Zero;
            }

            return readers;
        }
        #endregion Methods
    }
}
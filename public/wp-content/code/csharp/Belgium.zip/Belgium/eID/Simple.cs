using System;
using System.Drawing;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using eID.API;
using eID.SmartCardAPI;

namespace eID.Simple
{
    public class Reader : IDisposable
    {
        private static Dictionary<string, Reader> readers;

        private bool disposed;
        private String readerName;
        private IntPtr handle;
        private Image image;
        private bool haveData;
        private IDData data;
        private bool haveAddress;
        private Address address;
        private UTF8Encoding utf8;

        /// <summary>
        /// Returns a list with names of available SmartCard readers
        /// </summary>
        /// <returns></returns>
        public static List<string> GetReaderNames()
        {
            return SCard.GetReaderNames();
        }

        /// <summary>
        /// Returns a Reader instance attached to the default reader device
        /// </summary>
        /// <returns></returns>
        public static Reader GetReader()
        {
            return GetReader("");
        }

        /// <summary>
        /// Returns a Reader instance attached to the given reader device
        /// </summary>
        /// <param name="readerName"></param>
        /// <returns></returns>
        public static Reader GetReader(string readerName)
        {
            if (readers == null)
            {
                readers = new Dictionary<string, Reader>();
            }

            Reader reader;
            if (!readers.TryGetValue(readerName, out reader))
            {
                reader = new Reader(readerName);
            }

            return reader;
        }

        /// <summary>
        /// Constructor (use the factory to get an intance)
        /// </summary>
        /// <param name="readerName"></param>
        private Reader(string readerName)
        {
            this.disposed = false;
            this.readerName = readerName;
            this.haveData = false;
            this.haveAddress = false;
            this.utf8 = new UTF8Encoding();

            if (EidLib.Init(readerName, OCSPFlag.Mandatory, CRLFlag.Optional, out handle).General != eID.API.ReturnCode.OK)
            {
                throw new Exception("Could not initialize reader");
            }

            if (EidLib.BeginTransaction().General != eID.API.ReturnCode.OK)
            {
                throw new Exception("Could not start transaction");
            }
        }

        /// <summary>
        /// Fetches the ID Data from the eID card
        /// </summary>
        private void GetData()
        {
            if (!haveData)
            {
                CertifCheck check;
                if (EidLib.GetID(out data, out check).General != eID.API.ReturnCode.OK)
                {
                    throw new Exception("Could not fetch iddata");
                }
                haveData = true;
            }
        }

        /// <summary>
        /// Fetches the Address Data from the eID card
        /// </summary>
        private void GetAddress()
        {
            if (!haveAddress)
            {
                CertifCheck check;
                if (EidLib.GetAddress(out address, out check).General != eID.API.ReturnCode.OK)
                {
                    throw new Exception("Could not fetch address data");
                }
                haveAddress = true;
            }
        }

        /// <summary>
        /// Returns the image on the eID card
        /// </summary>
        /// <returns></returns>
        public Image GetImage()
        {
            if (image == null)
            {
                Bytes bytes = new Bytes(EidLib.MAX_PICTURE_LEN);
                CertifCheck check;
                if (EidLib.GetPicture(bytes, out check).General == eID.API.ReturnCode.OK)
                {
                    MemoryStream ms = new MemoryStream(bytes.Data.ToArray(bytes.Length));
                    image = Image.FromStream(ms);
                    ms = null;
                }
                else
                {
                    throw new Exception("Could not fetch image");
                }
            }

            return image;
        }

        public string GetCardNumber()
        {
            GetData();
            return new string(data.CardNumber).TrimEnd();
        }

        public string GetChipNumber()
        {
            GetData();
            return new string(data.ChipNumber).TrimEnd();
        }

        public DateTime GetValidityDateBegin()
        {
            GetData();
            string date = new string(data.ValidityDateBegin);
            return new DateTime(Int32.Parse(date.Substring(0, 4)), Int32.Parse(date.Substring(4, 2)), Int32.Parse(date.Substring(6, 2)));
  
        }

        public DateTime GetValidityDateEnd()
        {
            GetData();
            string date = new string(data.ValidityDateEnd);
            return new DateTime(Int32.Parse(date.Substring(0, 4)), Int32.Parse(date.Substring(4, 2)), Int32.Parse(date.Substring(6, 2)));
  
        }

        public string GetCardDeliveryMunicipality()
        {
            GetData();
            return utf8.GetString(data.Municipality).TrimEnd();
        }

        public string GetNationalNumber()
        {
            GetData();
            return new String(data.NationalNumber).TrimEnd();
        }

        public string GetName()
        {
            GetData();
            return utf8.GetString(data.Name).TrimEnd();
        }

        public string GetFirstName1()
        {
            GetData();
            return utf8.GetString(data.FirstName1).TrimEnd();
        }

        public string GetFirstName2()
        {
            GetData();
            return utf8.GetString(data.FirstName2).TrimEnd();
        }

        public string GetFirstName3()
        {
            GetData();
            return utf8.GetString(data.FirstName3).TrimEnd();
        }

        public string GetNationality()
        {
            GetData();
            return new string(data.Nationality).TrimEnd();
        }

        public string GetBirthLocation()
        {
            GetData();
            return utf8.GetString(data.BirthLocation).TrimEnd();
        }

        public DateTime GetBirthDate()
        {
            GetData();
            string date = new string(data.BirthDate);
            return new DateTime(Int32.Parse(date.Substring(0, 4)), Int32.Parse(date.Substring(4, 2)), Int32.Parse(date.Substring(6, 2)));
        }

        public string GetSex()
        {
            GetData();
            return new String(data.Sex).TrimEnd();
        }

        public string GetNobleCondition()
        {
            GetData();
            return utf8.GetString(data.NobleCondition).TrimEnd();
        }

        public int GetDocumentType()
        {
            GetData();
            return data.DocumentType;
        }

        public bool WhiteCane()
        {
            GetData();
            return data.WhiteCane;
        }

        public bool GetYellowCane()
        {
            GetData();
            return data.YellowCane;
        }

        public bool GetExtendedMinority()
        {
            GetData();
            return data.ExtendedMinority;
        }

        public string GetStreet()
        {
            GetAddress();
            return utf8.GetString(address.Street).TrimEnd();
        }

        public string GetStreetNumber()
        {
            GetAddress();
            return new string(address.StreetNumber).TrimEnd();
        }

        public string GetBoxNumber()
        {
            GetAddress();
            return new string(address.BoxNumber).TrimEnd();
        }

        public string GetZip()
        {
            GetAddress();
            return new string(address.Zip).TrimEnd();
        }

        public string GetMunicipality()
        {
            GetAddress();
            return utf8.GetString(address.Municipality).TrimEnd();
        }

        public string GetCountry()
        {
            GetAddress();
            return new string(address.Country).TrimEnd();
        }

        /// <summary>
        /// Dispose resources
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing) {
            if (!disposed) {
                if (disposing) {
                    if (EidLib.EndTransaction().General != eID.API.ReturnCode.OK)
                    {
                        throw new Exception("Could not end transaction");
                    }

                    if (EidLib.Exit().General != eID.API.ReturnCode.OK)
                    {
                        throw new Exception("Could not exit reader");
                    }

                    readers.Remove(this.readerName);
                }
            }
        }

        /// <summary>
        /// Implementation of IDisposable.Dispose
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace eID.Interop
{
    public struct StringPtr : IDisposable
    {
        private IntPtr data;

        public StringPtr(string data)
        {
            this.data = (data == null) ? IntPtr.Zero : Memory.StringToHLocalUni(data);
        }

        public override string ToString()
        {
            return Marshal.PtrToStringUni(this.data);
        }

        public void Free()
        {
            Memory.FreeHLocal(this.data);
        }

        public static StringPtr Zero
        {
            get
            {
                return new StringPtr(null);
            }
        }

        public static bool operator ==(StringPtr v1, StringPtr v2)
        {
            return v1.Equals(v2);
        }

        public static bool operator !=(StringPtr v1, StringPtr v2)
        {
            return !v1.Equals(v2);
        }
        public override bool Equals(object obj)
        {
            return ((obj is StringPtr) && ((StringPtr)obj).data.Equals(this.data));
        }

        public override int GetHashCode()
        {
            return data.GetHashCode();
        }

        public static void Free(StringPtr ptr)
        {
            if (StringPtr.Zero != ptr)
            {
                ptr.Free();
            }
        }

        public void Dispose()
        {
            Free();
        }
    }

    public struct BytePtr
    {
        private IntPtr data;

        public BytePtr(byte[] data)
            : this((data != null) ? data : null, 0, (data != null) ? data.Length : 0)
        {
            //
        }

        public BytePtr(byte[] data, int offset, int count)
        {
            this.data = (data == null) ? IntPtr.Zero : Memory.ByteToHLocal(data, offset, count);
        }


        public BytePtr(int size)
        {
            this.data = Memory.AllocHLocal(size);
        }

        public override string ToString()
        {
            return data.ToString();
        }

        public IntPtr Handle
        {
            get
            {
                return this.data;
            }
        }

        public void Free()
        {
            Memory.FreeHLocal(this.data);
        }

        public static BytePtr Zero
        {
            get
            {
                return new BytePtr(null);
            }
        }

        public static bool operator ==(BytePtr v1, BytePtr v2)
        {
            return v1.Equals(v2);
        }

        public static bool operator !=(BytePtr v1, BytePtr v2)
        {
            return !v1.Equals(v2);
        }

        public override bool Equals(object obj)
        {
            return ((obj is BytePtr) && ((BytePtr)obj).data.Equals(this.data));
        }

        public override int GetHashCode()
        {
            return data.GetHashCode();
        }

        public static void Free(BytePtr ptr)
        {
            if (BytePtr.Zero != ptr)
            {
                ptr.Free();
            }
        }

        public static byte[] Free(BytePtr ptr, int length)
        {
            byte[] result = null;

            if (BytePtr.Zero != ptr)
            {
                result = ptr.ToArray(length);
                ptr.Free();
            }

            return result;
        }

        public byte[] ToArray(int length)
        {
            byte[] result = null;

            if (this.data != IntPtr.Zero)
            {
                result = new byte[length];
                Marshal.Copy(this.data, result, 0, Convert.ToInt32(length));
            }

            return result;
        }

        public void Dispose()
        {
            Free();
        }
    }

    public class Memory
    {
        #region Constants
        public const String Kernel32_DLL = "kernel32.dll";
        #endregion

        #region Enumerations
        public enum AllocationFlags : int
        {
            Fixed = 0,
            Movable = 2,
            ZeroInit = 0x40,
            FixedZeroInit = (Fixed + ZeroInit)
        }
        #endregion

        #region Imports
        [DllImport(Kernel32_DLL, SetLastError = true)]
        private static extern IntPtr LocalAlloc(AllocationFlags flags, int bytes);

        [DllImport(Kernel32_DLL, SetLastError = true)]
        private static extern IntPtr LocalFree(IntPtr handle);

        [DllImport(Kernel32_DLL, SetLastError = true)]
        private static extern IntPtr LocalReAlloc(IntPtr handle, int bytes, AllocationFlags flags);
        #endregion

        #region Methods
        public static IntPtr AllocHLocal(int cb)
        {
            return LocalAlloc(AllocationFlags.FixedZeroInit, cb);
        }

        public static void FreeHLocal(IntPtr handle)
        {
            if (!handle.Equals(IntPtr.Zero))
            {
                if (!IntPtr.Zero.Equals(LocalFree(handle)))
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }
                else
                {
                    handle = IntPtr.Zero;
                }
            }
        }

        public static IntPtr ReAllocHLocal(IntPtr pv, int cb)
        {
            IntPtr newMem = LocalReAlloc(pv, cb, AllocationFlags.Movable);

            if (newMem.Equals(IntPtr.Zero))
            {
                throw new OutOfMemoryException();
            }

            return newMem;
        }

        public static IntPtr StringToHLocalUni(string s)
        {
            if (s == null)
            {
                return IntPtr.Zero;
            }
            else
            {
                int nc = s.Length;
                int length = 2 * (1 + nc);

                IntPtr handle = AllocHLocal(length);
                if (handle.Equals(IntPtr.Zero))
                {
                    throw new OutOfMemoryException();
                }
                else
                {
                    Marshal.Copy(s.ToCharArray(), 0, handle, s.Length);
                    return handle;
                }
            }
        }

        public static IntPtr ByteToHLocal(byte[] data, int offset, int count)
        {
            if (data == null)
            {
                return IntPtr.Zero;
            }
            else
            {
                IntPtr handle = AllocHLocal(count);
                if (handle.Equals(IntPtr.Zero))
                {
                    throw new OutOfMemoryException();
                }
                else
                {
                    Marshal.Copy(data, offset, handle, count);
                    return handle;
                }
            }
        }
        #endregion
    }
}
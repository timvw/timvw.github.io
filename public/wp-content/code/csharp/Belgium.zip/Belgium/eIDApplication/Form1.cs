using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using eID.Simple;

namespace eIDApplication
{
    public partial class Form1 : Form
    {
        private Reader reader;

        public Form1()
        {
            InitializeComponent();
            Initialize();
        }

        private void Initialize()
        {
            reader = Reader.GetReader();
            pictureBox1.Image = reader.GetImage();
            labelName.Text = reader.GetName();
            labelGivenNames.Text = reader.GetFirstName1() + reader.GetFirstName2() + reader.GetFirstName3();
            dateTimePicker1.Value = reader.GetBirthDate();
        }
    }
}
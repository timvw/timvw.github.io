﻿namespace Be.TimVW.WorkItemTrackingTool
{
    partial class WorkItemTrackerView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePickerBegin = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerEnd = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.dataGridViewUsernames = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.dataGridViewWorkItems = new System.Windows.Forms.DataGridView();
            this.ColumnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workItemFormControl1 = new Microsoft.TeamFoundation.WorkItemTracking.Controls.WorkItemFormControl();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            ( (System.ComponentModel.ISupportInitialize) ( this.dataGridViewUsernames ) ).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ( (System.ComponentModel.ISupportInitialize) ( this.dataGridViewWorkItems ) ).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point( 3, 13 );
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size( 63, 13 );
            this.label1.TabIndex = 0;
            this.label1.Text = "Usernames:";
            // 
            // label2
            // 
            this.label2.Anchor = ( (System.Windows.Forms.AnchorStyles) ( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left ) ) );
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point( 16, 479 );
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size( 37, 13 );
            this.label2.TabIndex = 1;
            this.label2.Text = "Begin:";
            // 
            // dateTimePickerBegin
            // 
            this.dateTimePickerBegin.Anchor = ( (System.Windows.Forms.AnchorStyles) ( ( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left )
                        | System.Windows.Forms.AnchorStyles.Right ) ) );
            this.dateTimePickerBegin.Location = new System.Drawing.Point( 85, 475 );
            this.dateTimePickerBegin.Name = "dateTimePickerBegin";
            this.dateTimePickerBegin.Size = new System.Drawing.Size( 260, 20 );
            this.dateTimePickerBegin.TabIndex = 3;
            // 
            // dateTimePickerEnd
            // 
            this.dateTimePickerEnd.Anchor = ( (System.Windows.Forms.AnchorStyles) ( ( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left )
                        | System.Windows.Forms.AnchorStyles.Right ) ) );
            this.dateTimePickerEnd.Location = new System.Drawing.Point( 85, 501 );
            this.dateTimePickerEnd.Name = "dateTimePickerEnd";
            this.dateTimePickerEnd.Size = new System.Drawing.Size( 260, 20 );
            this.dateTimePickerEnd.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.Anchor = ( (System.Windows.Forms.AnchorStyles) ( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left ) ) );
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point( 16, 505 );
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size( 29, 13 );
            this.label3.TabIndex = 5;
            this.label3.Text = "End:";
            // 
            // buttonSearch
            // 
            this.buttonSearch.Anchor = ( (System.Windows.Forms.AnchorStyles) ( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
            this.buttonSearch.BackColor = System.Drawing.SystemColors.Control;
            this.buttonSearch.Location = new System.Drawing.Point( 267, 536 );
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size( 78, 24 );
            this.buttonSearch.TabIndex = 6;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = false;
            this.buttonSearch.Click += new System.EventHandler( this.buttonSearch_Click );
            // 
            // dataGridViewUsernames
            // 
            this.dataGridViewUsernames.Anchor = ( (System.Windows.Forms.AnchorStyles) ( ( ( ( System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom )
                        | System.Windows.Forms.AnchorStyles.Left )
                        | System.Windows.Forms.AnchorStyles.Right ) ) );
            this.dataGridViewUsernames.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewUsernames.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUsernames.Columns.AddRange( new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1} );
            this.dataGridViewUsernames.Location = new System.Drawing.Point( 85, 13 );
            this.dataGridViewUsernames.Name = "dataGridViewUsernames";
            this.dataGridViewUsernames.Size = new System.Drawing.Size( 260, 448 );
            this.dataGridViewUsernames.TabIndex = 7;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "";
            this.Column1.Name = "Column1";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point( 0, 0 );
            this.splitContainer1.Margin = new System.Windows.Forms.Padding( 0 );
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.splitContainer1.Panel1.Controls.Add( this.panel1 );
            this.splitContainer1.Panel1.Margin = new System.Windows.Forms.Padding( 3 );
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add( this.splitContainer2 );
            this.splitContainer1.Panel2.Margin = new System.Windows.Forms.Padding( 3 );
            this.splitContainer1.Size = new System.Drawing.Size( 937, 768 );
            this.splitContainer1.SplitterDistance = 385;
            this.splitContainer1.SplitterWidth = 10;
            this.splitContainer1.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Anchor = ( (System.Windows.Forms.AnchorStyles) ( ( ( ( System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom )
                        | System.Windows.Forms.AnchorStyles.Left )
                        | System.Windows.Forms.AnchorStyles.Right ) ) );
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add( this.label1 );
            this.panel1.Controls.Add( this.label3 );
            this.panel1.Controls.Add( this.buttonSearch );
            this.panel1.Controls.Add( this.label2 );
            this.panel1.Controls.Add( this.dateTimePickerEnd );
            this.panel1.Controls.Add( this.dataGridViewUsernames );
            this.panel1.Controls.Add( this.dateTimePickerBegin );
            this.panel1.Location = new System.Drawing.Point( 12, 12 );
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size( 356, 583 );
            this.panel1.TabIndex = 10;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point( 0, 0 );
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add( this.dataGridViewWorkItems );
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add( this.workItemFormControl1 );
            this.splitContainer2.Size = new System.Drawing.Size( 542, 768 );
            this.splitContainer2.SplitterDistance = 240;
            this.splitContainer2.SplitterWidth = 10;
            this.splitContainer2.TabIndex = 0;
            // 
            // dataGridViewWorkItems
            // 
            this.dataGridViewWorkItems.AllowUserToAddRows = false;
            this.dataGridViewWorkItems.AllowUserToDeleteRows = false;
            this.dataGridViewWorkItems.AllowUserToOrderColumns = true;
            this.dataGridViewWorkItems.Anchor = ( (System.Windows.Forms.AnchorStyles) ( ( ( ( System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom )
                        | System.Windows.Forms.AnchorStyles.Left )
                        | System.Windows.Forms.AnchorStyles.Right ) ) );
            this.dataGridViewWorkItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWorkItems.Columns.AddRange( new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnID,
            this.ColumnState,
            this.ColumnTitle} );
            this.dataGridViewWorkItems.Location = new System.Drawing.Point( 0, 0 );
            this.dataGridViewWorkItems.MultiSelect = false;
            this.dataGridViewWorkItems.Name = "dataGridViewWorkItems";
            this.dataGridViewWorkItems.ReadOnly = true;
            this.dataGridViewWorkItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewWorkItems.Size = new System.Drawing.Size( 530, 237 );
            this.dataGridViewWorkItems.TabIndex = 0;
            this.dataGridViewWorkItems.SelectionChanged += new System.EventHandler( this.dataGridViewWorkItems_SelectionChanged );
            // 
            // ColumnID
            // 
            this.ColumnID.FillWeight = 50F;
            this.ColumnID.HeaderText = "ID";
            this.ColumnID.Name = "ColumnID";
            this.ColumnID.ReadOnly = true;
            this.ColumnID.Width = 50;
            // 
            // ColumnState
            // 
            this.ColumnState.FillWeight = 75F;
            this.ColumnState.HeaderText = "State";
            this.ColumnState.Name = "ColumnState";
            this.ColumnState.ReadOnly = true;
            this.ColumnState.Width = 75;
            // 
            // ColumnTitle
            // 
            this.ColumnTitle.FillWeight = 450F;
            this.ColumnTitle.HeaderText = "Title";
            this.ColumnTitle.Name = "ColumnTitle";
            this.ColumnTitle.ReadOnly = true;
            this.ColumnTitle.Width = 450;
            // 
            // workItemFormControl1
            // 
            this.workItemFormControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.workItemFormControl1.FormDefinition = null;
            this.workItemFormControl1.Item = null;
            this.workItemFormControl1.LayoutTargetName = "";
            this.workItemFormControl1.Location = new System.Drawing.Point( 0, 0 );
            this.workItemFormControl1.Name = "workItemFormControl1";
            this.workItemFormControl1.ReadOnly = false;
            this.workItemFormControl1.ServiceProvider = null;
            this.workItemFormControl1.Size = new System.Drawing.Size( 542, 518 );
            this.workItemFormControl1.TabIndex = 0;
            this.workItemFormControl1.UserActionRequiredBackColor = System.Drawing.SystemColors.Info;
            this.workItemFormControl1.UserActionRequiredForeColor = System.Drawing.SystemColors.InfoText;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange( new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripProgressBar1} );
            this.statusStrip1.Location = new System.Drawing.Point( 0, 746 );
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size( 937, 22 );
            this.statusStrip1.TabIndex = 11;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size( 109, 17 );
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Visible = false;
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size( 100, 16 );
            this.toolStripProgressBar1.Visible = false;
            // 
            // WorkItemTrackerView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF( 6F, 13F );
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size( 937, 768 );
            this.Controls.Add( this.statusStrip1 );
            this.Controls.Add( this.splitContainer1 );
            this.Name = "WorkItemTrackerView";
            this.Text = "WorkItemTracker";
            ( (System.ComponentModel.ISupportInitialize) ( this.dataGridViewUsernames ) ).EndInit();
            this.splitContainer1.Panel1.ResumeLayout( false );
            this.splitContainer1.Panel2.ResumeLayout( false );
            this.splitContainer1.ResumeLayout( false );
            this.panel1.ResumeLayout( false );
            this.panel1.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout( false );
            this.splitContainer2.Panel2.ResumeLayout( false );
            this.splitContainer2.ResumeLayout( false );
            ( (System.ComponentModel.ISupportInitialize) ( this.dataGridViewWorkItems ) ).EndInit();
            this.statusStrip1.ResumeLayout( false );
            this.statusStrip1.PerformLayout();
            this.ResumeLayout( false );
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePickerBegin;
        private System.Windows.Forms.DateTimePicker dateTimePickerEnd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.DataGridView dataGridViewUsernames;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.DataGridView dataGridViewWorkItems;
        private Microsoft.TeamFoundation.WorkItemTracking.Controls.WorkItemFormControl workItemFormControl1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnState;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTitle;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}


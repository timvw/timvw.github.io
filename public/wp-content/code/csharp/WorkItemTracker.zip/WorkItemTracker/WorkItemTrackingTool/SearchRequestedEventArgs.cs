using System;
using System.Collections.Generic;

namespace Be.TimVW.WorkItemTrackingTool
{
    public class SearchRequestedEventArgs : EventArgs
    {
        private List<string> usernames;
        private DateTime begin;
        private DateTime end;

        public SearchRequestedEventArgs( List<string> usernames, DateTime begin, DateTime end )
        {
            this.usernames = usernames;
            this.begin = begin;
            this.end = end;
        }

        public List<string> Usernames
        {
            get { return usernames; }
        }

        public DateTime Begin
        {
            get { return begin; }
        }

        public DateTime End
        {
            get { return end; }
        }
    }
}

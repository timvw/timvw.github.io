﻿using System;
using System.Windows.Forms;

namespace Be.TimVW.WorkItemTrackingTool
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault( false );

            WorkItemTrackerView view = new WorkItemTrackerView();
            new WorkItemTrackerPresenter( view );
            Application.Run( view );
        }
    }
}

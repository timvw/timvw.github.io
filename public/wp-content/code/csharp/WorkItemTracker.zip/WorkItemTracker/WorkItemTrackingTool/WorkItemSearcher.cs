﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.Client;

namespace Be.TimVW.WorkItemTrackingTool
{
    public class WorkItemSearcher
    {
        private TeamFoundationServer teamFoundationServer;
        private WorkItemStore workItemStore;

        public WorkItemSearcher(string name)
        {
            this.teamFoundationServer = TeamFoundationServerFactory.GetServer(name);
            this.workItemStore = (WorkItemStore)this.teamFoundationServer.GetService(typeof(WorkItemStore));
        }

        /// <summary>
        /// Gets the TeamFoundationServer
        /// </summary>
        public TeamFoundationServer TeamFoundationServer
        {
            get { return this.teamFoundationServer; }
        }

        /// <summary>
        /// Returns all the WorkItems that are currently in one of the given states and that have been changed by one of the given usernames between the end and start date.
        /// </summary>
        /// <param name="usernames"></param>
        /// <param name="begin"></param>
        /// <param name="end"></param>
        /// <returns></returns>
        public List<WorkItem> FindWorkItemsChangedByUserInRange(List<string> usernames, DateTime begin, DateTime end)
        {
            string changedByCondition = GetChangedByCondition(usernames);
            string changedDateCondtion = GetChangedDateCondition(begin);

            string query = "SELECT System.ID, System.Title FROM workitems WHERE {0} AND {1}";
            query = string.Format(query, changedByCondition, changedDateCondtion);

            List<WorkItem> result = new List<WorkItem>();
            foreach (WorkItem workItem in this.workItemStore.Query(query))
            {
                if (this.IsModifiedByUsernameInRange(workItem, usernames, begin, end))
                {
                    result.Add(workItem);
                }
            }
            return result;
        }

        /// <summary>
        /// Prepares a value to be used as a string constant in a WIQL statement.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string QuoteValue(string value)
        {
            return "'" + value + "'";
        }

        /// <summary>
        /// Builds an OR clause of [Changed By] EVER 'username' for the given usernames
        /// </summary>
        /// <param name="usernames"></param>
        /// <returns></returns>
        private string GetChangedByCondition(List<string> usernames)
        {
            StringBuilder result = new StringBuilder("(");
            for (int i = 0; i < usernames.Count - 1; ++i)
            {
                result.Append("[Changed By] EVER ");
                result.Append(QuoteValue(usernames[i]));
                result.Append(" OR ");
            }

            result.Append("[Changed By] EVER ");
            result.Append(QuoteValue(usernames[usernames.Count - 1]));
            result.Append(")");

            return result.ToString();
        }

        /// <summary>
        /// Builds a State IN ('state1', 'state2', ... ') clause for the given states
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        private string GetStateCondition(List<string> values)
        {
            StringBuilder result = new StringBuilder("State IN (");
            for (int i = 0; i < values.Count - 1; ++i)
            {
                result.Append(QuoteValue(values[i]));
                result.Append(", ");
            }

            result.Append(QuoteValue(values[values.Count - 1]));

            result.Append(")");

            return result.ToString();
        }

        /// <summary>
        /// Builds a [Changed Date] >= 'given date' for the given date
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        private string GetChangedDateCondition(DateTime date)
        {
            StringBuilder result = new StringBuilder("[Changed Date] >= ");
            result.Append(QuoteValue(date.ToShortDateString()));
            return result.ToString();
        }

        /// <summary>
        /// Returns true if the WorkItem has a revision between begin and end made by one of the given usernames
        /// </summary>
        /// <param name="workItem"></param>
        /// <param name="usernames"></param>
        /// <param name="begin"></param>
        /// <param name="end"></param>
        /// <returns></returns>
        private bool IsModifiedByUsernameInRange(WorkItem workItem, List<string> usernames, DateTime begin, DateTime end)
        {
            foreach (Revision revision in workItem.Revisions)
            {
                string changedBy = (string)revision.Fields["Changed By"].Value;
                if (usernames.Contains(changedBy))
                {
                    DateTime changedDate = (DateTime)revision.Fields["Changed Date"].Value;
                    if (begin <= changedDate && changedDate <= end)
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}

using System;
using System.Collections.Generic;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
namespace Be.TimVW.WorkItemTrackingTool
{
    public interface IWorkItemTrackerView
    {
        event EventHandler<SearchRequestedEventArgs> SearchRequested;

        List<string> Usernames { get; set; }

        void BeginWork( string message );
        void UnloadWorkItems();
        void LoadWorkItems( TeamFoundationServer teamFoundationServer, List<WorkItem> workItems );
        void EndWork();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Be.TimVW.WorkItemTrackingTool
{
    public partial class WorkItemTrackerView : Form, IWorkItemTrackerView
    {
        #region Events

        public event EventHandler<SearchRequestedEventArgs> SearchRequested;

        #endregion

        #region Constructors

        public WorkItemTrackerView()
        {
            InitializeComponent();

            this.dataGridViewUsernames.AutoGenerateColumns = false;
            this.dataGridViewWorkItems.AutoGenerateColumns = false;

            this.ColumnID.DataPropertyName = "Id";
            this.ColumnState.DataPropertyName = "State";
            this.ColumnTitle.DataPropertyName = "Title";
        }

        #endregion

        #region Properties

        public List<string> Usernames
        {
            get { return this.GetEnteredValues( this.dataGridViewUsernames ); }
            set
            {
                if( this.InvokeRequired )
                {
                    this.EndInvoke( this.BeginInvoke( new MethodInvoker( delegate { this.Usernames = value; } ) ) );
                }
                else
                {
                    this.dataGridViewUsernames.Rows.Clear();
                    foreach( string username in value )
                    {
                        this.dataGridViewUsernames.Rows.Add( username );
                    }
                }
            }
        }

        #endregion

        #region Public Methods

        public void BeginWork( string message )
        {
            this.PrePerform( message );
        }

        public void UnloadWorkItems()
        {
            if( this.InvokeRequired )
            {
                this.EndInvoke( this.BeginInvoke( new MethodInvoker( delegate { this.UnloadWorkItems(); } ) ) );
            }
            else
            {
                this.dataGridViewWorkItems.DataSource = null;
                this.workItemFormControl1.Item = null;
                this.workItemFormControl1.ServiceProvider = null;
            }
        }

        public void LoadWorkItems( TeamFoundationServer teamFoundationServer, List<WorkItem> workItems )
        {
            if( this.InvokeRequired )
            {
                this.EndInvoke( this.BeginInvoke( new MethodInvoker( delegate { this.LoadWorkItems( teamFoundationServer, workItems ); } ) ) );
            }
            else
            {
                this.workItemFormControl1.ServiceProvider = teamFoundationServer;

                SortableBindingList<WorkItem> sortableWorkItems = new SortableBindingList<WorkItem>( workItems );
                this.dataGridViewWorkItems.DataSource = sortableWorkItems;
            }
        }

        public void EndWork()
        {
            this.PostPerform( null );
        }

        #endregion

        #region Private Methods

        private void buttonSearch_Click( object sender, EventArgs e )
        {
            SearchRequestedEventArgs args = new SearchRequestedEventArgs( this.Usernames, this.dateTimePickerBegin.Value, this.dateTimePickerEnd.Value );
            this.RaiseSearchRequested( args );
        }

        private void dataGridViewWorkItems_SelectionChanged( object sender, EventArgs e )
        {
            if( this.dataGridViewWorkItems.SelectedRows.Count == 1 )
            {
                this.workItemFormControl1.Item = (WorkItem) this.dataGridViewWorkItems.SelectedRows[0].DataBoundItem;
            }
            else
            {
                this.workItemFormControl1.Item = null;
            }
        }

        private void RaiseSearchRequested( SearchRequestedEventArgs args )
        {
            EventHandler<SearchRequestedEventArgs> handler = this.SearchRequested;
            if( handler != null )
            {
                handler( this, args );
            }
        }

        private List<string> GetEnteredValues( DataGridView dataGridView )
        {
            List<string> values = new List<string>();

            for( int i = 0; i < dataGridView.RowCount; ++i )
            {
                if( !dataGridView.Rows[i].IsNewRow )
                {
                    values.Add( this.dataGridViewUsernames[0, i].Value.ToString() );
                }
            }

            return values;
        }

        private void PrePerform( string message )
        {
            if( this.InvokeRequired )
            {
                this.EndInvoke( this.BeginInvoke( new MethodInvoker( delegate { this.PrePerform( message ); } ) ) );
            }
            else
            {
                this.Enabled = false;
                this.toolStripStatusLabel1.Text = message;
                this.toolStripStatusLabel1.Visible = true;
                this.toolStripProgressBar1.Visible = true;
            }
        }

        private void PostPerform( object state )
        {
            if( this.InvokeRequired )
            {
                this.EndInvoke( this.BeginInvoke( new MethodInvoker( delegate { this.PostPerform( state ); } ) ) );
            }
            else
            {
                this.toolStripProgressBar1.Visible = false;
                this.toolStripStatusLabel1.Visible = false;
                this.toolStripStatusLabel1.Text = string.Empty;
                this.Enabled = true;
            }
        }

        #endregion
    }
}

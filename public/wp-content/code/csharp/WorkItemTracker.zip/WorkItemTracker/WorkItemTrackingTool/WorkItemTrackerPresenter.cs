using System.Configuration;
using System.Collections.Generic;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System.Threading;

namespace Be.TimVW.WorkItemTrackingTool
{
    public class WorkItemTrackerPresenter
    {
        public WorkItemTrackerPresenter( WorkItemTrackerView workItemTrackerView )
        {
            workItemTrackerView.SearchRequested += new System.EventHandler<SearchRequestedEventArgs>( workItemTracker_SearchRequested );
            workItemTrackerView.Usernames = new List<string>( ConfigurationManager.AppSettings["users"].Split( ',' ) );
        }

        private void workItemTracker_SearchRequested( object sender, SearchRequestedEventArgs e )
        {
            WorkItemTrackerView workItemTrackerView = (WorkItemTrackerView) sender;
            workItemTrackerView.BeginWork( "Searching WorkItems..." );
            workItemTrackerView.UnloadWorkItems();

            ThreadPool.QueueUserWorkItem( delegate( object state )
            {
                WorkItemSearcher workItemSearcher = new WorkItemSearcher( ConfigurationManager.AppSettings["server"] );
                List<WorkItem> workItems = workItemSearcher.FindWorkItemsChangedByUserInRange( e.Usernames, e.Begin, e.End );

                workItemTrackerView.LoadWorkItems( workItemSearcher.TeamFoundationServer, workItems );
                workItemTrackerView.EndWork();
            }, null );
        }
    }
}

using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : Page
{
    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        e.Authenticated = true;
    }
}
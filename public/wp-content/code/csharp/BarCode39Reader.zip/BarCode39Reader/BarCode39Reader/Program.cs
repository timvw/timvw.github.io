using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace BarCode39Reader
{
    class Program
    {
        static void Main( string[] args )
        {
            string encode = "i am bored and i need to go to sleep...".ToUpper();
            string decode = BarCodeReader.Decode( new Code39(encode).Paint() );
            Console.WriteLine( "encode: " + encode + Environment.NewLine + "decode: " + decode );

            Console.Write( "{0}Press any key to continue...", Environment.NewLine );
            Console.ReadKey();
        }
    }
}

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    /// <summary>
    /// Specifications for the conversion of $classname$s.
    /// </summary>
    [TestClass]
    public class WhenConverting$classname$s
    {
        /// <summary>
        /// Should be able to convert to $classname$.
        /// </summary>
        [TestMethod]
        public void ShouldBeAbleToConvertTo$classname$()
        {
            string value = "1";
            $classname$ actual = value;
            $classname$ expected = new $classname$(value);
            Assert.AreEqual(expected, actual, "Implicit conversion to $classname$");
        }

        /// <summary>
        /// Should be able to convert to string.
        /// </summary>
        [TestMethod]
        public void ShouldBeAbleToConvertToInt()
        {
            $classname$ value = new $classname$("2");
            string actual = value;
            string expected = "2";
            Assert.AreEqual(expected, actual, "Implicit conversion to string.");
        }
    }
}

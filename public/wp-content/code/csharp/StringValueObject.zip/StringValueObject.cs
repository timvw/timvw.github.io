using System;
using System.Globalization;

namespace $rootnamespace$
{
    /// <summary>
    /// Represents a value object of type string.
    /// </summary>
    public class $safeitemname$ : IComparable<$safeitemname$>, IEquatable<$safeitemname$>
    {
        private readonly string value;

        /// <summary>
        /// Initializes a new instance of the <see cref="$safeitemname$"/> class.
        /// </summary>
        /// <param name="value">The value.</param>
        public $safeitemname$(string value)
        {
            this.value = value;
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
        /// </returns>
        public override string ToString()
        {
            return this.value.ToString(CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"/> is equal to the current <see cref="T:System.Object"/>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"/> to compare with the current <see cref="T:System.Object"/>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"/> is equal to the current <see cref="T:System.Object"/>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            return InternalEquals(this, obj as $safeitemname$);
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"/>.
        /// </returns>
        public override int GetHashCode()
        {
            return this.value.GetHashCode();
        }

        /// <summary>
        /// Compares the current object with another object of the same type.
        /// </summary>
        /// <param name="other">An object to compare with this object.</param>
        /// <returns>
        /// A 32-bit signed integer that indicates the relative order of the objects being compared. 
        /// The return value has the following meanings: 
        /// - Less than zero: This object is less than the other parameter.
        /// - Zero: This object is equal to other. 
        /// - Greater: than zero This object is greater than other.
        /// </returns>
        public int CompareTo($safeitemname$ other)
        {
            return InternalCompare(this, other);
        }

        /// <summary>
        /// Indicates whether the current object is equal to another object of the same type.
        /// </summary>
        /// <param name="other">An object to compare with this object.</param>
        /// <returns>
        /// true if the current object is equal to the other parameter; otherwise, false.
        /// </returns>
        public bool Equals($safeitemname$ other)
        {
            return InternalEquals(this, other);
        }

        /// <summary>
        /// Compares two values.
        /// </summary>
        /// <param name="value1">The value1.</param>
        /// <param name="value2">The value2.</param>
        /// <returns></returns>
        private static int InternalCompare($safeitemname$ value1, $safeitemname$ value2)
        {
            if (ReferenceEquals(value1, value2))
            {
                return 0;
            }

            if ((object)value1 == null)
            {
                return -1;
            }

            if ((object)value2 == null)
            {
                return 1;
            }

            return value1.value.CompareTo(value2.value);
        }

        /// <summary>
        /// Determines if two values are equal.
        /// </summary>
        /// <param name="value1">The first value.</param>
        /// <param name="value2">The second value.</param>
        /// <returns>true when both identifications are equal.</returns>
        private static bool InternalEquals($safeitemname$ value1, $safeitemname$ value2)
        {
            if (ReferenceEquals(value1, value2))
            {
                return true;
            }

            if ((object)value1 == null || (object)value2 == null)
            {
                return false;
            }

            return value1.value == value2.value;
        }

        /// <summary>
        /// Implements the operator ==.
        /// </summary>
        /// <param name="value1">The first value.</param>
        /// <param name="value2">The second value.</param>
        /// <returns>The result of the operator.</returns>
        public static bool operator ==($safeitemname$ value1, $safeitemname$ value2)
        {
            return InternalEquals(value1, value2);
        }

        /// <summary>
        /// Implements the operator !=.
        /// </summary>
        /// <param name="value1">The first value.</param>
        /// <param name="value2">The second value.</param>
        /// <returns>The result of the operator.</returns>
        public static bool operator !=($safeitemname$ value1, $safeitemname$ value2)
        {
            return !(value1 == value2);
        }

        /// <summary>
        /// Performs an implicit conversion from <see cref="$safeitemname$"/> to <see cref="System.String"/>.
        /// </summary>
        /// <param name="value">The identification.</param>
        /// <returns>The result of the conversion.</returns>
        public static implicit operator string($safeitemname$ value)
        {
            return value.value;
        }

        /// <summary>
        /// Performs an implicit conversion from <see cref="System.String"/> to <see cref="$safeitemname$"/>.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>The result of the conversion.</returns>
        public static implicit operator $safeitemname$(string value)
        {
            return new $safeitemname$(value);
        }

        /// <summary>
        /// Implements the operator &lt;.
        /// </summary>
        /// <param name="value1">The value1.</param>
        /// <param name="value2">The value2.</param>
        /// <returns>The result of the operator.</returns>
        public static bool operator <($safeitemname$ value1, $safeitemname$ value2)
        {
            return InternalCompare(value1, value2) < 0;
        }

        /// <summary>
        /// Implements the operator &gt;.
        /// </summary>
        /// <param name="value1">The value1.</param>
        /// <param name="value2">The value2.</param>
        /// <returns>The result of the operator.</returns>
        public static bool operator >($safeitemname$ value1, $safeitemname$ value2)
        {
            return InternalCompare(value1, value2) > 0;
        }
    }
}
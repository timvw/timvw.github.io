using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    /// <summary>
    /// Specifications for the comparision of $classname$s.
    /// </summary>
    [TestClass]
    public class WhenComparing$classname$s
    {
        /// <summary>
        /// When comparing instance with null, instance should be greater.
        /// </summary>
        [TestMethod]
        public void ShouldReturnPositiveWhenComparedWithNull()
        {
            $classname$ value = new $classname$("0");
            Assert.IsTrue(value.CompareTo(null) > 0);
        }
        
        /// <summary>
        /// When both $classname$s reference the same instance, zero should be returned.
        /// </summary>
        [TestMethod]
        public void ShouldReturnZeroWhenBothReferencesAreSame()
        {
            $classname$ value = new $classname$("0");
            $classname$ value1 = value;
            $classname$ value2 = value;
            Assert.AreEqual(0, value1.CompareTo(value2));
            Assert.AreEqual(0, value2.CompareTo(value1));
        }

        /// <summary>
        /// The &lt; operator should return true when only first argument is null.
        /// </summary>
        [TestMethod]
        public void ShouldReturnTrueForSmallerThanOperatorWhenOnlyFirstArgumentIsNull()
        {
            $classname$ value1 = null;
            $classname$ value2 = new $classname$("2");
            Assert.IsTrue(value1 < value2);
            Assert.IsTrue(value2 > value1);
        }

        /// <summary>
        /// The &lt; operator should return true when only second argument is null.
        /// </summary>
        [TestMethod]
        public void ShouldReturnFalseForSmallerThanOperatorWhenOnlySecondArgumentIsNull()
        {
            $classname$ value1 = new $classname$("1");
            $classname$ value2 = null;
            Assert.IsFalse(value1 < value2);
            Assert.IsFalse(value2 > value1);
        }

        /// <summary>
        /// Comparison should be based on value.
        /// </summary>
        [TestMethod]
        public void ShouldUseValueForComparision()
        {
            $classname$ value1 = new $classname$("1");
            $classname$ value2 = new $classname$("2");
            $classname$ value3 = new $classname$("3");

            Assert.IsTrue(value1.CompareTo(value1) == 0);
            Assert.IsTrue(value1.CompareTo(value2) < 0);
            Assert.IsTrue(value1.CompareTo(value3) < 0);

            Assert.IsTrue(value2.CompareTo(value1) > 0);
            Assert.IsTrue(value2.CompareTo(value2) == 0);
            Assert.IsTrue(value2.CompareTo(value3) < 0);

            Assert.IsTrue(value3.CompareTo(value1) > 0);
            Assert.IsTrue(value3.CompareTo(value2) > 0);
            Assert.IsTrue(value3.CompareTo(value3) == 0);
        }
    }
}

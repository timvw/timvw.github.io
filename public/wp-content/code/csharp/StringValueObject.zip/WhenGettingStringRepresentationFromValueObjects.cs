using System.Globalization;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    /// <summary>
    /// Specifications for the generation of string representations of $classname$s.
    /// </summary>
    [TestClass]
    public class WhenGettingStringRepresentationFrom$classname$s
    {
        /// <summary>
        /// Should return string representation of internal value.
        /// </summary>
        [TestMethod]
        public void ShouldReturnStringRepresentationOfInternalValue()
        {
            string value = "1";
            $classname$ valueObject = new $classname$(value);
            Assert.AreEqual(value.ToString(CultureInfo.InvariantCulture), valueObject.ToString());
        }
    }
}

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    /// <summary>
    /// Specifications for the generation of HashCodes from $classname$s.
    /// </summary>
    [TestClass]
    public class WhenGettingHashCodeFrom$classname$s
    {
        /// <summary>
        /// HashCodes for two $classname$s that are equal should be equal.
        /// </summary>
        [TestMethod]
        public void ShouldReturnSameHashCodesForSameValues()
        {
            $classname$ value1 = new $classname$("1");
            $classname$ value2 = new $classname$("1");
            Assert.AreEqual(value1.GetHashCode(), value2.GetHashCode());
        }

        /// <summary>
        /// HashCodes for two $classname$s that are not equal should not be equal.
        /// </summary>
        [TestMethod]
        public void ShouldReturnDifferentHashCodesForDifferentValues()
        {
            $classname$ value1 = new $classname$("1");
            $classname$ value2 = new $classname$("2");
            Assert.AreNotEqual(value1.GetHashCode(), value2.GetHashCode());
        }
    }
}

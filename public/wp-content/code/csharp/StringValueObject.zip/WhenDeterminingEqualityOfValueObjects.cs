using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    /// <summary>
    /// Specifications for determining equality of $classname$s.
    /// </summary>
    [TestClass]
    public class WhenDeterminingEqualityOf$classname$s
    {
        /// <summary>
        /// The $classname$s are equal when values are same.
        /// </summary>
        [TestMethod]
        public void ShouldReturnTrueWhenValuesAreEqual()
        {
            $classname$ value1 = new $classname$("1");
            $classname$ value1Copy = new $classname$("1");
            $classname$ value2 = new $classname$("2");

            Assert.IsTrue(value1.Equals(value1));

            Assert.IsTrue(value1.Equals(value1Copy));
            Assert.IsTrue(value1 == value1Copy);
            Assert.IsFalse(value1 != value1Copy);

            Assert.IsFalse(value1.Equals(value2));
            Assert.IsFalse(value1 == value2);
            Assert.IsTrue(value1 != value2);

            Assert.IsFalse(value2.Equals(value1));
            Assert.IsFalse(value2 == value1);
            Assert.IsTrue(value2 != value1);

            Assert.IsTrue(value2.Equals(value2));
        }

        /// <summary>
        ///  The $classname$s are equal when both arguments reference same instance.
        /// </summary>
        [TestMethod]
        public void ShouldReturnTrueWhenBothArgumentsReferenceSameInstance()
        {
            $classname$ value = new $classname$("0");
            $classname$ value1 = value;
            $classname$ value2 = value;
            Assert.IsTrue(value1 == value2);
        }

        /// <summary>
        /// The $classname$s are not equal when only the first is null.
        /// </summary>
        [TestMethod]
        public void ShouldReturnFalseWhenOnlyFirstArgumentIsNull()
        {
            $classname$ value1 = null;
            $classname$ value2 = new $classname$("2");
            Assert.IsFalse(value1 == value2);
        }

        /// <summary>
        /// The $classname$s are not equal when only the second is null.
        /// </summary>
        [TestMethod]
        public void ShouldReturnFalsewhenOnlySecondArgumentIsNull()
        {
            $classname$ value1 = new $classname$("1");
            $classname$ value2 = null;
            Assert.IsFalse(value1 == value2);
        }
    }
}

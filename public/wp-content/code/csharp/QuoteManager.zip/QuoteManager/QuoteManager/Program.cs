using System;
using System.Windows.Forms;
using QuoteManager.Domain;
using QuoteManager.Resources;
using QuoteManager.Windows;

namespace QuoteManager
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var quoteForm = new QuoteForm();
            var quoteResource = new QuoteResource();
            new QuoteFormPresenter(quoteForm, quoteResource);

            Application.Run(quoteForm);
        }
    }
}
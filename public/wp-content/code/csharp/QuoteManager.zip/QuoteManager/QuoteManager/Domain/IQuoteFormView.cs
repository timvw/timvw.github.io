using System;

namespace QuoteManager.Domain
{
    public interface IQuoteFormView
    {
        string UpdatedQuote { get; }
        event EventHandler Load;
        event EventHandler EditClick;
        event EventHandler OKClick;
        event EventHandler CancelClick;

        void DisplayQuote(string quote);
        void DisplayError(string message);

        void MakeEditButtonVisible(bool visible);
        void MakeOKButtonVisible(bool visible);
        void MakeCancelButtonVisible(bool visible);
        void MakeQuoteEditable(bool editable);
    }
}
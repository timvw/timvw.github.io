using System;

namespace QuoteManager.Domain
{
    public class QuoteFormPresenter
    {
        private const string Quote = "The greatest mistake is trying to be more agreeable than you can be.";
        private readonly IQuoteFormView quoteFormView;
        private readonly IQuoteResource quoteResource;

        public QuoteFormPresenter(IQuoteFormView quoteFormView, IQuoteResource quoteResource)
        {
            this.quoteFormView = quoteFormView;
            this.quoteFormView.Load += this.quoteFormView_Load;
            this.quoteFormView.EditClick += this.quoteFormView_EditClick;
            this.quoteFormView.OKClick += this.quoteFormView_OKClick;
            this.quoteFormView.CancelClick += this.quoteFormView_CancelClick;
            this.quoteResource = quoteResource;
        }

        private void quoteFormView_Load(object sender, EventArgs e)
        {
            this.quoteFormView.DisplayQuote(Quote);
            this.quoteFormView.MakeEditButtonVisible(true);
            this.quoteFormView.MakeOKButtonVisible(false);
            this.quoteFormView.MakeCancelButtonVisible(false);
            this.quoteFormView.MakeQuoteEditable(false);
        }

        private void quoteFormView_EditClick(object sender, EventArgs e)
        {
            this.quoteFormView.MakeEditButtonVisible(false);
            this.quoteFormView.MakeOKButtonVisible(true);
            this.quoteFormView.MakeCancelButtonVisible(true);
            this.quoteFormView.MakeQuoteEditable(true);
        }

        private void quoteFormView_OKClick(object sender, EventArgs e)
        {
            try
            {
                var updatedQuote = this.quoteFormView.UpdatedQuote;
                this.quoteResource.Update(updatedQuote);
                this.quoteFormView.DisplayQuote(updatedQuote);

                this.quoteFormView.MakeEditButtonVisible(true);
                this.quoteFormView.MakeOKButtonVisible(false);
                this.quoteFormView.MakeCancelButtonVisible(false);
                this.quoteFormView.MakeQuoteEditable(false);
            }
            catch
            {
                this.quoteFormView.DisplayError("Faild to update quote.");
            }
        }

        private void quoteFormView_CancelClick(object sender, EventArgs e)
        {
            this.quoteFormView.MakeEditButtonVisible(true);
            this.quoteFormView.MakeOKButtonVisible(false);
            this.quoteFormView.MakeCancelButtonVisible(false);
            this.quoteFormView.MakeQuoteEditable(false);
        }
    }
}
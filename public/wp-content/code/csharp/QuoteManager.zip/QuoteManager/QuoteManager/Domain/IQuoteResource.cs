﻿namespace QuoteManager.Domain
{
    public interface IQuoteResource
    {
        string Update(string quote);
    }
}

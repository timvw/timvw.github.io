﻿using System;
using QuoteManager.Domain;

namespace QuoteManager.Resources
{
    public class QuoteResource : IQuoteResource
    {
        public string Update(string quote)
        {
            if (string.IsNullOrEmpty(quote)) throw new ApplicationException();
            //System.IO.File.WriteAllText("quote.txt", quote);
            return quote;
        }
    }
}

using System;

namespace QuoteManager.Infrastructure
{
    public static class EventHelper
    {
        public static void Raise(this EventHandler eventHandler, object sender, EventArgs eventArgs)
        {
            var handler = eventHandler;
            if (ReferenceEquals(handler, null)) return;
            handler(sender, eventArgs);
        }

        public static void Raise<T>(this EventHandler<T> eventHandler, object sender, T eventArgs) where T : EventArgs
        {
            var handler = eventHandler;
            if (ReferenceEquals(handler, null)) return;
            handler(sender, eventArgs);
        }
    }
}
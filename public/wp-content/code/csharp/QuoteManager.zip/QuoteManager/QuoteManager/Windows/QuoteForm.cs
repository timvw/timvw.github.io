using System;
using System.Windows.Forms;
using QuoteManager.Domain;
using QuoteManager.Infrastructure;

namespace QuoteManager.Windows
{
    public partial class QuoteForm : Form, IQuoteFormView
    {
        public QuoteForm()
        {
            this.InitializeComponent();
            this.buttonEdit.Click += this.buttonEdit_Click;
            this.buttonOK.Click += this.buttonOK_Click;
            this.buttonCancel.Click += this.buttonCancel_Click;
        }

        public event EventHandler EditClick;
        public event EventHandler OKClick;
        public event EventHandler CancelClick;

        public void DisplayQuote(string quote)
        {
            this.labelQuote.Text = quote;
        }

        public void DisplayError(string message)
        {
            MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public string UpdatedQuote
        {
            get { return this.textBoxQuote.Text; }
        }

        public void MakeEditButtonVisible(bool visible)
        {
            this.buttonEdit.Visible = visible;
        }

        public void MakeOKButtonVisible(bool visible)
        {
            this.buttonOK.Visible = visible;
        }

        public void MakeCancelButtonVisible(bool visible)
        {
            this.buttonCancel.Visible = visible;
        }

        public void MakeQuoteEditable(bool editable)
        {
            this.labelQuote.Visible = !editable;
            this.textBoxQuote.Visible = editable;
            this.textBoxQuote.Text = this.labelQuote.Text;
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            this.EditClick.Raise(sender, e);
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            this.OKClick.Raise(sender, e);
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.CancelClick.Raise(sender, e);
        }
    }
}
﻿using System;
using Moq;
using QuoteManager.Domain;
using Xunit;

namespace QuoteManager.QuoteFormRequirements
{
    public class WhenUserClicksEdit
    {
        protected Mock<IQuoteFormView> quoteFormViewMock;
        protected Mock<IQuoteResource> quoteResourceMock;
        protected QuoteFormPresenter sut;

        public WhenUserClicksEdit()
        {
            this.Given();
            this.When();
        }

        public virtual void Given()
        {
            this.quoteFormViewMock = new Mock<IQuoteFormView>();
            this.quoteResourceMock = new Mock<IQuoteResource>();
            this.sut = new QuoteFormPresenter(this.quoteFormViewMock.Object, this.quoteResourceMock.Object);
        }

        public virtual void When()
        {
            this.quoteFormViewMock
                .Raise(view => view.EditClick += null, null, EventArgs.Empty);
        }

        [Fact]
        public void ShouldMakeEditButtonInvisisble()
        {
            this.quoteFormViewMock.Verify(
                view => view.MakeEditButtonVisible(false));
        }

        [Fact]
        public void ShouldMakeOKButtonVisible()
        {
            this.quoteFormViewMock.Verify(
                view => view.MakeOKButtonVisible(true));
        }

        [Fact]
        public void ShouldMakeCancelButtonVisible()
        {
            this.quoteFormViewMock.Verify(
                view => view.MakeCancelButtonVisible(true));
        }

        [Fact]
        public void ShouldMakeQuoteEditable()
        {
            this.quoteFormViewMock.Verify(
                view => view.MakeQuoteEditable(true));
        }
    }
}
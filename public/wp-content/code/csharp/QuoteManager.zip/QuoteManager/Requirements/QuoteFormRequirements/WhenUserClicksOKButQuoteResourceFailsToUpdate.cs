﻿using System;
using Moq;
using QuoteManager.Domain;
using Xunit;

namespace QuoteManager.QuoteFormRequirements
{
    public class WhenUserClicksOKButQuoteResourceFailsToUpdate : WhenUserClicksOK
    {
        /// <summary>
        /// Establish the context in which the requirements have to be fulfilled.
        /// </summary>
        public override void Given()
        {
            base.Given();

            base.quoteResourceMock
                .Setup(resource => resource.Update(It.IsAny<string>()))
                .Returns<string>(quote =>
                {
                    if (string.IsNullOrEmpty(quote)) throw new ApplicationException();
                    return quote.Replace("a", "b");
                });
        }

        [Fact]
        public void ShouldDisplayErrorMessage()
        {
            this.quoteFormViewMock.Verify(
                view => view.DisplayError(It.IsAny<string>()));
        }
    }
}
﻿using System;
using Moq;
using QuoteManager.Domain;
using Xunit;

namespace QuoteManager.QuoteFormRequirements
{
    public class WhenUserClicksOK
    {
        protected Mock<IQuoteFormView> quoteFormViewMock;
        protected Mock<IQuoteResource> quoteResourceMock;
        protected QuoteFormPresenter sut;
        protected string updatedQuote;

        /// <summary>
        /// For each test we establish the context and execute the system operation we want to test.
        /// </summary>
        public WhenUserClicksOK()
        {
            this.Given();
            this.When();
        }

        /// <summary>
        /// Establish the context in which the requirements have to be fulfilled.
        /// </summary>
        public virtual void Given()
        {
            this.quoteFormViewMock = new Mock<IQuoteFormView>();

            this.updatedQuote = "the updated quote";
            this.quoteFormViewMock
                .Setup(view => view.UpdatedQuote)
                .Returns(this.updatedQuote);

            this.quoteResourceMock = new Mock<IQuoteResource>();

            this.sut = new QuoteFormPresenter(this.quoteFormViewMock.Object, this.quoteResourceMock.Object);
        }

        /// <summary>
        /// Performs the system operation for which we are describing the requirements.
        /// </summary>
        public virtual void When()
        {
            this.quoteFormViewMock
                .Raise(view => view.OKClick += null, null, EventArgs.Empty);
        }

        [Fact]
        public void ShouldMakeEditButtonVisisble()
        {
            this.quoteFormViewMock.Verify(
                view => view.MakeEditButtonVisible(true));
        }

        [Fact]
        public void ShouldMakeOKButtonInvisible()
        {
            this.quoteFormViewMock.Verify(
                view => view.MakeOKButtonVisible(false));
        }

        [Fact]
        public void ShouldMakeCancelButtonInvisible()
        {
            this.quoteFormViewMock.Verify(
                view => view.MakeCancelButtonVisible(false));
        }

        [Fact]
        public void ShouldMakeQuoteNotEditable()
        {
            this.quoteFormViewMock.Verify(
                view => view.MakeQuoteEditable(false));
        }

        [Fact]
        public void ShouldDisplayUpdatedQuote()
        {
            this.quoteFormViewMock.Verify(
                view => view.DisplayQuote(this.updatedQuote));
        }

        [Fact]
        public void ShouldSaveUpdateQuote()
        {
            var quote = this.quoteFormViewMock.Object.UpdatedQuote;
            this.quoteResourceMock.Verify(
                resource => resource.Update(quote));
        }
    }
}
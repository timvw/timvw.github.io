using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace AsyncDemo
{
    public partial class Form1 : Form
    {
        #region Delegates

        private delegate void Performer();

        #endregion

        #region Constructors

        public Form1()
        {
            InitializeComponent();
        }

        #endregion

        #region EventHandlers

        private void button1_Click(object sender, EventArgs e)
        {
            // remove previously retrieved results
            this.UpdateResultLabel(string.Empty);

            this.Perform(delegate
            {
                // simulate the effect of a blocking operation that takes a while to complete
                // eg: remoting, webrequests, database queries, ...
                Thread.Sleep(5000);

                // display the result of the long running operation
                this.UpdateResultLabel("Value was retrieved...");

            }, "Retrieving value...");
        }

        #endregion

        #region Methods

        /// <summary>
        /// Performs the given Performer
        /// </summary>
        /// <param name="performer"></param>
        /// <param name="message"></param>
        private void Perform(Performer performer, string message)
        {
            this.PrePerform(message);
            performer.BeginInvoke(this.PostPerform, null);
        }

        /// <summary>
        /// Performs the given Performer
        /// </summary>
        /// <param name="performer"></param>
        private void Perform(Performer performer)
        {
            this.Perform(performer, string.Empty);
        }

        /// <summary>
        /// Prepare the ui for a performance
        /// </summary>
        /// <param name="message"></param>
        private void PrePerform(string message)
        {
            if (this.InvokeRequired)
            {
                this.EndInvoke(this.BeginInvoke(new MethodInvoker(delegate { this.PrePerform(message); })));
            }
            else
            {
                this.Enabled = false;
                this.toolStripStatusLabel1.Text = message;
                this.toolStripStatusLabel1.Visible = true;
                this.toolStripProgressBar1.Visible = true;
            }
        }

        /// <summary>
        /// Restore the ui from a performance
        /// </summary>
        /// <param name="state"></param>
        private void PostPerform(object state)
        {
            if (this.InvokeRequired)
            {
                this.EndInvoke(this.BeginInvoke(new MethodInvoker(delegate { this.PostPerform(state); })));
            }
            else
            {
                this.toolStripProgressBar1.Visible = false;
                this.toolStripStatusLabel1.Visible = false;
                this.toolStripStatusLabel1.Text = string.Empty;
                this.Enabled = true;
            }
        }

        /// <summary>
        /// Update the result label
        /// </summary>
        /// <param name="message"></param>
        private void UpdateResultLabel(string message)
        {
            if (this.InvokeRequired)
            {
                this.EndInvoke(this.BeginInvoke(new MethodInvoker(delegate { this.UpdateResultLabel(message); })));
            }
            else
            {
                this.labelResult.Text = message;
            }
        }

        #endregion
    }
}
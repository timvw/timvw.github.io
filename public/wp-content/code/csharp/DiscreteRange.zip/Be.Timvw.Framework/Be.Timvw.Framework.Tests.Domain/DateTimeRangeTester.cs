using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Be.Timvw.Framework.Domain;

namespace Be.Timvw.Framework.Tests.Domain
{
    [TestClass]
    public class DateTimeRangeTester
    {
        [TestMethod, Owner("TVW")]
        public void TestDateTimeRangeIsCoveredByDateRange2008Covered()
        {
            DateTimeRange periodToCover = new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(2008, 12, 31, 23, 59, 59));

            IEnumerable<IDiscreteRange<DateTime>> coveredPeriods = new DateTimeRange[]
           {
               new DateTimeRange(DateTime.MinValue, new DateTime(2008, 6, 1, 23, 59, 59)),
               new DateTimeRange(new DateTime(2008, 6, 2), new DateTime(2008, 6, 30, 23, 59, 59)),
               new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(2009, 1, 1, 23, 59, 59))
           };

            Assert.IsTrue(periodToCover.IsCoveredByRanges(coveredPeriods));
        }

        [TestMethod, Owner("TVW")]
        public void TestDateTimeRangeIsCoveredByDateRanges2008NotCovered()
        {
            DateTimeRange periodToCover = new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(2008, 12, 31, 23, 59, 59));

            IEnumerable<IDiscreteRange<DateTime>> coveredPeriods = new DateTimeRange[]
           {
               new DateTimeRange(new DateTime(2000, 1, 1), new DateTime(2008, 6, 1, 23, 59, 59)),
               new DateTimeRange(new DateTime(2008, 6, 2), new DateTime(2008, 6, 30, 23, 59, 59)),
               new DateTimeRange(new DateTime(2010, 1, 1), new DateTime(2010, 12, 31, 23, 59, 59))
           };

            Assert.IsFalse(periodToCover.IsCoveredByRanges(coveredPeriods));
        }

        [TestMethod, Owner("TVW")]
        public void TestDateTimeRangeIsCoveredByDateRangePeriodTillEndOfTimeCovered()
        {
            DateTimeRange periodToCover = new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(9999, 12, 31, 23, 59, 59));

            IEnumerable<IDiscreteRange<DateTime>> coveredPeriods = new DateTimeRange[]
           {
               new DateTimeRange(new DateTime(2000, 1, 1), new DateTime(2008, 6, 1, 23, 59, 59)),
               new DateTimeRange(new DateTime(2008, 6, 2), new DateTime(2008, 6, 30, 23, 59, 59)),
               new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(2009, 1, 1, 23, 59, 59)),
               new DateTimeRange(new DateTime(2009, 1, 2), new DateTime(9999, 12, 31, 23, 59, 59))
           };

            Assert.IsTrue(periodToCover.IsCoveredByRanges(coveredPeriods));
        }

        [TestMethod, Owner("TVW")]
        public void TestDateTimeRangeIsCoveredByDateRangePeriodTillEndOfTimeNotCovered()
        {
            DateTimeRange periodToCover = new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(9999, 12, 31, 23, 59, 59));

            IEnumerable<IDiscreteRange<DateTime>> coveredPeriods = new DateTimeRange[]
           {
               new DateTimeRange(DateTime.MinValue, new DateTime(2008, 6, 1)),
               new DateTimeRange(new DateTime(2008, 6, 2), new DateTime(2008, 6, 30, 23, 59, 59)),
               new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(2009, 1, 1, 23, 59, 59)),
               new DateTimeRange(new DateTime(2009, 1, 2), new DateTime(9999, 12, 31, 23, 59, 58))
           };

            Assert.IsFalse(periodToCover.IsCoveredByRanges(coveredPeriods));
        }

        [TestMethod, Owner("TVW")]
        public void TestDateTimeRangeIsCoveredByDateRangePeriodTillEndOfTimeCoveredWithPeriodForEndOfTime()
        {
            DateTimeRange periodToCover = new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(9999, 12, 31, 23, 59, 59));

            IEnumerable<IDiscreteRange<DateTime>> coveredPeriods = new DateTimeRange[]
           {
               new DateTimeRange(new DateTime(2000, 1, 1), new DateTime(2008, 6, 1, 23, 59, 59)),
               new DateTimeRange(new DateTime(2008, 6, 2), new DateTime(2008, 6, 30, 23, 59, 59)),
               new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(9999, 12, 31, 23, 59, 58)),
               new DateTimeRange(new DateTime(9999, 12, 31, 23, 59, 59), new DateTime(9999, 12, 31, 23, 59, 59))
           };

            Assert.IsTrue(periodToCover.IsCoveredByRanges(coveredPeriods));
        }

        [TestMethod, Owner("TVW")]
        public void TestDateTimeRangeIsCoveredByDateRangePeriodTillEndOfTimeCoveredWithPeriodsForEndOfTime()
        {
            DateTimeRange periodToCover = new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(9999, 12, 31, 23, 59, 59));

            IEnumerable<IDiscreteRange<DateTime>> coveredPeriods = new DateTimeRange[]
           {
               new DateTimeRange(new DateTime(2000, 1, 1), new DateTime(2008, 6, 1, 23, 59, 59)),
               new DateTimeRange(new DateTime(2008, 6, 2), new DateTime(2008, 6, 30, 23, 59, 59)),
               new DateTimeRange(new DateTime(2008, 1, 1), new DateTime(9999, 12, 31, 23, 59, 57)),
               new DateTimeRange(new DateTime(9999, 12, 31, 23, 59, 58), new DateTime(9999, 12, 31, 23, 59, 58)),
               new DateTimeRange(new DateTime(9999, 12, 31, 23, 59, 59), new DateTime(9999, 12, 31, 23, 59, 59))
           };

            Assert.IsTrue(periodToCover.IsCoveredByRanges(coveredPeriods));
        }
    }
}
﻿using System.Collections.Generic;
namespace Be.Timvw.Framework.Domain
{
    public interface IDiscreteRange<T> : IRange<T>
    {
        bool IsCoveredByRanges(IEnumerable<IDiscreteRange<T>> ranges);
    }
}

using System;
using System.Collections.Generic;

namespace Be.Timvw.Framework.Domain
{
    public class DateRange : Range<DateTime>, IDiscreteRange<DateTime>, IDiscreteValuesProvider<DateTime>
    {
        #region Private Fields

        private DiscreteValuesRange<DateTime> discreteRange;

        #endregion

        #region Constructors

        public DateRange(DateTime begin, DateTime end)
            : base(begin, end)
        {
            this.discreteRange = new DiscreteValuesRange<DateTime>(begin, end, this);
        }

        #endregion

        #region IDiscreteValueProvider<DateTime> Members

        public DateTime GetNextValue(DateTime value)
        {
            return value.AddDays(1);
        }

        public DateTime MaxValue
        {
            get { return new DateTime(9999, 12, 31); }
        }

        #endregion

        #region IDiscreteRange<DateTime> Members

        public bool IsCoveredByRanges(IEnumerable<IDiscreteRange<DateTime>> ranges)
        {
            return this.discreteRange.IsCoveredByRanges(ranges);
        }

        #endregion

        #region Public Methods

        public bool IsCoveredByRanges(IEnumerable<DateRange> ranges)
        {
            return this.discreteRange.IsCoveredByRanges(Convert(ranges));
        }

        #endregion

        #region Private Methods

        public IEnumerable<IDiscreteRange<DateTime>> Convert(IEnumerable<DateRange> ranges)
        {
            foreach (DateRange dateTimeRange in ranges)
            {
                yield return (IDiscreteRange<DateTime>)dateTimeRange;
            }
        }

        #endregion
    }
}

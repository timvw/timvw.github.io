﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Be.Timvw.Framework.Domain
{
    public interface IDiscreteValuesProvider<T>
    {
        T GetNextValue(T value);
        T MaxValue { get; }
    }
}

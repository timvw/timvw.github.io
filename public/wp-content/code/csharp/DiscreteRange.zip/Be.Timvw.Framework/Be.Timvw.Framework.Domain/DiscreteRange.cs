﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Be.Timvw.Framework.Domain
{
    public class DiscreteValuesRange<T> : Range<T>, IDiscreteRange<T> where T : IComparable<T>
    {
        private IDiscreteValuesProvider<T> discreteValuesProvider;

        public DiscreteValuesRange(T begin, T end, IDiscreteValuesProvider<T> discreteValuesProvider)
            : base(begin, end)
        {
            this.discreteValuesProvider = discreteValuesProvider;
        }

        #region IDiscreteRange<T> Members

        public bool IsCoveredByRanges(IEnumerable<IDiscreteRange<T>> ranges)
        {
            T endOfRange = this.discreteValuesProvider.MaxValue;

            T currentValueToCheck = this.Begin;
            while (currentValueToCheck.CompareTo(this.End) <= 0)
            {
                bool currentValueToCheckIsCovered = false;

                foreach (IDiscreteRange<T> range in ranges)
                {
                    if (range.Includes(currentValueToCheck))
                    {
                        currentValueToCheckIsCovered = true;

                        if (range.End.CompareTo(endOfRange) < 0)
                        {
                            currentValueToCheck = this.discreteValuesProvider.GetNextValue(range.End);
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                if (!currentValueToCheckIsCovered)
                {
                    return false;
                }
            }

            return true;
        }

        #endregion
    }
}

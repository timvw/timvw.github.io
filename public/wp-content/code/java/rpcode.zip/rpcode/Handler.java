import java.util.regex.*;

abstract public class Handler {
	private Context context;
	private Matcher matcher;

	public Handler() {
		//
	}

	public Context getContext() {
		return context;
	}

	public void setContext(Context context) {
		this.context = context;
	}

	public Matcher getMatcher() {
		return matcher;
	}

	public void setMatcher(Matcher matcher) {
		this.matcher = matcher;
	}

	public String replaceAllCodes(String msg) {
		Pattern p = Pattern.compile("\\[.*?\\]");
		Matcher m = p.matcher(msg);
		return m.replaceAll("");
	}

	public Handler handle() {
		Context context = getContext();
		String message = context.getMessage();
	
		int pos = message.indexOf("[/" + getEndToken() + "]");
		if (pos != -1) {
			String msg = message.substring(0, pos);
			context.setMessage(msg);

			beforeHandling();
			
			Handler handler = new RegularHandler();
			handler.setContext(context);

			while (handler != null) {
				handler = handler.handle();
			}

			afterHandling();
			context.setMessage(message.substring(pos + getEndToken().length() + 3));
		}
		return null;
	}

	abstract public String getBeginToken();
	abstract public String getEndToken();

	public void beforeHandling() {}
	public void afterHandling() {}
}

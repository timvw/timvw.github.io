import java.util.regex.*;

public class RightHandler extends Handler {
	public String getBeginToken() {
		return "^r$";
	}

	public String getEndToken() {
		return "r";
	}

	public void beforeHandling() {
		Context context = getContext();
		String clean = replaceAllCodes(context.getMessage());
		context.setX(context.getWidth() - context.getG2().getFontMetrics().stringWidth(clean));
	}

	public void afterHandling() {
	}
}

import java.awt.*;
import java.util.regex.*;

public class ColorHandler extends Handler {
	private Color color;

	public String getBeginToken() {
		return "^color=(.*?)$";
	}

	public String getEndToken() {
		return "color";
	}

	public void beforeHandling() {	
		color = getContext().getG2().getColor();
		getContext().getG2().setColor(getColor(getMatcher().group(1).toLowerCase()));
	}

	public void afterHandling() {
		getContext().getG2().setColor(color);
	}

	private Color getColor( String color ) {
		if (color.equals("black")) return Color.black;
		else if (color.equals("blue")) return Color.blue;
		else if (color.equals("cyan")) return Color.cyan;
		else if (color.equals("dark gray")) return Color.darkGray;
		else if (color.equals("green")) return Color.green;
		else if (color.equals("light gray")) return Color.lightGray;
		else if (color.equals("magenta")) return Color.magenta;
		else if (color.equals("orange")) return Color.orange;
		else if (color.equals("pink")) return Color.pink;
		else if (color.equals("red")) return Color.red;
		else if (color.equals("white")) return Color.white;
		else if (color.equals("yellow")) return Color.yellow;
		return Color.black;
	}
}

import java.util.*;
import java.util.regex.*;

public class LeftAlignLeftHandler extends Handler {
	public String getBeginToken() {
		return "^ll=(\\d+)$";
	}

	public String getEndToken() {
		return "ll";
	}

	public void beforeHandling() {
		Context context = getContext();
		int col = Integer.parseInt(getMatcher().group(1));	
		char[] filler = new char[col - 1];
		Arrays.fill(filler, 'M');
		int posX = context.getG2().getFontMetrics().stringWidth(new String(filler));
		context.setX(posX); 
	}

	public void afterHandling() {
	}
}

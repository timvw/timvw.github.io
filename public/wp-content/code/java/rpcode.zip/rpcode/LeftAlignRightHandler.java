import java.util.*;
import java.util.regex.*;

public class LeftAlignRightHandler extends Handler {
	public String getBeginToken() {
		return "^lr=(\\d+)$";
	}

	public String getEndToken() {
		return "lr";
	}

	public void beforeHandling() {
		Context context = getContext();
		int col = Integer.parseInt(getMatcher().group(1));	
		char[] filler = new char[col];
		Arrays.fill(filler, 'M');
		int posX = context.getWidth() - context.getG2().getFontMetrics().stringWidth(new String(filler));
		context.setX(posX); 
	}

	public void afterHandling() {
	}
}

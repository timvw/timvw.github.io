import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.util.*;
import javax.swing.*;

public class JTest extends JPanel {
	public static void main(String[] args) {
		Collection<String> messages = new ArrayList<String>();
		messages.add("[c][b]Restaurant DE REGAPAN[/b][/c]");
		messages.add("[c][b]Sint-Maartensstraat 55d[/b][/c]");
		messages.add("[c][b]B-3000 Leuven[/b][/c]");
		messages.add("[c][b]Tel. +32 (0)16 29 85 11[/b][/c]");
		messages.add("[c][b]Fax +32 (0)16 20 44 17[/b][/c]");
		messages.add("");
		messages.add("");
		
		messages.add("Tafel: 5 [r]" + DateFormat.getDateTimeInstance().format(new Date()) + "[/r]");
		messages.add("");

		messages.add("[rl=2]1[/rl] x Cola [rr=8]1.65[/rr][r]1.65[/r]");
		messages.add("[rl=2]14[/rl] x Fanta [rr=8]1.65[/rr][r]23.10[/r]");
		messages.add("[rl=2]5[/rl] x Duvel [rr=8]2.00[/rr][r]12.00[/r]");
		messages.add("[r]=============[/r]");
		messages.add("Totaal: [r][b]�  36.75[/b][/r]");	
		messages.add("");
		messages.add("");

		messages.add("U werd bediend door: Tim");
		messages.add("");
		messages.add("[c]Dank u voor uw bezoek en tot weerziens![/c]");

		JFrame f = new JFrame("");
		f.getContentPane().setLayout(new BorderLayout());
		f.getContentPane().add(new JTest(400, messages), BorderLayout.CENTER);

		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.pack();
		f.setVisible(true);
	}

	private int width;
	private Collection<String> messages;
	
	public JTest(int width, Collection<String> messages) {
		this.width = width;
		this.messages = messages;

		setMinimumSize(new Dimension(width, 340));
		setPreferredSize(new Dimension(width, 340));
	}

	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2 = (Graphics2D) g;

		int y = g2.getFontMetrics().getHeight();
		for (String message: messages) {
			new Context(g2, width, y, message).handle();
			y += g2.getFontMetrics().getHeight();
		}
	}
}

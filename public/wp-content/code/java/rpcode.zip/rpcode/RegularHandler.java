import java.util.*;
import java.util.regex.*;

public class RegularHandler extends Handler {
	public String getBeginToken() {
		return null;
	}

	public String getEndToken() {
		return null;
	}

	public Handler handle() {
		Context context = getContext();
		String message = context.getMessage();

		Collection<Handler> handlers = new ArrayList<Handler>();
		handlers.add(new BoldHandler());
		handlers.add(new ItalicHandler());
		handlers.add(new ColorHandler());
		handlers.add(new CenterHandler());
		handlers.add(new RightHandler());
		handlers.add(new LeftAlignLeftHandler());
		handlers.add(new LeftAlignRightHandler());
		handlers.add(new RightAlignLeftHandler());
		handlers.add(new RightAlignRightHandler());
	
		int begin = message.indexOf("[");
		if (begin != -1) {
			int end = message.indexOf("]", begin);
			if (end != -1) {
				String token = message.substring(begin + 1, end);

				for(Handler handler: handlers) {
					String key = handler.getBeginToken();
					Pattern p = Pattern.compile(key);
					Matcher m = p.matcher(token);
					if (m.find()) {
						String msg = message.substring(0, begin);
						context.setMessage(msg);
						context.print();

						context.setMessage(message.substring(end + 1));				

						handler.setContext(context);
						handler.setMatcher(m);
						while (handler != null) {
							handler = handler.handle();
						}

						Handler next = new RegularHandler();
						next.setContext(context);	
						return next;
					}
				}
			}
		}
	
		context.print();	
		return null;
	}
}

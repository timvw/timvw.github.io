import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Context {
	private Graphics2D g2;
	private int width;
	private int x;
	private int y;
	private String message;

	public Context(Graphics2D g2, int width, int y, String message) {
		this.g2 = g2;
		this.width = width;
		this.x = 0;
		this.y = y;
		this.message = message;
	}

	public Graphics2D getG2() {
		return g2;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getWidth() {
		return width;
	}

	public void print() {
		g2.drawString(message, x, y);
		x += g2.getFontMetrics().stringWidth(message);
	}

	public void handle() {
		Handler handler = new RegularHandler();
		handler.setContext(this);
		while (handler != null) {
			handler = handler.handle();
		}
	}
}

import java.util.regex.*;

public class CenterHandler extends Handler {
	public String getBeginToken() {
		return "^c$";
	}

	public String getEndToken() {
		return "c";
	}

	public void beforeHandling() {
		Context context = getContext();
		String clean = replaceAllCodes(context.getMessage());
		context.setX((context.getWidth() - context.getG2().getFontMetrics().stringWidth(clean)) / 2);
	}

	public void afterHandling() {
	}
}

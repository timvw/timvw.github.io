import java.awt.*;

public class ItalicHandler extends Handler {
	private Font f;

	public String getBeginToken() {
		return "^i$";
	}

	public String getEndToken() {
		return "i";
	}

	public void beforeHandling() {
		f = getContext().getG2().getFont(); 
		getContext().getG2().setFont(f.deriveFont(Font.ITALIC + (f.isBold() ? Font.BOLD : 0)));
	}

	public void afterHandling() {
		getContext().getG2().setFont(f);
	}
}

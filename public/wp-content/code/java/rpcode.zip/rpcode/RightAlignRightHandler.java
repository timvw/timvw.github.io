import java.util.*;
import java.util.regex.*;

public class RightAlignRightHandler extends Handler {
	public String getBeginToken() {
		return "^rr=(\\d+)$";
	}

	public String getEndToken() {
		return "rr";
	}

	public void beforeHandling() {
		Context context = getContext();
		int col = Integer.parseInt(getMatcher().group(1));	
		char[] filler = new char[col - 1];
		Arrays.fill(filler, 'M');
		int posX = context.getWidth();
		posX -= context.getG2().getFontMetrics().stringWidth(new String(filler));
		posX -= context.getG2().getFontMetrics().stringWidth(replaceAllCodes(context.getMessage()));
		context.setX(posX); 
	}

	public void afterHandling() {
	}
}

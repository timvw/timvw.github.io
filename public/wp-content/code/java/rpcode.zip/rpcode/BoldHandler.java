import java.awt.*;

public class BoldHandler extends Handler {
	private Font f;

	public String getBeginToken() {
		return "^b$";
	}

	public String getEndToken() {
		return "b";
	}

	public void beforeHandling() {
		f = getContext().getG2().getFont();
		getContext().getG2().setFont(f.deriveFont(Font.BOLD + (f.isItalic() ? Font.ITALIC : 0)));
	}

	public void afterHandling() {
		getContext().getG2().setFont(f);
	}
}

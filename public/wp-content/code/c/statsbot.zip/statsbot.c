/*
 * statsbot.c
 *
 * Author: Tim Van Wassenhove <timvw@users.sourceforge.net>
 * Update: September 05, 2002 05:55:28 AM
 *
 * This program connects to a tetrinet server (as spectator),
 * spectates a games, and generates statistics for all the players
 * that participated to the game.
 *
 */

#include "statsbot.h"

int sock;
int slot;
int analyzing;

char server[128] = "tetrinet.be";
char nickname[128] = "eukiBOT";
char password[128] = "aardbeismaak";
char channel[128] = "#tetrinet";

// main method
int main (int argc,char *argv[]) {

	char input[1024];
	char output[1024];
	char *token;
	int i,j;

	// try to connect to the server with nickname and password
	if (tetri_connect(server,nickname) > 0) {
		// we are connected, start handling messages
		while (tetri_read(input,sizeof(input)) > 0) {
			printf("we read: %s\n",input);
			token = strtok(input," ");
			if (token) {
				if (!strcmp(token,"playernum")) {
					// we recieved our slotnumber, meaning we should answer with our password
					token = strtok(NULL," ");
					if (token) {
						slot = atoi(token);
						sprintf(output,"team %d %s",slot,password);
						tetri_write(output);
						sprintf(output,"pline %d /j %s",slot,channel);
						tetri_write(output);
					}
				} else if (!strcmp(token,"playerjoin")) {
						// a player joined our channel
						token = strtok(NULL," ");
						if (token) {
							int playerslot = atoi(token);
							token = strtok(NULL," ");
							if (token) {
								strcpy(players[playerslot-1].nickname,token);
								players[playerslot-1].timeofstart = 0;
								players[playerslot-1].timeofend = 0;
								players[playerslot-1].dropblocks = 0;
								players[playerslot-1].addlines = 0;
								players[playerslot-1].addtetris = 0;
								players[playerslot-1].inuse = 1;
							}
						}
				} else if (!strcmp(token,"playerleave")) {
						// a player left our channel
						token = strtok(NULL," ");
						if (token) {
							int playerslot = atoi(token);
							players[playerslot-1].inuse = 0;
						}
				} else if (!strcmp(token,"kick")) {
						// a player has been kicked
						token = strtok(NULL," ");
						if (token) {
							int playerslot = atoi(token);
							players[playerslot-1].inuse = 0;
						}
				} else if(!strcmp(token,"newgame")) {
						// the game has been started
						for (i=0;i<MAX_PLAYERS;i++) {
							time(&players[i].timeofstart);
							players[i].timeofend = 0;
							players[i].dropblocks = -1;
							players[i].addlines = 0;
							players[i].addtetris = 0;
						}
						analyzing = 1;
				} else if (!strcmp(token,"pause")) {
						//	the game has been (un)paused
						for (i=0;i<MAX_PLAYERS;i++) {
							if (players[i].timeofstart != 0) {
								time_t timenow;
								time(&timenow);
								players[i].timeofstart = timenow - players[i].timeofstart;

							}
						}
				} else if (!strcmp(token,"playerlost")) {
						// a player has lost
						token = strtok(NULL," ");
						if (token) {
							int playerslot = atoi(token);
							time(&players[playerslot-1].timeofend);
						}
				} else if (!strcmp(token,"playerwon")) {
						// a player has won
						token = strtok(NULL," ");
						if (token) {
							int playerslot = atoi(token);
							time(&players[playerslot-1].timeofend);
							if (analyzing) {
								sendstats();
								analyzing = 0;
							}
						}
				} else if (!strcmp(token,"endgame")) {
						// the game has been ended
						j = 0;
						for (i=0;i<MAX_PLAYERS;i++) {
							if (players[i].inuse) {
								j++;
							}
						}
						if (j <= 1 && analyzing) {
							sendstats();
							analyzing = 0;
						}
				} else if (!strcmp(token,"f")) {
						// a player has changed his field
						token = strtok(NULL," ");
						if (token) {
							int playerslot = atoi(token);
							players[playerslot-1].dropblocks++;
						}
				} else if (!strcmp(token,"sb")) {
						// a player has used a special
						token = strtok(NULL," ");
						if (token) {
							int from = atoi(token);
							token = strtok(NULL," ");
							if (token) {
								if (token[0] == 'c' && token[1] == 's') {
									players[from-1].addlines += (token[2]-0x30);
									if (token[2] == '4') {
										players[from-1].addtetris++;
									}
									for (i=0;i<MAX_PLAYERS;i++) {
										if (i != (from-1)) {
											players[i].dropblocks--;
										}
									}
								} else {
									token = strtok(NULL," ");
									if (token) {
										int to = atoi(token);
										players[to-1].dropblocks--;
									}
								}
							}
						}
				}
			}
		}
	}

	return 0;
}

/*
 * int tetri_read(char *str,int len)
 *
 * char *str: the string in which we will put what we read
 * int len: the number of bytes we want to read
 *
 * returns: 1 if success, -1 if failed
 *
 */
int tetri_read(char *str,int len) {
	int i;
	int end = 0;
	for (i=0;i<len-1 && !end;i++) {
		if (!recv(sock,&str[i],1,0)) {
			return -1;
		}
		if (str[i] == (char)0xFF) {
			end = 1;
		}
	}
	str[i-1] = '\0';
	return 1;
}

/*
 * int tetri_write(char *str)
 *
 * char *str: the string we want to write
 *
 * returns: 1
 *
 */
int tetri_write(char *str) {
	char c = 0xFF;
	send(sock,str,strlen(str),0);
	send(sock,&c,1,0);
	return 1;
}

/*
 * int tetri_connect(char *server,char *nickname)
 *
 * char *server: the name of the server we want to connect to
 * char *nickname: the name we use to identify ourselves on the server
 *
 * returns: 1 if success, value < 0 if failed
 */

int tetri_connect(char *server,char *nickname) {
	struct hostent *sip;
	struct sockaddr_in sin;
	char buf[200], buf2[200];
	unsigned char ip[4];
	unsigned char iphashbuf[6];
	int i,len;

	// lookup information about the server
	sip = gethostbyname(server);
	if (!sip) {
		printf("Error: Could not lookup %s\n",server);
		return -1;
	}

	// initialise socket info
	memset(&sin,0,sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(PORT_SPECTATOR);
	memcpy(&sin.sin_addr,sip->h_addr,sip->h_length);

	// initialise socket
	if ((sock = socket(PF_INET,SOCK_STREAM,0)) < 0) {
		printf("Error: Could not create socket\n");
		return -2;
	}

	// connect the socket to the server
	if (connect(sock,(struct sockaddr *)&sin,sizeof(struct sockaddr)) == -1) {
		printf("Error: Could not connect to %s",server);
		return -3;
	}

	// generate the initial string
	sprintf(buf,"tetrisstart %s 1.13",nickname);
	len = sizeof(sin);
	getpeername(sock,(struct sockaddr *)&sin,&len);
	memcpy(ip,&sin.sin_addr,4);
	sprintf(iphashbuf,"%d",ip[0]*54 + ip[1]*41 + ip[2]*29 + ip[3]*17);
	len = strlen(iphashbuf);
	buf2[0] = 0;
	for (i=0;buf[i];i++) {
		buf2[i+1] = (((buf2[i]&0xFF)+(buf[i]&0xFF)) % 255) ^ iphashbuf[i % len];
	}
	len = i+1;
	for (i=0;i<len;i++) {
		sprintf(buf+i*2,"%02X",buf2[i]&0xFF);
	}

	// write initial string to the server
	tetri_write(buf);

	return 1;
}

// generate game stats
void sendstats() {
	char output[1024];
	float timetotal,ppm;
	int i;

	for (i=0;i<MAX_PLAYERS;i++) {
		if (players[i].inuse && players[i].timeofstart != 0) {
			if (players[i].timeofend == 0) {
				time(&players[i].timeofend);
			}
			timetotal = (float) (players[i].timeofend - players[i].timeofstart);
			ppm = (float) (60 * players[i].dropblocks) / timetotal;
			sprintf(output,"pline %d /msg %s %c%s %c%d %cblocks @ %c%.2f %cppm added: %c%d %c(%c%d %ctetris)",i+1,channel,BLUE,players[i].nickname,RED,players[i].dropblocks,BLACK,RED,ppm,BLACK,RED,players[i].addlines,BLACK,RED,players[i].addtetris,BLACK);
			tetri_write(output);
		}
	}
}
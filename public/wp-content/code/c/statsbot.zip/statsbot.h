/*
 * statsbot.h
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/times.h>

// some tetrinet tcp/ip port numbers
#define PORT_IRC 				31456
#define PORT_TETRINET 	31457
#define PORT_SPECTATOR 	31458

#define MAX_PLAYERS	6

// some colors
#define BOLD			02
#define CYAN			03
#define BLACK			04
#define BLUE			05
#define DARKGRAY	06
#define MAGENTA		08
#define GREEN			12
#define NEON			14
#define SILVER		15
#define BROWN			16
#define NAVY			17
#define VIOLET		19
#define RED				20
#define ITALIC		22
#define TEAL			23
#define WHITE			24
#define YELLOW		25
#define UNDERLINE	31

// what we need to know about a player
struct player {
	int inuse;
	char nickname[128];
	char teamname[128];
	int dropblocks;
	int addlines;
	int addtetris;
	time_t timeofstart;
	time_t timeofend;
};

struct player players[MAX_PLAYERS];

// some function prototypes
int tetri_connect(char *server,char *nickname);
int tetri_read(char *str,int len);
int tetri_write(char *str);
void sendstats();